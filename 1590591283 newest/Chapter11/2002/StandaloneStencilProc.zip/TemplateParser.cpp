// TypesCheckCodeGen.cpp : Defines the entry point for the console application.


#include "stdafx.h"
#include <fstream.h>
//using namespace std;
#include "SupportedTypes.h"

#define PARAM_SIZE	128
#define MAX_INC_PARAMS 10


typedef TCHAR	FSArray[PARAM_SIZE];




stTypeDescriptor	*arSOAPTypes	=	NULL;

typedef struct tagIncData
{
	FSArray	left;
	FSArray	right;
	FSArray	values[MAX_INC_PARAMS];
}stIncData;

class CSAStream : public IWriteStream
{
protected:
	ofstream	out;
public:	
	CSAStream(LPCTSTR szOutFile)
	{
		out.open( szOutFile);
		out.setmode(filebuf::binary);
		
	}

	~CSAStream()
	{
		out.close();
	}

	
	HRESULT WriteStream(LPCSTR szOut, int nLen, DWORD *pdwWritten)
	{
		char	*buff	=	new char[nLen + 1];
		buff[nLen] = 0;
		memcpy( buff, szOut, nLen);
		out	<<	buff;
		delete[] buff;
		
		if( pdwWritten)
		{
			*pdwWritten = nLen;
		}
		return S_OK;
	}
	
	HRESULT FlushStream()
	{
		return S_OK;
	}

	void operator	<< (LPCTSTR	strBuff)
	{
		if( strBuff != NULL )
		{
			WriteStream( strBuff, _tcslen(strBuff), NULL);
		}
	}

	void operator	<< (CString& szBuff)
	{
		WriteStream( szBuff.GetBuffer(), szBuff.GetLength(), NULL);
	}

};


class CSAHandler : 
	public ITagReplacerImpl<CSAHandler>
{
protected:
	CSAStream			*_pStream;
	stTypeDescriptor	*_pTypeDescriptor;


	bool				_bEnumerateMode;
	int					_iTypesIndex;
	int					_iSoapStyleIndex;
public:
	virtual HRESULT STDMETHODCALLTYPE QueryInterface( 
			/* [in] */ REFIID riid,
			/* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject)
	{
		return E_NOTIMPL;
	}
	    
	virtual ULONG STDMETHODCALLTYPE AddRef( void)
	{
		return 0;
	}

	virtual ULONG STDMETHODCALLTYPE Release( void)
	{
		return 0;
	}

public:
	void	SetSoapStyle(int iIndex )
	{
		ATLASSERT( iIndex >= 0 );
		ATLASSERT( iIndex < sizeof(arSOAPStyles)/sizeof(SoapStyle) );

		_iSoapStyleIndex = iIndex;
	}


	bool	renderFile(LPCTSTR szFileName, CSAStream	*pStream, stTypeDescriptor	*pTypeDescriptor)
	{
		CStencil	stencil;
		HRESULT		hRet;
		bool		bRet	=	true;
		
		_bEnumerateMode	=	false;
		if( !pStream /*|| !pTypeDescriptor*/ )
		{
			return false;
		}
		_pStream	=	pStream;
		_pTypeDescriptor	=	pTypeDescriptor;

		
		hRet	=	stencil.LoadFromFile(szFileName);
		if( !SUCCEEDED(hRet) )
		{
			return false;
		}

		bRet	=	stencil.ParseReplacements(this);
		if( !bRet )
		{
			return false;
		}
		stencil.FinishParseReplacements();

		
		hRet	=	stencil.Render(this, pStream);
		_pStream	=	NULL;
		_pTypeDescriptor	=	NULL;

		bRet	=	SUCCEEDED(hRet);
		
		return bRet;
	}

public:

	HTTP_CODE	OnTypePhraseCase()
	{
		ATLASSERT( _pTypeDescriptor != NULL ); 
		(*_pStream)	<<	_pTypeDescriptor->strTypeAsPhrase;
		return HTTP_SUCCESS;
	}

	HTTP_CODE	OnType()
	{
		ATLASSERT( _pTypeDescriptor != NULL ); 
		(*_pStream)	<<	_pTypeDescriptor->strType;
		return HTTP_SUCCESS;
	}


	HTTP_CODE	OnResetList()
	{
		_bEnumerateMode	=	true;
		_iTypesIndex = -1;
		return HTTP_SUCCESS;
	}


	HTTP_CODE	OnStillTypes()
	{
		int		iSize	=	0;

		iSize	=	sizeof(arSOAPTypes)/sizeof(stTypeDescriptor);
		
		_iTypesIndex ++;

		if( _iTypesIndex < iSize )
		{
			_pTypeDescriptor	=	& (arSOAPTypes[_iTypesIndex]);
			return HTTP_SUCCESS;
		}
		else
		{
			_bEnumerateMode	=	false;
			return HTTP_S_FALSE;
		}
	}


	HTTP_CODE	OnStyle()
	{
		ATLASSERT( _iSoapStyleIndex >= 0 );
		ATLASSERT( _iSoapStyleIndex < sizeof(arSOAPStyles)/sizeof(SoapStyle) );

		SoapStyle	curStyle	=	arSOAPStyles[ _iSoapStyleIndex ];
		(*_pStream)	 <<	curStyle.szStyle;

		return HTTP_SUCCESS;
	}
	
	HTTP_CODE	OnIsStyle(LPSTR	str)
	{
		ATLASSERT( _iSoapStyleIndex >= 0 );
		ATLASSERT( _iSoapStyleIndex < sizeof(arSOAPStyles)/sizeof(SoapStyle) );
		CStringA	strCurrentStyle;
		HRESULT		hRet = HTTP_S_FALSE;

		
		SoapStyle	curStyle	=	arSOAPStyles[ _iSoapStyleIndex ];
		
		strCurrentStyle		=	curStyle.szStyle;
		strCurrentStyle		+=	"/";
		strCurrentStyle		+=	curStyle.szUse;
		
		
		if( str )
			if( strCurrentStyle.CompareNoCase( str) == 0 )
				hRet	=	HTTP_SUCCESS;
		
		return hRet;
	}
	

	HTTP_CODE	OnUse()
	{
		ATLASSERT( _iSoapStyleIndex >= 0 );
		ATLASSERT( _iSoapStyleIndex < sizeof(arSOAPStyles)/sizeof(SoapStyle) );

		SoapStyle	curStyle	=	arSOAPStyles[ _iSoapStyleIndex ];
		(*_pStream)		<<	curStyle.szUse;
		return HTTP_SUCCESS;
	}


	HTTP_CODE OnGetAGuid()
	{
		CString strFormat, rString; 
		GUID	m_guid;

		::CoCreateGuid(&m_guid);
		strFormat = "%08lX-%04X-%04x-%02X%02X-%02X%02X%02X%02X%02X%02X"; 

		// then format into destination 
		rString.Format(strFormat, 
		// first copy... 
		m_guid.Data1, m_guid.Data2, m_guid.Data3, 
		m_guid.Data4[0], m_guid.Data4[1], m_guid.Data4[2], m_guid.Data4[3], 
		m_guid.Data4[4], m_guid.Data4[5], m_guid.Data4[6], m_guid.Data4[7], 
		// second copy... 
		m_guid.Data1, m_guid.Data2, m_guid.Data3, 
		m_guid.Data4[0], m_guid.Data4[1], m_guid.Data4[2], m_guid.Data4[3], 
		m_guid.Data4[4], m_guid.Data4[5], m_guid.Data4[6], m_guid.Data4[7]); 
	
		(*_pStream)	<<	rString;
		return HTTP_SUCCESS;
	}



	BEGIN_REPLACEMENT_METHOD_MAP(CSAHandler)
		REPLACEMENT_METHOD_ENTRY("Type_Phrase_Case", OnTypePhraseCase)
		REPLACEMENT_METHOD_ENTRY("Type", OnType)
		REPLACEMENT_METHOD_ENTRY("GetAGuid", OnGetAGuid)
		//Hack for the long->int compiling error
		// iterative methods
		REPLACEMENT_METHOD_ENTRY("resetList", OnResetList)
		REPLACEMENT_METHOD_ENTRY("stillTypes", OnStillTypes)
		// style/use methods
		REPLACEMENT_METHOD_ENTRY_EX_STR("isStyle", OnIsStyle)
		REPLACEMENT_METHOD_ENTRY("style", OnStyle)
		REPLACEMENT_METHOD_ENTRY("use", OnUse)
		
		// Methods for the main cpp file

	END_REPLACEMENT_METHOD_MAP()

};

void loadSoapTypes(char*	szFile, int& iSize, stTypeDescriptor*& arTypes, CString& szSRF, CString& szOut)
{
	char	buff[2048];
	::GetPrivateProfileString("General", "SRF", "", buff, 2047, szFile);
	szSRF	=	buff;

	::GetPrivateProfileString("General", "OutFolder", "", buff, 2047, szFile);
	szOut	=	buff;

	iSize	=	::GetPrivateProfileInt("General", "Types", 0, szFile);

	arTypes	=	new stTypeDescriptor[iSize];
	
	for( int iIndex= 0; iIndex < iSize; iIndex ++ )
	{
		stTypeDescriptor	*desc	=	&(arTypes[iIndex]);
		desc->strType	=	new char[2048];
		desc->strTypeAsPhrase	=	new char[2048];

		char	szKey[64];
		sprintf(szKey, "Type%d", iIndex);
		::GetPrivateProfileString("Types", szKey, "", buff, 2047, szFile);
		strcpy( desc->strType, buff);

		sprintf(szKey, "Type%d_Phrase", iIndex);
		::GetPrivateProfileString("Types", szKey, "", buff, 2047, szFile);
		strcpy( desc->strTypeAsPhrase, buff);

	}
}
int main(int argc, char* argv[])
{
	
	CSAHandler	handler;
	CString		szOutputPath	=	"D:\\SOAPInterop\\ATLS\\Phase2\\SRFGenerator\\DataFiles";
	CString		szSRF;
	CString		szSrvFile, szClientFile;

	CString		szSRFFile;

	int			iSize;


	if( argc != 2)
	{
		printf("Usage : *.exe config_file\n");
		return -1;
	}
	loadSoapTypes( argv[1], iSize, arSOAPTypes, szSRF, szOutputPath);


	CoInitialize(NULL);
	//iSize	=	sizeof(arSOAPTypes)/sizeof(stTypeDescriptor);
	// Rendering client and server for each type
	for( int	iIndex = 0; iIndex < iSize; iIndex ++)
	{
		CString				szURL;

		stTypeDescriptor	*pTypeDesc	=	&(arSOAPTypes[iIndex]);

		// Render SOAP server
		for(int	iStyleIndex = 0; iStyleIndex < sizeof(arSOAPStyles)/sizeof(SoapStyle); iStyleIndex ++)
		{
			SoapStyle	currentStyle	=	arSOAPStyles[iStyleIndex];
			CStringA	strStyleFolder;
			handler.SetSoapStyle( iStyleIndex );

			strStyleFolder	+=	currentStyle.szStyle;
			strStyleFolder	+=	currentStyle.szUse;
			
			szSrvFile.Format("%s\\%s\\%s_Server.cpp", szOutputPath, strStyleFolder, pTypeDesc->strTypeAsPhrase);
			{
				CSAStream	stream(szSrvFile.GetBuffer());
				szSRFFile	=	szSRF;
				handler.renderFile(
							szSRFFile, 
							&stream,
							pTypeDesc);
			}

			printf("basicTypes_RPCENC.dll?Handler=GenRet%sWSDL\n", pTypeDesc->strTypeAsPhrase);
			printf("basicTypes_RPCENC.dll?Handler=GenRet%sOutWSDL\n", pTypeDesc->strTypeAsPhrase);
			printf("basicTypes_RPCENC.dll?Handler=GenRet%sByRefWSDL\n", pTypeDesc->strTypeAsPhrase);
		}
	}

	
	return 0;
}
