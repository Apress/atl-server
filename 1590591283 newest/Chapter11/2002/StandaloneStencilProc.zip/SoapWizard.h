#ifndef SOAPWIZARD_H_INCLUDED
#define SOAPWIZARD_H_INCLUDED


// Types supported by a SOAP server

// Types supported by ATL Server SOAP
enum SOAP_TYPE
{
	SOAP_TYPE_BOOL, 
	SOAP_TYPE_CHAR,
	SOAP_TYPE_WCHAR_T,
	SOAP_TYPE_INT8,
	SOAP_TYPE_UINT8,
	SOAP_TYPE_INT16,
	SOAP_TYPE_UINT16, 
	SOAP_TYPE_INT32,
	SOAP_TYPE_UINT32, 
	SOAP_TYPE_INT64,
	SOAP_TYPE_UINT64,
	SOAP_TYPE_DOUBLE,
	SOAP_TYPE_FLOAT,
	SOAP_TYPE_BSTR,
	SOAP_TYPE_BLOB,
};

struct stTypeDescriptor
{
	// the type code
	SOAP_TYPE	type;
	
	// type's displayable name
	LPCTSTR		szTypeName;

	// TRUE if the type needs memory allocation, 
	// like BSTR and ATLSOAP_BLOB
	BOOL		bNeedsMemoryAllocation;
};


enum SOAP_PARAM_DIRECTION
{
	SOAP_DIRECTION_IN,
	SOAP_DIRECTION_OUT,
	SOAP_DIRECTION_INOUT,
};

// Class describing a SOAP Method parameter
class CSoapMethodParam
{
public:
	// Parameter name
	CString					m_strParamName;
	
	// Parameter direction
	SOAP_PARAM_DIRECTION	m_direction;

	SOAP_TYPE				m_type;

	BOOL		Assign( CSoapMethodParam& other )
	{
		if( &other != this )
		{
			m_strParamName = other.m_strParamName;
			m_direction = other.m_direction;
			m_type = other.m_type;
		}
		return TRUE;
	}
};

// Class that encapsulates a SOAP method
class CSoapMethod
{
public:
	// Destructor required to clear the parameters array
	~CSoapMethod()
	{
		size_t nCount = m_arrParams.GetCount();
		for( size_t  nIndex = 0; nIndex < nCount; nIndex ++)
		{
			CSoapMethodParam*	pParam = m_arrParams.GetAt(nIndex);
			delete pParam;
		}
		m_arrParams.RemoveAll();
	}
	
	// Method to add a new parameter
	BOOL			AddParam(CSoapMethodParam*  pParam)
	{
		if( pParam )
		{
			m_arrParams.Add(pParam);
			return  true;
		}
		return false;
	}

	BOOL			Assign(CSoapMethod& other)
	{
		if( &other != this )
		{
			this->m_strName = other.m_strName;
			this->m_strParamDisplayString = other.m_strParamDisplayString;
			unsigned int nIndex = 0;
			for( nIndex = 0; nIndex < m_arrParams.GetCount(); nIndex ++)
			{
				delete m_arrParams.GetAt( nIndex );
			}
			m_arrParams.RemoveAll();

			for( nIndex = 0; nIndex < other.m_arrParams.GetCount(); nIndex ++)
			{
				CSoapMethodParam	*pParam = new CSoapMethodParam();
				pParam->Assign(*other.m_arrParams[nIndex]);
				this->m_arrParams.Add( pParam );
			}
		}
		return TRUE;
	}

	// Method to remove a parameter
	BOOL			RemoveParam(UINT nIndex)
	{
		if( nIndex < m_arrParams.GetCount() )
		{
			CSoapMethodParam	*pParam = m_arrParams.GetAt(nIndex);
			delete pParam;
			m_arrParams.RemoveAt(nIndex);
			return true;
		}
		return false;
	}

	// SoapMethod name
	CString							m_strName;
	
	// Display string containing all the parameters (for the main list)
	CString							m_strParamDisplayString;

	// Array of parameters
	CAtlArray<CSoapMethodParam*>	m_arrParams;
};

// class encapsulating a SOAP Service
class CSoapService
{
public:
	// destructor required to clear the functions array
	~CSoapService()
	{
		size_t nCount = m_arrMethods.GetCount();
		for( size_t nIndex = 0; nIndex < nCount; nIndex ++)
		{
			CSoapMethod*	pMethod = m_arrMethods.GetAt(nIndex);
			delete pMethod;
		}
		m_arrMethods.RemoveAll();
	}
	
	// Adds a new SOAP method
	BOOL		AddSoapMethod(CSoapMethod* pMethod)
	{
		if( pMethod )
		{
			m_arrMethods.Add(pMethod);
			return  true;
		}
		return false;
	}
	
	// Removes a method from the list
	BOOL		RemoveMethod(UINT nIndex)
	{
		if( nIndex < m_arrMethods.GetCount() )
		{
			CSoapMethod	*pMethod = m_arrMethods.GetAt(nIndex);
			delete pMethod;
			m_arrMethods.RemoveAt(nIndex);
			return true;
		}
		return false;
	}
	

	// Name of the service
	CString							m_strName;

	// Array of SOAP Methods
	CAtlArray<CSoapMethod*>	m_arrMethods;
};





inline BOOL CreateDirectoryRec(LPCTSTR szLocation)
{
	if( !szLocation || !szLocation[0])
	{
		return FALSE;
	}
	
	LPCTSTR szPathSkipRoot = PathSkipRoot(szLocation);
	CString strPathSoFar;

	if( szPathSkipRoot )
	{
		strPathSoFar.SetString(szLocation, (int)(_tcslen(szLocation) - _tcslen(szPathSkipRoot)) );
	}
	

	LPCTSTR szNextBackslash = szPathSkipRoot?szPathSkipRoot:szLocation;
	
	BOOL	bContinue = TRUE;
	do
	{

		LPCTSTR szTemp = _tcschr( szNextBackslash, _T('\\'));
		if( szTemp == szNextBackslash )
		{
			szTemp += 1;
			szTemp = _tcschr( szTemp, _T('\\'));
		}
		if( !szTemp )
		{
			bContinue = FALSE;
			strPathSoFar.Append( szNextBackslash);
		}
		else
		{
			strPathSoFar.Append( szNextBackslash, (int)(szTemp - szNextBackslash) );
			szNextBackslash = szTemp + 1;
		}
		
		BOOL	bRet = ::CreateDirectory( strPathSoFar, NULL);
		if( !bRet )
		{
			bRet = (ERROR_ALREADY_EXISTS == GetLastError());
		}
		if( !bRet )
		{
			return bRet;
		}

		if( bContinue )
		{
			strPathSoFar += _T("\\");
		}
	}while( bContinue );

	return TRUE;
}


// global array containing all the supported SOAP Types
__declspec(selectany) stTypeDescriptor arSOAPTypes[] = 
{
	{
		SOAP_TYPE_BOOL, 
		_T("bool"),
		FALSE
	},
	{
		SOAP_TYPE_CHAR,
		_T("char"),
		FALSE
	},
	{
		SOAP_TYPE_WCHAR_T,
		_T("wchar_t"),
		FALSE
	},
	{
		SOAP_TYPE_INT8,
		_T("__int8"),
		FALSE
	},
	{
		SOAP_TYPE_UINT8,
		_T("unsigned __int8"),
		FALSE
	},
	{
		SOAP_TYPE_INT16,
		_T("__int16"),
		FALSE
	},
	{
		SOAP_TYPE_UINT16, 
		_T("unsigned __int16"),
		FALSE
	},
	{
		SOAP_TYPE_INT32,
		_T("__int32"),
		FALSE
	},
	{
		SOAP_TYPE_UINT32, 
		_T("unsigned __int32"),
		FALSE
	},
	{
		SOAP_TYPE_INT64,
		_T("__int64"),
		FALSE
	},
	{
		SOAP_TYPE_UINT64,
		_T("unsigned __int64"),
		FALSE
	},
	{
		SOAP_TYPE_DOUBLE,
		_T("double"),
		FALSE
	},
	{
		SOAP_TYPE_FLOAT,
		_T("float"),
		FALSE
	},
	{
		SOAP_TYPE_BSTR,
		_T("BSTR"),
		TRUE
	},
	{
		SOAP_TYPE_BLOB,
		_T("ATLSOAP_BLOB"),
		TRUE
	}
};


inline LPCTSTR GetTypeNameFromType(SOAP_TYPE type)
{
	LPCTSTR szRet = "";
	int nIndex, nSize;

	nSize = sizeof(arSOAPTypes)/sizeof(arSOAPTypes[0]);
	for( nIndex = 0; nIndex < nSize; nIndex ++)
	{
		if(type == arSOAPTypes[nIndex].type)
		{
			szRet = arSOAPTypes[nIndex].szTypeName;
			break;
		}
	}
	return szRet;
}


inline HTTP_CODE IsTypeUsingHeap(SOAP_TYPE type)
{
	BOOL	hRet = HTTP_S_FALSE;
	int nIndex, nSize;

	nSize = sizeof(arSOAPTypes)/sizeof(arSOAPTypes[0]);
	for( nIndex = 0; nIndex < nSize; nIndex ++)
	{
		if(type == arSOAPTypes[nIndex].type)
		{
			if( arSOAPTypes[nIndex].bNeedsMemoryAllocation )
			{
				hRet = HTTP_SUCCESS;
			}
			break;
		}
	}
	return hRet;
}

inline LPCTSTR GetDirectionNameFromDirection(SOAP_PARAM_DIRECTION dir)
{
	LPCTSTR szRet = "";
	static LPCTSTR szIn = _T("in");
	static LPCTSTR szOut = _T("out");
	static LPCTSTR szInOut = _T("in, out");
	
	switch(dir)
	{
	case SOAP_DIRECTION_IN:
		szRet = szIn;
		break;
	case SOAP_DIRECTION_OUT:
		szRet = szOut;
		break;
	case SOAP_DIRECTION_INOUT:
		szRet = szInOut;
		break;
	}

	return szRet;
}



#endif //SOAPWIZARD_H_INCLUDED
