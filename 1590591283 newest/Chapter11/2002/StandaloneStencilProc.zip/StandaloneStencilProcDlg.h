// StandaloneStencilProcDlg.h : header file
//

#pragma once


// CStandaloneStencilProcDlg dialog
class CStandaloneStencilProcDlg : public CDHtmlDialog
{
// Construction
public:
	CStandaloneStencilProcDlg(CSoapService& service, CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	CString	m_strServiceLocation;

	enum { IDD = IDD_STANDALONESTENCILPROC_DIALOG, IDH = IDR_HTML_STANDALONESTENCILPROC_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	HRESULT OnButtonGenerate(IHTMLElement *pElement);
	HRESULT OnButtonCancel(IHTMLElement *pElement);
	HRESULT OnBrowse(IHTMLElement *phtmlElement);
	HRESULT OnButtonAddWebMethod(IHTMLElement *pElement);
	HRESULT OnClickDelete(IHTMLElement *phtmlElement);
	HRESULT OnClickLink(IHTMLElement *phtmlElement);


// Implementation
	
protected:
	HICON m_hIcon;

	CSoapService&			m_service;

	void					RefreshContent();
	void					UpdateContent(BOOL	bSave = TRUE);


	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()

protected:
	BOOL	ValidateContent();
	BOOL	GenerateOutput();
	BOOL	IsValidCPPId(CString& str, LPCTSTR strErrorLabel);
};
