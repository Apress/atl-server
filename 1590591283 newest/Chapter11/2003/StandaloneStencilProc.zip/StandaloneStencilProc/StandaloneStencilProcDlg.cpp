// StandaloneStencilProcDlg.cpp : implementation file
//

#include "stdafx.h"
#include "StandaloneStencilProc.h"
#include "StandaloneStencilProcDlg.h"
#include "SoapMethodDlg.h"

#include "ContentGenerator.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CStandaloneStencilProcDlg dialog

BEGIN_DHTML_EVENT_MAP(CStandaloneStencilProcDlg)
	DHTML_EVENT_ONCLICK(_T("ButtonBrowse"), OnBrowse)
	DHTML_EVENT_ONCLICK(_T("ButtonGenerate"), OnButtonGenerate)
	DHTML_EVENT_ONCLICK(_T("ButtonCancel"), OnButtonCancel)
	DHTML_EVENT_ONCLICK(_T("ButtonAddWebMethod"), OnButtonAddWebMethod)

	DHTML_EVENT_CLASS(DISPID_HTMLELEMENTEVENTS_ONCLICK, _T("command"),  OnClickDelete)
	DHTML_EVENT_CLASS(DISPID_HTMLELEMENTEVENTS_ONCLICK, _T("link"),  OnClickLink)
END_DHTML_EVENT_MAP()


CStandaloneStencilProcDlg::CStandaloneStencilProcDlg(CSoapService& service, CWnd* pParent /*=NULL*/)
	: CDHtmlDialog(CStandaloneStencilProcDlg::IDD, CStandaloneStencilProcDlg::IDH, pParent), m_service(service)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CStandaloneStencilProcDlg::DoDataExchange(CDataExchange* pDX)
{
	CDHtmlDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStandaloneStencilProcDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CStandaloneStencilProcDlg, CDHtmlDialog)
	ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CStandaloneStencilProcDlg message handlers

BOOL CStandaloneStencilProcDlg::OnInitDialog()
{
	// Add "About..." menu item to system menu.
	SetHostFlags(DOCHOSTUIFLAG_NO3DBORDER);

	CDHtmlDialog::OnInitDialog();


	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CStandaloneStencilProcDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDHtmlDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CStandaloneStencilProcDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDHtmlDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStandaloneStencilProcDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
HRESULT CStandaloneStencilProcDlg::OnButtonGenerate(IHTMLElement* /*pElement*/)
{
	CWaitCursor	waitCursor;
	UpdateContent();
	if( ValidateContent() )
	{
		if( GenerateOutput() )
		{
			CString	strMessage;
			strMessage.Format(_T("Web Service %s successfully generated in %s\n") 
				_T("To run the web service, execute the following steps:\n")
				_T("1) Open the solution in Visual Studio :\n")
				_T("2) Build the %sServer project :\n")
				_T("3) In the %sClient project, select the %sServerService.wsdl file\n")
				_T("4) In the context menu, select Update  Web Reference, to run the sproxy.exe tool\n")
				_T("5) Build and run the %sClient project\n"),
				m_service.m_strName,
				m_strServiceLocation,
				m_service.m_strName,
				m_service.m_strName,m_service.m_strName,
				m_service.m_strName);
			AfxMessageBox( strMessage, MB_OK | MB_ICONEXCLAMATION);

			OnOK();
			return S_OK;
		}
	}
	return S_FALSE;


	
}

HRESULT CStandaloneStencilProcDlg::OnButtonCancel(IHTMLElement* /*pElement*/)
{
	OnCancel();
	return S_OK;
}

HRESULT CStandaloneStencilProcDlg::OnButtonAddWebMethod(IHTMLElement* /*pElement*/)
{

	UpdateContent();
	
	CSoapMethod* pMethod = new CSoapMethod;
	pMethod->m_strName = "[New Method]";

	CSoapMethodDlg	dlg;
	dlg.m_pMethod = pMethod;
	if( IDOK == dlg.DoModal() )
	{
		m_service.m_arrMethods.Add( pMethod);
	}
	else
	{
		delete pMethod;
	}
	UpdateContent(FALSE);

	return S_OK;
}






HRESULT CStandaloneStencilProcDlg::OnBrowse(IHTMLElement* /*phtmlElement*/)
{
	BROWSEINFO bi;
	TCHAR szDisplayName[MAX_PATH];
	memset(&bi, 0x00, sizeof(bi));
	bi.hwndOwner = m_hWnd;
	bi.pszDisplayName = szDisplayName;
	bi.ulFlags = BIF_RETURNONLYFSDIRS;
	LPITEMIDLIST pidl = SHBrowseForFolder(&bi);
	if (pidl)
	{
		SHGetPathFromIDList(pidl, szDisplayName);
		UpdateContent();
		m_strServiceLocation = szDisplayName;
		UpdateContent(FALSE);

		// free the pidl
		CComPtr<IMalloc> spSHMalloc;
		SHGetMalloc(&spSHMalloc);
		if (spSHMalloc != NULL)
			spSHMalloc->Free(pidl);
	}

	return S_OK;
}




HRESULT CStandaloneStencilProcDlg::OnClickDelete(IHTMLElement *phtmlElement)
{
	CComBSTR bstr;
	phtmlElement->get_id(&bstr);
	LPSTR	pCurr = CW2A(bstr);
	ASSERT( strlen(pCurr) >= 4 );

	pCurr += 3;
	unsigned int nIndex = atoi(pCurr );
	if( nIndex < m_service.m_arrMethods.GetCount() )
	{
		CSoapMethod* pMethod = m_service.m_arrMethods[nIndex];
		ASSERT(pMethod);
		CString		strMsg;
		strMsg.Format(_T("Do you really want to delete method %s?"), pMethod->m_strName);
		if( IDOK == AfxMessageBox(strMsg, MB_OKCANCEL) )
		{
			m_service.m_arrMethods.RemoveAt(nIndex);
			delete pMethod;
			UpdateContent(FALSE);
		}
	}

	return S_OK;
}

HRESULT CStandaloneStencilProcDlg::OnClickLink(IHTMLElement *phtmlElement)
{
	CComBSTR bstr;
	phtmlElement->get_id(&bstr);
	


	phtmlElement->get_id(&bstr);
	LPSTR	pCurr = CW2A(bstr);
	ASSERT( strlen(pCurr) >= 4 );

	pCurr += 3;
	unsigned int nIndex = atoi(pCurr );
	if( nIndex < m_service.m_arrMethods.GetCount() )
	{
		CSoapMethod* pMethod = new CSoapMethod;
		pMethod->Assign(*m_service.m_arrMethods[nIndex]);

		CSoapMethodDlg	dlg;
		dlg.m_pMethod = pMethod;
		if( IDOK == dlg.DoModal() )
		{
			m_service.m_arrMethods[nIndex]->Assign(*pMethod);
		}
		delete pMethod;
	}
	UpdateContent(FALSE);
	
	return S_OK;
}


void CStandaloneStencilProcDlg::UpdateContent(BOOL	bSave)
{

	CComPtr<IHTMLInputElement>	spServiceName;
	GetElementInterface(_T("EditServiceName"), IID_IHTMLInputElement, (void **) &spServiceName);
	if( spServiceName )
	{
		BSTR bstrTemp;
		if( bSave )
		{
			spServiceName->get_value( &bstrTemp);
			m_service.m_strName = bstrTemp;
		}
		else
		{
			bstrTemp = m_service.m_strName.AllocSysString();
			spServiceName->put_value( bstrTemp);
		}
		SysFreeString(bstrTemp);
	}


	CComPtr<IHTMLInputElement>	spServiceLocation;
	GetElementInterface(_T("EditServiceLocation"), IID_IHTMLInputElement, (void **) &spServiceLocation);
	if( spServiceLocation)
	{
		BSTR bstrTemp;
		if( bSave )
		{
			spServiceLocation->get_value( &bstrTemp);
			m_strServiceLocation = bstrTemp;
		}
		else
		{
			bstrTemp = m_strServiceLocation.AllocSysString();
			spServiceLocation->put_value( bstrTemp);
		}
		SysFreeString(bstrTemp);
	}


	if( !bSave )
	{
		RefreshContent();
	}

}

void CStandaloneStencilProcDlg::RefreshContent()
{
	CString strTable;

	
	strTable =	
		_T("<table id=TableSoapMethods width=90% border=3>\n")
		_T("<tr>")
		_T("<td align=center><font color=00007f>Web Method Name</font></td>")
		_T("<td align=center><font color=00007f>Web Method Params</font></td></td>");

	// recreate the filelist table
	CComPtr<IHTMLElement> spDivSoapMethods;
	GetElementInterface(_T("SoapMethods"), IID_IHTMLElement, (void **) &spDivSoapMethods);
	
	if (spDivSoapMethods == NULL)
		return;

	CWaitCursor cur;
	CString str;

	 

	for( unsigned int nIndex = 0; nIndex < m_service.m_arrMethods.GetCount(); nIndex ++)
	{
		
		CSoapMethod* pMethod = m_service.m_arrMethods[nIndex];
		ASSERT(pMethod);
		str.Format(_T("<tr>")
				   _T("<td><img id=Del%d class=\"command\" src=\"PNG/DeleteBtn.png\"/>")
				   _T("<SPAN class=\"link\" id=Met%d>%s</SPAN></td>")
				   _T("<td>%s</td></tr>"), 
				   nIndex,
				   nIndex,
				   pMethod->m_strName,
				   pMethod->m_strParamDisplayString);
		strTable += str;
	}

	strTable += _T("</TABLE>");
	BSTR bstrTable = strTable.AllocSysString();
	spDivSoapMethods->put_innerHTML(bstrTable);
	SysFreeString(bstrTable);
}






////////////////////////////////////////////////////////////////////////////////////////////
//
//			STAND ALONE STENCIL PROCESSOR SAMPLE CODE STARTS HERE
//
////////////////////////////////////////////////////////////////////////////////////////////

/*
	ValidateContent	
	- ensures that the web service location is a valid directory
	(either exists or can be created)
	- ensures that the web service name is not empty and is a valid C++ identifier
	- ensures that all the methods and parrameter names are valid C++ identifiers
	- IT DOES NOT CHECKS WHETHER THE METHOD NAMES ARE UNIQUE
	- IT DOES NOT CHECKS WHETHER THE PARAMETER NAMES ARE UNIQUE

*/
BOOL	CStandaloneStencilProcDlg::ValidateContent()
{
	if( !IsValidCPPId(m_service.m_strName, _T("Service Name") ) )
	{
		return FALSE;
	}

	BOOL	bRet = CreateDirectoryRec(m_strServiceLocation);
	if( !bRet )
	{
		AfxMessageBox(_T("Cannot create destination directory"), MB_ICONERROR|MB_OK);
		return FALSE;
	}
	
	size_t nCount, nIndex;

	nCount = m_service.m_arrMethods.GetCount();

	if( nCount == 0 )
	{
		AfxMessageBox(_T("Cannot generate a Web Service with no methods"), MB_ICONERROR|MB_OK);
		return FALSE;
	}

	
	for( nIndex = 0; nIndex < nCount; nIndex ++ )
	{
		CString strErrorLabel;
		CSoapMethod*	pMethod = m_service.m_arrMethods[nIndex];
		ASSERT(pMethod);
		
		strErrorLabel = _T("Method ") + m_service.m_arrMethods[nIndex]->m_strName;

		if( !IsValidCPPId(pMethod->m_strName, strErrorLabel ))
		{
			return FALSE;
		}

		size_t jCount, jIndex;
		for( jIndex = 0, jCount = pMethod->m_arrParams.GetCount(); jIndex < jCount; jIndex ++)
		{
			CSoapMethodParam*	pParam = pMethod->m_arrParams[jIndex];
			strErrorLabel = _T("Method ") + pMethod->m_strName;
			strErrorLabel += _T(", Param ") + pParam->m_strParamName;

			if( !IsValidCPPId(pParam->m_strParamName, strErrorLabel ))
			{
				return FALSE;
			}
		}
	}

	return TRUE;

}

BOOL	CStandaloneStencilProcDlg::IsValidCPPId(CString& str,  LPCTSTR strErrorLabel)
{
	BOOL	bRet = TRUE;
	ASSERT( strErrorLabel );
	bRet = str.GetLength() > 0;

	for( int nIndex = 0; nIndex <  str.GetLength(); nIndex ++)
	{
		if( !__iscsym(str.GetAt(nIndex) ) )
		{
			bRet = FALSE;
			break;

		}
	}

	if( !bRet )
	{
		CString strError;
		strError = strErrorLabel;
		strError += _T(" is not a valid CPP identifier.\n");
		strError += _T("A valid CPP identifier is not empty \nand contains only letters, digits or underscore.");
		bRet = FALSE;
		AfxMessageBox( strError, MB_ICONERROR|MB_OK);
	}
	return bRet;
}


BOOL	CStandaloneStencilProcDlg::GenerateOutput()
{
	
	CContentGenerator	generator;
	BOOL				bRet = FALSE;


	generator.SetService( &m_service);
	generator.SetLocationFolder( m_strServiceLocation );
	generator.SetResourceInstance(AfxGetApp()->m_hInstance);
	bRet = generator.renderContent();

	return bRet;
}
