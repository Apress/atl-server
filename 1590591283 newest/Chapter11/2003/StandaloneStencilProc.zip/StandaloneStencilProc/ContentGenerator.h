#ifndef __CONTENTGENERATOR_H_INCLUDED
#define __CONTENTGENERATOR_H_INCLUDED

#include "SoapWizard.h"
#include <fstream>
using namespace std;



#define EnsureIndexIsValid(index, min, max)\
	if( (index < min) || (index >= max) )\
	{\
		m_strLastError.Format(_T("%s out of range\n"), #index);\
		return HTTP_FAIL;\
	}\
	
/*
	Implementation of the IWriteStream interface.
	It is used by the Stencil processorto generate content
	This implementation generates content to a specified file
	Different implementation could :
	- write in a socket (See ATL Server's default implementation)
	- display on the screen
	- write in a pipe
	etc.
*/
class CWriteStreamOnFile : public IWriteStream
{
protected:
	CString		m_strFileName;
	ofstream	out;
	BOOL		m_bOpened;

public:	
	CWriteStreamOnFile(LPCTSTR szOutFile)
	{
		m_strFileName = szOutFile;
		m_bOpened = FALSE;
	}
	
	
	~CWriteStreamOnFile()
	{
		if( m_bOpened )
		{
			out.close();
		}
	}
	
	BOOL	Open()
	{
        out.open( m_strFileName, ios_base::out | ios_base::binary);
		m_bOpened = out.is_open();
		
		return m_bOpened;
	}

	
	HRESULT WriteStream(LPCSTR szOut, int nLen, DWORD *pdwWritten)
	{
		if( m_bOpened)
		{
			char	*buff	=	new char[nLen + 1];
			buff[nLen] = 0;
			memcpy( buff, szOut, nLen);
			out	<<	buff;
			delete[] buff;
			
			if( pdwWritten)
			{
				*pdwWritten = nLen;
			}
			return S_OK;
		}
		return E_FAIL;
	}
	
	HRESULT FlushStream()
	{
		return S_OK;
	}

	void operator	<< (LPCTSTR	strBuff)
	{
		if( m_bOpened )
		{
			if( strBuff != NULL )
			{
				WriteStream( strBuff, (int)_tcslen(strBuff), NULL);
			}
		}
	}

	void operator	<< (unsigned int nVal)
	{
		if( m_bOpened )
		{
			CString	strTmp;
			strTmp.Format(_T("%d"), nVal);
			WriteStream( strTmp.GetBuffer(), (int)strTmp.GetLength(), NULL);
		}
	}


	void operator	<< (CString& szBuff)
	{
		WriteStream( szBuff.GetBuffer(), szBuff.GetLength(), NULL);
	}

};


/*
	S(tand)A(lone)(Replacement)Handler
	This class implements the callbacks (replacement methods) that will
	generate the dynamic content of the SRFs
*/
class CSAHandler : 
	public ITagReplacerImpl<CSAHandler>
	// Inherit from ITagReplacerImpl to leverage the 
	// support for mapping macros
{
protected:
	CWriteStreamOnFile			*m_pStream;
	CSoapService				*m_pService;
	HINSTANCE					m_hResourceInst;
	

	// Variables used during content generation 
	
	// GUIDs for the Visual Studio projects and solution
	// NOTE: This part of the content generation just attempts to 
	// mimic the behavior of the Visual Studio .Net (R)  wizards in 
	// creating a solution. There is no warranty that this will work 
	// with any other version of VS. Actually, it is very likely it won't!
	GUID						m_slnClientGUID;
	GUID						m_slnServerGUID;


	// Index of the currently selected method
	unsigned int				m_nMethodIndex;
	// Index of the currently selected param (in the current method)
	unsigned int				m_nParamIndex;
	
	// temporary method object to be saved while re-ordering the parameters
	CSoapMethod					m_tmpMethod;
public:
	CString						m_strLastError;


	void						SetResourceModule(HINSTANCE hInst)
	{
		m_hResourceInst = hInst;
	}
	
public:
	virtual HRESULT STDMETHODCALLTYPE QueryInterface( 
			/* [in] */ REFIID riid,
			/* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject)
	{
		return E_NOTIMPL;
	}
	    
	virtual ULONG STDMETHODCALLTYPE AddRef( void)
	{
		return 0;
	}

	virtual ULONG STDMETHODCALLTYPE Release( void)
	{
		return 0;
	}

public:
	CSAHandler(CSoapService* 	pService)
	{
		m_pService = pService;
		m_pStream = NULL;
		
		// Create GUIDs for the Client and Server projects
		::CoCreateGuid(&m_slnClientGUID);
		::CoCreateGuid(&m_slnServerGUID);
	}

	
	
	bool	renderFile(LPCTSTR szSRFResource, CWriteStreamOnFile	*pStream)
	{
		// The main stencil processor 
		CStencil	stencil;
		HRESULT		hRet;
		bool		bRet	=	true;
		
		m_strLastError.Empty();
		m_nMethodIndex = -1;
		m_nParamIndex = -1;
		
		
		if( !pStream || !m_pService )
		{
			m_strLastError = _T("The stream cannot be null, the service cannot be null when calling renderFile\n");
			return false;
		}
		m_pStream	=	pStream;
	
		
		// Load the stencil from the file specified as parameter
		// Thsi call could be replaced with LoadFromFile, LoadFromResourceEx or LoadFromString
		hRet	=	stencil.LoadFromResource(m_hResourceInst, szSRFResource);
		if( !SUCCEEDED(hRet) )
		{
			m_strLastError = _T("Canot load stencil file\n");
			return false;
		}

		// Map the replacement tags to the replacement methods in this class
		bRet	=	stencil.ParseReplacements(this);
		if( !bRet )
		{
			m_strLastError = _T("Failed in parsing the replacements\n");
			return false;
		}
		
		// Syntactically check the tokenized stencil
		stencil.FinishParseReplacements();

		
		// Render the actual content to the stream
		hRet	=	stencil.Render(this, pStream);
		m_pStream	=	NULL;

		bRet	=	SUCCEEDED(hRet);
		
		return bRet;
	}

public:

	HTTP_CODE	OnSlnClientGUID()
	{
		return RenderGUID(m_slnClientGUID);
	}
	
	HTTP_CODE	OnSlnServerGUID()
	{
		return RenderGUID(m_slnServerGUID);
	}
	

	HTTP_CODE	OnProjectName()
	{
		(*m_pStream)	<<	m_pService->m_strName;
		return HTTP_SUCCESS;
	}


	HTTP_CODE	OnSelectNextMethod()
	{
		HRESULT	hRet;
		m_nMethodIndex++;
		
		if( m_nMethodIndex < m_pService->m_arrMethods.GetCount() )
		{
			hRet = HTTP_SUCCESS;
		}
		else
		{
			// Return failure, but reset the index for the 
			// next OnSelectNextMethod call
			m_nMethodIndex = -1;
			hRet = HTTP_S_FALSE;
		}
		m_nParamIndex = -1;
		return hRet;
	}


	HTTP_CODE	OnMethodName()
	{
		EnsureIndexIsValid(m_nMethodIndex, 0, m_pService->m_arrMethods.GetCount() );
		CSoapMethod*	pMethod = m_pService->m_arrMethods.GetAt(m_nMethodIndex);
		(*m_pStream)	<<	pMethod->m_strName;
		return HTTP_SUCCESS;
	}

	HTTP_CODE	OnMethodIndex()
	{
		EnsureIndexIsValid(m_nMethodIndex, 0, m_pService->m_arrMethods.GetCount() );
		(*m_pStream)	<<	(m_nMethodIndex + 1);
		return HTTP_SUCCESS;
	}


	HTTP_CODE	OnSelectNextParam()
	{
		EnsureIndexIsValid(m_nMethodIndex, 0, m_pService->m_arrMethods.GetCount() );
		CSoapMethod*	pMethod = m_pService->m_arrMethods.GetAt(m_nMethodIndex);

		HRESULT	hRet;
		m_nParamIndex++;

		if( m_nParamIndex < pMethod->m_arrParams.GetCount() )
		{
			hRet = HTTP_SUCCESS;
		}
		else
		{
			// Return failure, but reset the index for the 
			// next OnSelectNextParam call
			m_nParamIndex = -1;
			hRet = HTTP_S_FALSE;
		}
		return hRet;
	}


	// Example of using a replacement tag with parameters
	HTTP_CODE	OnParam(LPSTR	str)
	{
		HRESULT	hRet  = HTTP_SUCCESS;
		EnsureIndexIsValid(m_nMethodIndex, 0, m_pService->m_arrMethods.GetCount() );
		CSoapMethod*	pMethod = m_pService->m_arrMethods.GetAt(m_nMethodIndex);

		EnsureIndexIsValid(m_nParamIndex, 0, pMethod->m_arrParams.GetCount() );
		CSoapMethodParam*	pParam = pMethod->m_arrParams.GetAt(m_nParamIndex);

		ASSERT(pParam);
		ASSERT(str);

		
		if( strcmp(str, "Direction") == 0 )
		{
			(*m_pStream) << GetDirectionNameFromDirection( pParam->m_direction );
		}
		else if( strcmp(str, "Type") == 0 )
		{
			(*m_pStream) << GetTypeNameFromType( pParam->m_type);
		}
		else if( strcmp(str, "IsOut") == 0 )
		{
			hRet = (pParam->m_direction ==SOAP_DIRECTION_OUT||pParam->m_direction ==SOAP_DIRECTION_INOUT)?HTTP_SUCCESS:HTTP_S_FALSE;
		}
		else if( strcmp(str, "IsIn") == 0 )
		{
			hRet = (pParam->m_direction ==SOAP_DIRECTION_IN||pParam->m_direction ==SOAP_DIRECTION_INOUT)?HTTP_SUCCESS:HTTP_S_FALSE;
		}
		else if( strcmp(str, "IsInOut") == 0 )
		{
			hRet = (pParam->m_direction ==SOAP_DIRECTION_INOUT)?HTTP_SUCCESS:HTTP_S_FALSE;
		}
		else if( strcmp(str, "Name") == 0 )
		{
			(*m_pStream) << pParam->m_strParamName;
		}
		else if( strcmp(str, "IsLast") == 0 )
		{
			hRet = (m_nParamIndex == pMethod->m_arrParams.GetCount() - 1)?HTTP_SUCCESS:HTTP_S_FALSE;
		}
		else if( strcmp(str, "UsesHeap") == 0 )
		{
			hRet = IsTypeUsingHeap(pParam->m_type);
		}
		else if( strcmp(str, "IsStringType") == 0 )
		{
			hRet = (pParam->m_type == SOAP_TYPE_BSTR) ? HTTP_SUCCESS : HTTP_S_FALSE;
		}
		else if( strcmp(str, "IsBlobType") == 0 )
		{
			hRet = (pParam->m_type == SOAP_TYPE_BLOB) ? HTTP_SUCCESS : HTTP_S_FALSE;
		}
		else
		{
			// Cannot reach this
			hRet = HTTP_FAIL;
		}


		return hRet;
	}


	HTTP_CODE	OnDefaultValue(LPSTR	str)
	{
		HRESULT	hRet  = HTTP_SUCCESS;
		EnsureIndexIsValid(m_nMethodIndex, 0, m_pService->m_arrMethods.GetCount() );
		CSoapMethod*	pMethod = m_pService->m_arrMethods.GetAt(m_nMethodIndex);

		EnsureIndexIsValid(m_nParamIndex, 0, pMethod->m_arrParams.GetCount() );
		CSoapMethodParam*	pParam = pMethod->m_arrParams.GetAt(m_nParamIndex);

		ASSERT(pParam);
		ASSERT(str);

		
		if( strcmp(str, "currParam") == 0 )
		{
			// Render the default value associated with the type of the current parameter
			(*m_pStream) << RenderTypeDefaultValue(pParam->m_type);
		}
		else if( strcmp(str, "BLOB_Size") == 0 )
		{
			// Render the default BLOB size. It will be 10 by default
			if( pParam->m_type != SOAP_TYPE_BLOB )
			{
				hRet = HTTP_FAIL;
			}
			else
			{
				static LPCTSTR	szDefaultBlobSizeString = _T("10");
				(*m_pStream) << szDefaultBlobSizeString ;
			}
		}
		else if( strcmp(str, "BLOB_FillChar") == 0 )
		{
			// Render the default BLOB fill-in character. It will be 'a' by default
			if( pParam->m_type != SOAP_TYPE_BLOB )
			{
				hRet = HTTP_FAIL;
			}
			else
			{
				static LPCTSTR	szDefaultBlobFillInString = _T("'a'");
				(*m_pStream) << szDefaultBlobFillInString;
			}
		}
		else
		{
			// Should not reach this
			hRet = HTTP_FAIL;
		}


		return hRet;
	}


	// Parameters Reordering method
	/*
		These two methods might be a little confusing, so here is what happens:
		Assume that one writes a SOAP method ( on the server) with the following signature
		HRESULT MyFunction([out]int* nOut, [in]int nIn);

		The WSDL for the service will look like:
		<message name="MyFunctionIn">
			<part name="nIn" type="s:int"/>
		</message>
		<message name="MyFunctionOut">
			<part name="nOut" type="s:int"/>
		</message>

		The sproxy.exe tool will process the parameters in this exact order, generate (on the client side) 
		a method looking like:
		HRESULT MyFunction([in]int nIn, [out]int* nOut);

		So, the first function will move the IN or IN/OUT parameters at the beginning of the list
		and save the original permutation. Then, the second function will restore the original 
		permutation
	*/

	HTTP_CODE OnInternalOrderParametersINFirst()
	{
		EnsureIndexIsValid(m_nMethodIndex, 0, m_pService->m_arrMethods.GetCount() );
		CSoapMethod*	pMethod = m_pService->m_arrMethods.GetAt(m_nMethodIndex);
		m_tmpMethod.Assign(*pMethod);

		size_t	nLastINPos = 0;
		size_t	nIndex, nCount;

		nCount = pMethod->m_arrParams.GetCount();
		for( nIndex = 0; nIndex < nCount; nIndex ++ )
		{
			CSoapMethodParam*	pParam = pMethod->m_arrParams.GetAt(nIndex);
			// If it is IN, remove it from the array, then re-insert it at nLastINPos
			if( (pParam->m_direction == SOAP_DIRECTION_IN) || (pParam->m_direction == SOAP_DIRECTION_INOUT) )
			{
				pMethod->m_arrParams.RemoveAt( nIndex);
				pMethod->m_arrParams.InsertAt( nLastINPos++, pParam);
			}
		}
		return HTTP_SUCCESS;
	}

	HTTP_CODE OnInternalRestoreParametersOrder()
	{
		EnsureIndexIsValid(m_nMethodIndex, 0, m_pService->m_arrMethods.GetCount() );
		CSoapMethod*	pMethod = m_pService->m_arrMethods.GetAt(m_nMethodIndex);
		pMethod->Assign( m_tmpMethod);
		return HTTP_SUCCESS;
	}


	BEGIN_REPLACEMENT_METHOD_MAP(CSAHandler)
		REPLACEMENT_METHOD_ENTRY("SlnClientGUID", OnSlnClientGUID)
		REPLACEMENT_METHOD_ENTRY("SlnServerGUID", OnSlnServerGUID)
		REPLACEMENT_METHOD_ENTRY("ProjectName", OnProjectName)

		REPLACEMENT_METHOD_ENTRY("SelectNextMethod", OnSelectNextMethod)
		REPLACEMENT_METHOD_ENTRY("MethodName", OnMethodName)
		REPLACEMENT_METHOD_ENTRY("MethodIndex", OnMethodIndex)


		REPLACEMENT_METHOD_ENTRY("SelectNextParam", OnSelectNextParam)
		REPLACEMENT_METHOD_ENTRY_EX_STR("Param", OnParam)


		REPLACEMENT_METHOD_ENTRY("InternalOrderParametersINFirst", OnInternalOrderParametersINFirst)
		REPLACEMENT_METHOD_ENTRY("InternalRestoreParametersOrder", OnInternalRestoreParametersOrder)
		
		
		
		REPLACEMENT_METHOD_ENTRY_EX_STR("DefaultValue", OnDefaultValue)
	END_REPLACEMENT_METHOD_MAP()
	
protected:
	
	HTTP_CODE RenderGUID(GUID& guid)
	{
		CString 	rString; 
		static LPCTSTR 	szFormat = _T("{%08lX-%04X-%04x-%02X%02X-%02X%02X%02X%02X%02X%02X}");


		// format into destination 
		rString.Format(szFormat, 
			// first copy... 
			guid.Data1, guid.Data2, guid.Data3, 
			guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3], 
			guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7], 
			// second copy... 
			guid.Data1, guid.Data2, guid.Data3, 
			guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3], 
			guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]); 
	
		(*m_pStream)	<<	rString;
		return HTTP_SUCCESS;
	}


	// This method renders the default value for simple types
	LPCTSTR	RenderTypeDefaultValue(SOAP_TYPE type)
	{
		switch(type)
		{
		case	SOAP_TYPE_BOOL:
			{
				static LPCTSTR szDefaultBOOLValue = "true";
				return szDefaultBOOLValue;
			}
			break;
		case	SOAP_TYPE_CHAR:
			{
				static LPCTSTR szDefaultCHARValue = "'x'";
				return szDefaultCHARValue;
			}
			break;
		case	SOAP_TYPE_WCHAR_T:
			{
				static LPCTSTR szDefaultWCHAR_TValue = "0x1234";
				return szDefaultWCHAR_TValue;
			}
			break;
		case	SOAP_TYPE_INT8:
			{
				static LPCTSTR szDefaultINT8Value = "7";
				return szDefaultINT8Value;
			}
			break;
		case	SOAP_TYPE_UINT8:
			{
				static LPCTSTR szDefaultUINT8Value = "8";
				return szDefaultUINT8Value;
			}
			break;
		case	SOAP_TYPE_INT16:
			{
				static LPCTSTR szDefaultINT16Value = "15";
				return szDefaultINT16Value;
			}
			break;
		case	SOAP_TYPE_UINT16:
			{
				static LPCTSTR szDefaultUINT16Value = "16";
				return szDefaultUINT16Value;
			}
			break;
		case	SOAP_TYPE_INT32:
			{
				static LPCTSTR szDefaultINT32Value = "31";
				return szDefaultINT32Value;
			}
			break;
		case	SOAP_TYPE_UINT32:
			{
				static LPCTSTR szDefaultUINT32Value = "32";
				return szDefaultUINT32Value;
			}
			break;
		case	SOAP_TYPE_INT64:
			{
				static LPCTSTR szDefaultINT64Value = "63";
				return szDefaultINT64Value;
			}
			break;
		case	SOAP_TYPE_UINT64:
			{
				static LPCTSTR szDefaultUINT64Value = "64";
				return szDefaultUINT64Value;
			}
			break;
		case	SOAP_TYPE_DOUBLE:
			{
				static LPCTSTR szDefaultDOUBLEValue = "123.456";
				return szDefaultDOUBLEValue;
			}
			break;
		case	SOAP_TYPE_FLOAT:
			{
				static LPCTSTR szDefaultFLOATValue = "(float)0.123";
				return szDefaultFLOATValue;
			}
			break;
		case	SOAP_TYPE_BSTR:
			{
				static LPCTSTR szDefaultBSTRValue = "TestStringValue";
				return szDefaultBSTRValue;
			}
			break;
		case	SOAP_TYPE_BLOB:
		default:
			{
				static LPCTSTR szError = "NOT A VALID TYPE";
				return szError;
			}
		}
	}

};


// Array of template files to be rendered 
// All the names are relative to the "Templates" folder
static LPCTSTR 	arSRFResources[] = 
{
	_T("Template.sln"),
	_T("TemplateClient\\stdafx.cpp"),
	_T("TemplateClient\\stdafx.h"),
	_T("TemplateClient\\TemplateClient.cpp"),
	_T("TemplateClient\\TemplateClient.vcproj"),
	_T("TemplateServer\\resource.h"),
	_T("TemplateServer\\StdAfx.cpp"),
	_T("TemplateServer\\StdAfx.h"),
	_T("TemplateServer\\TemplateServer.cpp"),
	_T("TemplateServer\\TemplateServer.def"),
	_T("TemplateServer\\TemplateServer.disco"),
	_T("TemplateServer\\TemplateServer.h"),
	_T("TemplateServer\\TemplateServer.htm"),
	_T("TemplateServer\\TemplateServer.rc"),
	_T("TemplateServer\\TemplateServer.vcproj")
};


class CContentGenerator
{
	
protected:
	// The service to be rendered
	CSoapService*	m_pService;
	
	// The output directory
	CString			m_strOutDir;
	
	// The app instance that contains the resource SRFs
	HINSTANCE		m_hResourceInst;
	
	// The result solution complete path
	CString			m_strSolution;
public:
	CContentGenerator() : m_pService(NULL), m_hResourceInst(NULL){}
	
	// sets the service to be rendered
	void		SetService(CSoapService* pService)
	{
		m_pService = pService;
	}
	
	// sets the folder containing the templates
	void 		SetResourceInstance(HINSTANCE hInstance)
	{
		m_hResourceInst = hInstance;
	}
	
	// sets the destination folder
	void 		SetLocationFolder(LPCSTR szOutDir)
	{
		m_strOutDir = szOutDir;
	}
	
	
	bool		renderContent()
	{
	
		CSAHandler	handler(m_pService);
		CString		strSrfResource, strOutputFile;
		int			iSize, iIndex;
		
		if( !m_pService )
		{
			TRACE(_T("No service to render\n"));
			return false;
		}

		handler.SetResourceModule(this->m_hResourceInst);
		
		// Attempt to create the directories first
		CString	 strDir;
		
		strDir = m_strOutDir + _T("\\");
		strDir += m_pService->m_strName;
		strDir += _T("Client");
		if( !CreateDirectoryRec(strDir) )
		{
			TRACE(_T("Cannot create client directory: %s\n"), strDir);
		}
		
		strDir = m_strOutDir + _T("\\");
		strDir += m_pService->m_strName;
		strDir += _T("Server");
		if( !CreateDirectoryRec(strDir) )
		{
			TRACE(_T("Cannot create client directory: %s\n"), strDir);
		}
		
		
		iSize = sizeof(arSRFResources)/sizeof(arSRFResources[0]);

		// Rendering the files
		for(iIndex = 0; iIndex < iSize; iIndex ++)
		{
			CString		strFileName;
			
			strFileName = arSRFResources[iIndex];
			
			strSrfResource = 	strFileName;
			strSrfResource += 	_T(".srf");
			
			strFileName.Replace(_T("Template"), m_pService->m_strName);
			strOutputFile	=	m_strOutDir + _T("\\");
			strOutputFile += 	strFileName;

			CWriteStreamOnFile	stream(strOutputFile.GetBuffer());
			if( !stream.Open())
			{
				TRACE(_T("Cannot open file %s\n"),  strOutputFile);
				return false;
			}
			if( !handler.renderFile(strSrfResource, &stream))
			{
				TRACE(_T("Rendering failed. Last error: %s\n"),  handler.m_strLastError);
				return false;
			}
		}

		
		return true;
	}
};

#endif