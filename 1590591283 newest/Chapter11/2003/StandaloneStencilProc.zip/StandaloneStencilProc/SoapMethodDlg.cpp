// SoapMethodDlg.cpp : implementation file
//

#include "stdafx.h"
#include "StandaloneStencilProc.h"
#include "SoapMethodDlg.h"



// CSoapMethodDlg dialog

IMPLEMENT_DYNCREATE(CSoapMethodDlg, CDHtmlDialog)

CSoapMethodDlg::CSoapMethodDlg(CWnd* pParent /*=NULL*/)
	: CDHtmlDialog(CSoapMethodDlg::IDD, CSoapMethodDlg::IDH, pParent)
{
}

CSoapMethodDlg::~CSoapMethodDlg()
{
}

void CSoapMethodDlg::DoDataExchange(CDataExchange* pDX)
{
	CDHtmlDialog::DoDataExchange(pDX);
}

BOOL CSoapMethodDlg::OnInitDialog()
{
	SetHostFlags(DOCHOSTUIFLAG_NO3DBORDER);
	CDHtmlDialog::OnInitDialog();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

BEGIN_MESSAGE_MAP(CSoapMethodDlg, CDHtmlDialog)
END_MESSAGE_MAP()

BEGIN_DHTML_EVENT_MAP(CSoapMethodDlg)
	DHTML_EVENT_ONCLICK(_T("ButtonOK"), OnButtonOK)
	DHTML_EVENT_ONCLICK(_T("ButtonCancel"), OnButtonCancel)
	DHTML_EVENT_ONCLICK(_T("ButtonAddParam"), OnButtonAddParam)

	DHTML_EVENT_CLASS(DISPID_HTMLELEMENTEVENTS_ONCLICK, _T("command"),  OnClickCommand)
	DHTML_EVENT_CLASS(DISPID_HTMLELEMENTEVENTS_ONAFTERUPDATE, _T("sensitiveContent"),  OnSensitiveContentChanged)
	DHTML_EVENT_CLASS(DISPID_HTMLELEMENTEVENTS_ONFOCUSOUT, _T("sensitiveContent"),  OnSensitiveContentChanged)
	

END_DHTML_EVENT_MAP()


// CSoapMethodDlg message handlers

HRESULT CSoapMethodDlg::OnButtonOK(IHTMLElement* /*pElement*/)
{
	UpdateContent();
	OnOK();
	return S_OK;  // return TRUE  unless you set the focus to a control
}

HRESULT CSoapMethodDlg::OnButtonCancel(IHTMLElement* /*pElement*/)
{
	OnCancel();
	return S_OK;  // return TRUE  unless you set the focus to a control
}





HRESULT CSoapMethodDlg::OnClickCommand(IHTMLElement *phtmlElement)
{
	CComBSTR bstr;
	phtmlElement->get_id(&bstr);
	LPSTR	pCurr = CW2A(bstr);
	SysFreeString(bstr);
	ASSERT( strlen(pCurr) >= 4 );

	pCurr += 3;
	unsigned int nIndex = atoi(pCurr );
	if( nIndex < m_pMethod->m_arrParams.GetCount() )
	{
		CSoapMethodParam* pParam = m_pMethod->m_arrParams[nIndex];
		ASSERT(pParam);
		CString		strMsg;
		strMsg.Format(_T("Do you really want to delete param %s?"), pParam->m_strParamName);
		if( IDOK == AfxMessageBox(strMsg, MB_OKCANCEL) )
		{
			m_pMethod->m_arrParams.RemoveAt(nIndex);
			delete pParam;
			BuildMethodSignature();
			UpdateContent(FALSE);
		}
	}

	return S_OK;
}


HRESULT CSoapMethodDlg::OnButtonAddParam(IHTMLElement* /*pElement*/)
{

	UpdateContent();
	CSoapMethodParam	*pParam = new CSoapMethodParam;

	pParam->m_strParamName = _T("[New Param]");
	pParam->m_direction	= SOAP_DIRECTION_IN;
	pParam->m_type = SOAP_TYPE_BOOL;

	m_pMethod->AddParam(pParam);
	
	BuildMethodSignature();
	UpdateContent(FALSE);

	return S_OK;
}


void CSoapMethodDlg::UpdateContent(BOOL bSave)
{
	CComPtr<IHTMLInputElement> spMethodName;
	GetElementInterface(_T("EditMethodName"), IID_IHTMLInputElement, (void **) &spMethodName);
	if( spMethodName )
	{
		BSTR bstrTemp;
		if( bSave )
		{
			spMethodName->get_value(&bstrTemp);
			m_pMethod->m_strName = bstrTemp;
		}
		else
		{
			bstrTemp = m_pMethod->m_strName.AllocSysString();
			spMethodName->put_value(bstrTemp);
		}
		SysFreeString(bstrTemp);
	}

	if( bSave )
	{
		SaveContent();
	}
	else
	{
		RefreshContent();
	}

}

void CSoapMethodDlg::RefreshContent()
{
	CString strTable;

	ASSERT(m_pMethod);
	
	strTable =	
		_T("<table id=TableSoapMethodParams width=100% border=3>\n")
		_T("<thead><td><b>Name</b></td><td><b>Type</b></td><td><b>Direction</b></td></thead>");


	// recreate the filelist table
	CComPtr<IHTMLElement> spDivSoapMethods;
	GetElementInterface(_T("MethodParams"), IID_IHTMLElement, (void **) &spDivSoapMethods);
	
	if (spDivSoapMethods == NULL)
		return;

	CWaitCursor cur;
	CString str;

	for( unsigned int nIndex = 0; nIndex < m_pMethod->m_arrParams.GetCount(); nIndex ++)
	{
		
		CSoapMethodParam* pParam = m_pMethod->m_arrParams[nIndex];
		ASSERT(pParam);
		CString	strTypesHTML, strDirHTML;
		BuildDirectionsListFromSelection(pParam->m_direction, strDirHTML);
		BuildTypeListFromSelection(pParam->m_type, strTypesHTML);
		str.Format(_T("<tr>")
				   _T("<td><img id=Del%d class=command src=PNG/DeleteBtn.png>")
				   _T("<input class=sensitiveContent type=text id=Prm%d value=\"%s\" size=24 name=Prm%d /></td>")
				   _T("<td><select class=sensitiveContent id=Typ%d name=Typ%d>%s</select></td>")
				   _T("<td><select class=sensitiveContent id=Dir%d name=Dir%d>%s</select></td>"),
				   nIndex,
				   nIndex,
				   pParam->m_strParamName,
				   nIndex,

				   nIndex,
				   nIndex,
				   strTypesHTML,

				   nIndex,
				   nIndex,
				   strDirHTML);
		strTable += str;
	}

	strTable += _T("</TABLE>");
	BSTR bstrTable = strTable.AllocSysString();
	spDivSoapMethods->put_innerHTML(bstrTable);
	SysFreeString(bstrTable);

	RefreshMethodSignature();
	
}



void CSoapMethodDlg::SaveContent()
{
	size_t nCount=m_pMethod->m_arrParams.GetCount();
	unsigned int nIndex;
	for( nIndex = 0; nIndex < nCount; nIndex ++)
	{
		SaveParamContent(nIndex);
	}
	BuildMethodSignature();
}


void	CSoapMethodDlg::SaveParamContent(unsigned int nIndex)
{
	CSoapMethodParam	*pParam = m_pMethod->m_arrParams[nIndex];
	ASSERT(pParam);

	CComPtr<IHTMLInputElement> spCurrParamName;
	CComPtr<IHTMLSelectElement> spCurrParamType;
	CComPtr<IHTMLSelectElement> spCurrParamDirection;

	CString strID;

	strID.Format(_T("Prm%d"), nIndex);
	GetElementInterface(strID, IID_IHTMLInputElement, (void **) &spCurrParamName);
	if( spCurrParamName )
	{
		BSTR bstrName;
		if( SUCCEEDED(spCurrParamName->get_value(&bstrName)) )
		{
			pParam->m_strParamName = CW2A(bstrName);
		}
		SysFreeString(bstrName);
	}

	strID.Format(_T("Typ%d"), nIndex);
	GetElementInterface(strID, IID_IHTMLSelectElement, (void **) &spCurrParamType);
	if( spCurrParamType )
	{
		LONG lIndex;
		if( SUCCEEDED(spCurrParamType->get_selectedIndex(&lIndex)))
		{
			ASSERT(lIndex < sizeof(arSOAPTypes)/sizeof(stTypeDescriptor));
			pParam->m_type = arSOAPTypes[lIndex].type;
		}
	}

	strID.Format(_T("Dir%d"), nIndex);
	GetElementInterface(strID, IID_IHTMLSelectElement, (void **) &spCurrParamDirection);
	if( spCurrParamDirection )
	{
		LONG lIndex;
		if( SUCCEEDED(spCurrParamDirection->get_selectedIndex(&lIndex)))
		{
			switch(lIndex)
			{
			case 0:
				pParam->m_direction = SOAP_DIRECTION_IN;
				break;
			case 1:
				pParam->m_direction = SOAP_DIRECTION_OUT;
				break;
			case 2:
				pParam->m_direction = SOAP_DIRECTION_INOUT;
				break;
			}
		}
	}
}


void	CSoapMethodDlg::BuildTypeListFromSelection(SOAP_TYPE currType, CString& strOut)
{
	strOut.Empty();
	for( unsigned int nIndex = 0; nIndex < sizeof(arSOAPTypes)/sizeof(stTypeDescriptor); nIndex++)
	{
		CString strAppend;
		strAppend.Format(_T("<option %s value=%d>%s</option>\n"),
							(currType == arSOAPTypes[nIndex].type)?_T("selected"):_T(""),
							(int)arSOAPTypes[nIndex].type,
							arSOAPTypes[nIndex].szTypeName);
		strOut.Append( strAppend);
	}
}


void	CSoapMethodDlg::BuildDirectionsListFromSelection(SOAP_PARAM_DIRECTION currDir, CString& strOut)
{
	strOut.Empty();	

	strOut.Format(	_T("<option value=in %s>in</option>")
								_T("<option value=out %s>out</option>")
								_T("<option value=inout %s>in/out</option>"),
								(currDir == SOAP_DIRECTION_IN)?_T("selected"):_T(""),
								(currDir == SOAP_DIRECTION_OUT)?_T("selected"):_T(""),
								(currDir == SOAP_DIRECTION_INOUT)?_T("selected"):_T(""));
}

void CSoapMethodDlg::OnNavigateComplete(LPDISPATCH pDisp, LPCTSTR szUrl)
{
	CDHtmlDialog::OnNavigateComplete(pDisp, szUrl);
	UpdateContent(FALSE);
}



void	CSoapMethodDlg::BuildMethodSignature()
{
	size_t nCount = m_pMethod->m_arrParams.GetCount();
	m_pMethod->m_strParamDisplayString.Empty();
	size_t nIndex = 0;

	for( nIndex = 0; nIndex < nCount; nIndex ++)
	{
		CSoapMethodParam *pParam = m_pMethod->m_arrParams[nIndex];
		BOOL bPointer = FALSE;
		CString	 strAdd;
		if( nIndex > 0)
		{
			strAdd += _T(", ");
		}
		bPointer  =TRUE;
		switch(pParam->m_direction)
		{
			case SOAP_DIRECTION_IN:
				bPointer  =FALSE;
				strAdd += _T("[<b>in</b>] ");
				break;
			case SOAP_DIRECTION_OUT:
				strAdd += _T("[<b>out</b>] ");
				break;
			case SOAP_DIRECTION_INOUT:
				strAdd += _T("[<b>in, out</b>] ");
				break;
		}

		strAdd += _T("<font color=#0000ff>");
		for( int jIndex = 0; jIndex < sizeof(arSOAPTypes)/sizeof(stTypeDescriptor); jIndex++)
		{
			if( arSOAPTypes[jIndex].type == pParam->m_type )
			{
				strAdd += arSOAPTypes[jIndex].szTypeName;
				break;
			}
		}
		strAdd += _T("</font>");

		if( bPointer )
		{
			strAdd += _T("* ");
		}
		else
		{
			strAdd += _T(" ");
		}
		strAdd += pParam->m_strParamName;
		m_pMethod->m_strParamDisplayString.Append(strAdd);

	}
}


HRESULT CSoapMethodDlg::OnSensitiveContentChanged(IHTMLElement* pElement)
{
	BSTR bstr;
	pElement->get_id(&bstr);
	LPCSTR	strID = CW2A(bstr);
	SysFreeString(bstr);
	ASSERT( strlen(strID) > 3 );
	
	if( strcmp(strID, "EditMethodName") == 0 )
	{
		CComPtr<IHTMLInputElement> spMethodName;
		GetElementInterface(_T("EditMethodName"), IID_IHTMLInputElement, (void **) &spMethodName);
		if( spMethodName )
		{
			BSTR bstrTemp;
			spMethodName->get_value(&bstrTemp);
			m_pMethod->m_strName = bstrTemp;
			SysFreeString(bstrTemp);
		}
		return S_OK;
	}

	strID += 3;
	unsigned int nIndex = atoi(strID);

	if( nIndex < m_pMethod->m_arrParams.GetCount() )
	{
		SaveParamContent( nIndex );
		BuildMethodSignature();
		RefreshMethodSignature();
	}

	
	
	return S_OK;  // return TRUE  unless you set the focus to a control
}


void	CSoapMethodDlg::RefreshMethodSignature()
{
	CComPtr<IHTMLElement> spDivSignature;
	GetElementInterface(_T("signature"), IID_IHTMLElement, (void **) &spDivSignature);
	
	if (spDivSignature == NULL)
		return;
	BSTR bstrTemp = m_pMethod->m_strParamDisplayString.AllocSysString();
	spDivSignature->put_innerHTML(bstrTemp);
	SysFreeString(bstrTemp);
}
