// StandaloneStencilProc.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "StandaloneStencilProc.h"
#include "StandaloneStencilProcDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CStandaloneStencilProcApp

BEGIN_MESSAGE_MAP(CStandaloneStencilProcApp, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()


// CStandaloneStencilProcApp construction

CStandaloneStencilProcApp::CStandaloneStencilProcApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CStandaloneStencilProcApp object

CStandaloneStencilProcApp theApp;


// CStandaloneStencilProcApp initialization

BOOL CStandaloneStencilProcApp::InitInstance()
{
	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	AfxEnableControlContainer();


	CSoapService	service;
	CStandaloneStencilProcDlg dlg(service);

	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
