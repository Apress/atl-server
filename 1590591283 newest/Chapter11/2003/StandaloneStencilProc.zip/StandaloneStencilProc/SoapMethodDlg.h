#pragma once


// CSoapMethodDlg dialog

class CSoapMethodDlg : public CDHtmlDialog
{
	DECLARE_DYNCREATE(CSoapMethodDlg)

public:
	CSoapMethodDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSoapMethodDlg();
// Overrides
	HRESULT OnButtonOK(IHTMLElement *pElement);
	HRESULT OnButtonCancel(IHTMLElement *pElement);

// Dialog Data
	enum { IDD = IDD_SOAPMETHODDLG, IDH = IDR_HTML_SOAPMETHODDLG };


	HRESULT OnButtonAddParam(IHTMLElement *pElement);
	HRESULT OnClickCommand(IHTMLElement *phtmlElement);
	HRESULT OnSensitiveContentChanged(IHTMLElement *phtmlElement);

// Data
	CSoapMethod*		m_pMethod;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()


	void	UpdateContent(BOOL bSave = TRUE);

	void	RefreshContent();
	void	RefreshMethodSignature();

	void	SaveContent();
	void	SaveParamContent(unsigned int nIndex);

	void	BuildTypeListFromSelection(SOAP_TYPE currType, CString& strOut);
	void	BuildDirectionsListFromSelection(SOAP_PARAM_DIRECTION currDir, CString& strOut);

	void	BuildMethodSignature();

public:
	virtual void OnNavigateComplete(LPDISPATCH pDisp, LPCTSTR szUrl);
};
