#ifndef WORKINGTHREADPOOL_H_INCLUDED
#define WORKINGTHREADPOOL_H_INCLUDED


struct stResultDescriptor
{
	CStringA		strUserName;
	int				nAge;
	CStringA		strLocation;
	CStringA		strProduct;
};

typedef void (*JOB_COMPLETION_CALLBACK)(HRESULT hRet, stResultDescriptor& result);


struct stJobDescriptor
{
	CStringA					strUserName;
	JOB_COMPLETION_CALLBACK		pfnCompletionCallback;
};



class CSampleDatabaseWorker
{
public:
	typedef stJobDescriptor* RequestType;
	
	CSampleDatabaseWorker() throw()
	{
	}

	~CSampleDatabaseWorker() throw()
	{
	}

	virtual BOOL Initialize(void *pvParam) throw()
	{
		// Do any initialization here
		return TRUE;
	}

	virtual void Terminate(void* pvParam) throw()
	{
		// Do any cleanup here
	}

	void Execute(stJobDescriptor	*pRequestInfo, void *pvParam, OVERLAPPED *pOverlapped) throw()
	{
		static LPCSTR	arLocations[4] = 
		{
			"Redmond, WA",
			"Washington, DC",
			"Los Angeles, CA",
			"Boise, ID"
		};
		
		static LPCSTR	arProducts[5] = 
		{
			"Tape Recorder",
			"Sport shoes",
			"Pool Table",
			"Computer Speakers",
			"Soccer Ball"
		};
		

		ATLASSERT(pRequestInfo!=NULL);

		// Execute simulates a database query that takes 10 seconds to complete
		::Sleep(10000);

		// Then, simulates fetching the response from the database
		HRESULT					hrPseudoDBResult = S_OK;
		stResultDescriptor		result;

		// the user name is the same
		result.strUserName = pRequestInfo->strUserName;

		int nLetterSum = 0;
		for( int nIndex = 0; nIndex < pRequestInfo->strUserName.GetLength(); nIndex++)
		{
			nLetterSum += pRequestInfo->strUserName.GetAt( nIndex );
		}

		
		// Assume that the DB operation fails in some situations
		// For example, when letter sum divides by 13

		if( nLetterSum % 13 != 0)
		{
			// Generate the age by summing the letters and %100
			result.nAge = nLetterSum % 100;
			// Generate the location by picking one from an array of fixed locations (the Locations 'table')
			result.strLocation  = arLocations[nLetterSum%4];
			// Generate the product by picking one from an array of fixed products (the Products 'table')
			result.strProduct   = arProducts[nLetterSum%5];
			hrPseudoDBResult = S_OK;
		}
		else
		{
			hrPseudoDBResult = E_FAIL;
		}

		if( pRequestInfo->pfnCompletionCallback )
		{
			pRequestInfo->pfnCompletionCallback(hrPseudoDBResult, result);
		}
		delete pRequestInfo;
	}

};


typedef CThreadPool<CSampleDatabaseWorker>	CSampleProcessingPool;



#endif // WORKINGTHREADPOOL_H_INCLUDED