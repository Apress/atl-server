// StandAloneThreadpool.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "WorkingThreadPool.h"

void displayMenu()
{
	printf("Enter customer name, then <ENTER> to lookup, or 'Q' to quit:");
}

void	CompletionProc(HRESULT hRet, stResultDescriptor& result)
{
	if( SUCCEEDED(hRet) )
	{
		printf("\nLookup for %s SUCCEEDED:\n", result.strUserName);
		printf("\tAge: %d\n", result.nAge);
		printf("\tLocation: %s\n", result.strLocation);
		printf("\tProduct: %s\n", result.strProduct);
		printf("------------------\n\n");
	}
	else
	{
		printf("\nLookup for %s FAILED:\n", result.strUserName);
		printf("------------------\n\n");
	}
}




int _tmain(int argc, _TCHAR* argv[])
{
	CSampleProcessingPool	threadPool;

	
	// Initialize the tread pool to 4 threads per CPU
	threadPool.Initialize(0, -4);

	while(true)
	{
		char	line[81];
		displayMenu();
		gets(line);

		if( strlen(line) == 1 && (line[0] == 'q' || line[0] == 'Q'))
			break;
		
		stJobDescriptor	*pJobDesc = new stJobDescriptor;
		if( !pJobDesc )
		{
			printf("Memory allocation error -- Out of memory??\n");
			break;
		}
		pJobDesc->pfnCompletionCallback = CompletionProc;
		pJobDesc->strUserName = line;
		if( !threadPool.QueueRequest(pJobDesc) )
		{
			printf("An error occurred while attempting to post the Lookup job\n");
		}
		else
		{
			printf("Lookup job started...\n");
		}
	}

	printf("\n\nExiting application...");
	threadPool.Shutdown();

	return 0;
}

