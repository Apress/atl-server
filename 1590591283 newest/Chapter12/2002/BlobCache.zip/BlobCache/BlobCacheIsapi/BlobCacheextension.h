#pragma once

#include <atlisapi.h>

// CBlobCacheExtension - the ISAPI extension class
template <class ThreadPoolClass=CThreadPool<CIsapiWorker>, 
    class CStatClass=CNoRequestStats, 
    class HttpUserErrorTextProvider=CDefaultErrorProvider, 
    class WorkerThreadTraits=DefaultThreadTraits >
class CBlobCacheExtension : 
    public CIsapiExtension<ThreadPoolClass, 
        CStatClass, 
        HttpUserErrorTextProvider, 
        WorkerThreadTraits>
{

protected:

    typedef CIsapiExtension<ThreadPoolClass, 
        CStatClass, HttpUserErrorTextProvider, 
        WorkerThreadTraits> baseISAPI;
    typedef CWorkerThread<WorkerThreadTraits> WorkerThreadClass;

    // blob cache support
    CBlobCache<WorkerThreadClass, CStdStatClass > m_BlobCache;

public:

    BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer)
    {
        if (!baseISAPI::GetExtensionVersion(pVer))
        {
            return FALSE;
        }
        
        if (GetCriticalIsapiError() != 0)
        {
            return TRUE;
        }
        

        if (S_OK != m_BlobCache.Initialize(
            static_cast<IServiceProvider*>(this), &m_WorkerThread))
        {
            ATLTRACE("Blob cache service failed to initialize\n");
            TerminateExtension(0);
            return SetCriticalIsapiError(IDS_ATLSRV_CRITICAL_BLOBCACHEFAILED);
        }

        return TRUE;
    }

    BOOL TerminateExtension(DWORD dwFlags)
    {
        m_BlobCache.Uninitialize();
        BOOL bRet = baseISAPI::TerminateExtension(dwFlags);
        return bRet;
    }
    
    HRESULT STDMETHODCALLTYPE QueryService(REFGUID guidService, 
            REFIID riid, void** ppvObject)
    {
        if (InlineIsEqualGUID(guidService, IID_IMemoryCache))
            return m_BlobCache.QueryInterface(riid, ppvObject);
        return baseISAPI::QueryService(guidService, riid, ppvObject);
    }
}; // class CBlobCacheExtension