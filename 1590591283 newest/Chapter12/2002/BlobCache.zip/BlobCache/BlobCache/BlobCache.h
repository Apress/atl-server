// BlobCache.h : Defines the ATL Server request handler class
//
#pragma once

class CMemoryCacheClient :
    public IMemoryCacheClient
{
public:

    // IMemoryCacheClient
    STDMETHOD(QueryInterface)(REFIID riid, void **ppv)
    {
        if (!ppv)
            return E_POINTER;

        if (InlineIsEqualGUID(riid, __uuidof(IUnknown)) ||
            InlineIsEqualGUID(riid, __uuidof(IMemoryCacheClient)))
        {
            *ppv = static_cast<IMemoryCacheClient*>(this);
            return S_OK;
        }
        return E_NOINTERFACE;
    }

    STDMETHOD_(ULONG, AddRef)()
    {
        return 1;
    }

    STDMETHOD_(ULONG, Release)()
    {
        return 1;
    }

    STDMETHOD(Free)(const void *pData)
    {
        if (!pData)
            return E_POINTER;

        free(*((void **) pData));

        return S_OK;
    }
};

CMemoryCacheClient g_MemoryCacheClient;


[ request_handler("Default") ]
class CBlobCacheHandler 
{
private:
    // Put private members here
    // uncomment the service declaration(s) if you want to use
    // a service that was generated with your ISAPI extension

    // Blob cache support
    CComPtr<IMemoryCache> m_spBlobCache;

    const char * m_szWeather;
    DWORD m_dwSize;

protected:
    // Put protected members here

public:
    // Put public members here

    HTTP_CODE ValidateAndExchange()
    {
        // TODO: Put all initialization and validation code here
        
        // Set the content-type
        m_HttpResponse.SetContentType("text/html");

        // uncomment the service initialization(s) if you want to use
        // a service that was generated with your ISAPI extension
        

        // Get the IMemoryCache service from the ISAPI extension
        if (FAILED(m_spServiceProvider->QueryService(__uuidof(IMemoryCache), 
                        &m_spBlobCache)))
            return HTTP_FAIL;

        HCACHEITEM hEntry = NULL;

        // attempt to lookup the entry
        HRESULT hr = m_spBlobCache->LookupEntry("Weather_Today", &hEntry);
        if (FAILED(hr) || !hEntry)
        {
            
            // attempt to add the entry (just make it static data)
            static const char * const s_szWeather = "Sunny, 78 degrees F, No rain, Light wind";
            size_t nLen = strlen(s_szWeather);

            // allocate the data even though it's static, just to show how it would
            // be done if it were being retrieved dynamically
            char * szData = (char *)malloc(nLen+1);
            if (!szData)
                return HTTP_ERROR(500, ISE_SUBERR_OUTOFMEM);
            strcpy(szData, s_szWeather);

            // create the expires time (just make it 24 hours from now)
            CFileTime cftExpires = CFileTime::GetCurrentTime() + CFileTime::Day;
            hr = m_spBlobCache->Add(
                "Weather_Today",        // the key for the data
                szData,                 // the data
                (DWORD)nLen+1,            // the size of the data
                &cftExpires,            // the expiration time of the data
                m_hInstHandler,         // the DLL of the handler where the data lives (so the DLL will not be unloaded)
                &hEntry,                // the out parameter that points to the added data
                &g_MemoryCacheClient);  // the IMemoryCacheClient that will be used to free the data

            if (FAILED(hr) || !hEntry)
                return HTTP_FAIL;
        }

        hr = m_spBlobCache->GetData(hEntry, (void **)&m_szWeather, &m_dwSize);
        if (FAILED(hr) || !m_szWeather || m_dwSize == 0)
            return HTTP_FAIL;
        
        return HTTP_SUCCESS;
    }
 
protected:
    // Here is an example of how to use a replacement tag with the stencil processor
    [ tag_name(name="Hello") ]
    HTTP_CODE OnHello(void)
    {
        m_HttpResponse << "Hello World! <br>"
                          "Today's weather is : ";
        m_HttpResponse.WriteLen(m_szWeather, m_dwSize-1);

        return HTTP_SUCCESS;
    }
}; // class CBlobCacheHandler
