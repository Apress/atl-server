#pragma once

#include <atlisapi.h>

enum WIND_CONDITION { wcNone = 0, wcLight, wcBreezy, wcHurricane };
enum RAIN_CONDITION { rcNone = 0, rcLight, rcShowers, rcTorrential };

struct CWeatherData
{
    int nTemp;
    WIND_CONDITION eWind;
    RAIN_CONDITION eRain;
};

__interface ATL_NO_VTABLE __declspec(uuid("a69dda6f-59da-4ba3-84f8-38b8db65201c")) 
    IMemoryCacheEx : public IUnknown
{
    // IMemoryCache Methods
    STDMETHOD(Add)(int Key, CWeatherData* Data, DWORD dwSize, 
                FILETIME *pftExpireTime,
                HINSTANCE hInstClient, HCACHEITEM *phEntry,
                IMemoryCacheClient *pClient);

    STDMETHOD(LookupEntry)(int szKey, HCACHEITEM * phEntry);
    STDMETHOD(GetData)(const HCACHEITEM hEntry, CWeatherData **ppData, 
        DWORD *pdwSize) const;
    STDMETHOD(ReleaseEntry)(const HCACHEITEM hEntry);
    STDMETHOD(RemoveEntry)(const HCACHEITEM hEntry);
    STDMETHOD(RemoveEntryByKey)(int Key);

    STDMETHOD(Flush)();
};

template <
        class MonitorClass,
        class StatClass=CStdStatClass,
        class SyncObj=CComCriticalSection,
        class FlushClass=COldFlusher,
        class CullClass=CExpireCuller >
class CBlobCacheEx : public CMemoryCache<CWeatherData*, 
    StatClass, FlushClass, int, 
    CElementTraits<int>, SyncObj, CullClass>,
    public IMemoryCacheEx,
    public IMemoryCacheControl,
    public IMemoryCacheStats,
    public IWorkerThreadClient
{
    typedef CMemoryCache<CWeatherData*, StatClass, FlushClass, int, 
        CElementTraits<int>, SyncObj, CullClass> cacheBase;

    MonitorClass m_Monitor;

protected:
    HANDLE m_hTimer;

public:
    CBlobCacheEx() : m_hTimer(NULL)
    {
    }

    HRESULT Initialize(IServiceProvider *pProv)
    {
        HRESULT hr = cacheBase::Initialize(pProv);
        if (FAILED(hr))
            return hr;
        hr = m_Monitor.Initialize();
        if (FAILED(hr))
            return hr;
        return m_Monitor.AddTimer(ATL_BLOB_CACHE_TIMEOUT, 
            static_cast<IWorkerThreadClient*>(this), 
            (DWORD_PTR) this, &m_hTimer);
    }

    template <class ThreadTraits>
    HRESULT Initialize(IServiceProvider *pProv, 
        CWorkerThread<ThreadTraits> *pWorkerThread)
    {
        ATLASSERT(pWorkerThread);

        HRESULT hr = cacheBase::Initialize(pProv);
        if (FAILED(hr))
            return hr;

        hr = m_Monitor.Initialize(pWorkerThread);
        if (FAILED(hr))
            return hr;

        return m_Monitor.AddTimer(ATL_BLOB_CACHE_TIMEOUT, 
            static_cast<IWorkerThreadClient*>(this), 
            (DWORD_PTR) this, &m_hTimer);
    }

    HRESULT Execute(DWORD_PTR dwParam, HANDLE /*hObject*/)
    {
        CBlobCacheEx* pCache = (CBlobCacheEx*)dwParam;

        if (pCache)
            pCache->Flush();
        return S_OK;
    }

    HRESULT CloseHandle(HANDLE hObject)
    {
        ATLASSERT(m_hTimer == hObject);
        m_hTimer = NULL;
        ::CloseHandle(hObject);
        return S_OK;
    }

    ~CBlobCacheEx()
    {
        if (m_hTimer)
            m_Monitor.RemoveHandle(m_hTimer);
    }

    HRESULT Uninitialize()
    {
        if (m_hTimer)
        {
            m_Monitor.RemoveHandle(m_hTimer);
            m_hTimer = NULL;
        }
        m_Monitor.Shutdown();
        return cacheBase::Uninitialize();
    }
    // IUnknown methods
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void **ppv)
    {
        HRESULT hr = E_NOINTERFACE;
        if (!ppv)
            hr = E_POINTER;
        else
        {
            if (InlineIsEqualGUID(riid, __uuidof(IUnknown)) ||
                InlineIsEqualGUID(riid, __uuidof(IMemoryCacheEx)))
            {
                *ppv = (IUnknown *) (IMemoryCacheEx *) this;
                AddRef();
                hr = S_OK;
            }
            if (InlineIsEqualGUID(riid, __uuidof(IMemoryCacheStats)))
            {
                *ppv = (IUnknown *) (IMemoryCacheStats*)this;
                AddRef();
                hr = S_OK;
            }
            if (InlineIsEqualGUID(riid, __uuidof(IMemoryCacheControl)))
            {
                *ppv = (IUnknown *) (IMemoryCacheControl*)this;
                AddRef();
                hr = S_OK;
            }

        }
        return hr;
    }

    ULONG STDMETHODCALLTYPE AddRef()
    {
        return 1;
    }

    ULONG STDMETHODCALLTYPE Release()
    {
        return 1;
    }

    // IMemoryCache Methods
    HRESULT STDMETHODCALLTYPE Add(int Key, CWeatherData *Data, DWORD dwSize, 
        FILETIME *pftExpireTime, 
        HINSTANCE hInstClient,
        HCACHEITEM *phEntry,
        IMemoryCacheClient *pClient)
    {
        HRESULT hr = E_FAIL;
        //if it's a multithreaded cache monitor we'll let the monitor 
        //take care of cleaning up the cache so we don't overflow 
        // our configuration settings. if it's not a threaded cache monitor, 
        // we need to make sure we don't overflow the configuration settings 
        // by adding a new element
        if (m_Monitor.GetThreadHandle()==NULL)
        {
            if (!cacheBase::CanAddEntry(dwSize))
            {
                //flush the entries and check again to see if we 
                // can add
                cacheBase::FlushEntries();
                if (!cacheBase::CanAddEntry(dwSize))
                    return E_OUTOFMEMORY;
            }
        }
        _ATLTRY
        {
            hr = cacheBase::AddEntry(Key, Data, dwSize,
                pftExpireTime, hInstClient, pClient, phEntry);
            return hr;
        }
        _ATLCATCHALL()
        {
            return E_FAIL;
        }
    }

    // all other methods delegate to CacheBase or m_statObj

    HRESULT STDMETHODCALLTYPE LookupEntry(int Key, HCACHEITEM * phEntry)
    {
        return cacheBase::LookupEntry(Key, phEntry);
    }

    HRESULT STDMETHODCALLTYPE GetData(const HCACHEITEM hKey, 
        CWeatherData **ppData, DWORD *pdwSize) const
    {
        return cacheBase::GetEntryData(hKey, ppData, pdwSize);
    }

    HRESULT STDMETHODCALLTYPE ReleaseEntry(const HCACHEITEM hKey)
    {
        return cacheBase::ReleaseEntry(hKey);
    }

    HRESULT STDMETHODCALLTYPE RemoveEntry(const HCACHEITEM hKey)
    {
        return cacheBase::RemoveEntry(hKey);
    }

    HRESULT STDMETHODCALLTYPE RemoveEntryByKey(int Key)
    {
        return cacheBase::RemoveEntryByKey(Key);
    }

    HRESULT STDMETHODCALLTYPE Flush()
    {
        return cacheBase::FlushEntries();
    }


    HRESULT STDMETHODCALLTYPE SetMaxAllowedSize(DWORD dwSize)
    {
        return cacheBase::SetMaxAllowedSize(dwSize);
    }

    HRESULT STDMETHODCALLTYPE GetMaxAllowedSize(DWORD *pdwSize)
    {
        return cacheBase::GetMaxAllowedSize(pdwSize);
    }

    HRESULT STDMETHODCALLTYPE SetMaxAllowedEntries(DWORD dwSize)
    {
        return cacheBase::SetMaxAllowedEntries(dwSize);
    }

    HRESULT STDMETHODCALLTYPE GetMaxAllowedEntries(DWORD *pdwSize)
    {
        return cacheBase::GetMaxAllowedEntries(pdwSize);
    }

    HRESULT STDMETHODCALLTYPE ResetCache()
    {
        return cacheBase::ResetCache();
    }

    // IMemoryCacheStats methods
    HRESULT STDMETHODCALLTYPE ClearStats()
    {
        m_statObj.ResetCounters();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetHitCount(DWORD *pdwSize)
    {
        if (!pdwSize)
            return E_POINTER;
        *pdwSize = m_statObj.GetHitCount();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetMissCount(DWORD *pdwSize)
    {
        if (!pdwSize)
            return E_POINTER;
        *pdwSize = m_statObj.GetMissCount();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetMaxAllocSize(DWORD *pdwSize)
    {
        if (!pdwSize)
            return E_POINTER;
        *pdwSize = m_statObj.GetMaxAllocSize();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetCurrentAllocSize(DWORD *pdwSize)
    {
        if (!pdwSize)
            return E_POINTER;
        *pdwSize = m_statObj.GetCurrentAllocSize();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetMaxEntryCount(DWORD *pdwSize)
    {
        if (!pdwSize)
            return E_POINTER;
        *pdwSize = m_statObj.GetMaxEntryCount();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetCurrentEntryCount(DWORD *pdwSize)
    {
        if (!pdwSize)
            return E_POINTER;
        *pdwSize = m_statObj.GetCurrentEntryCount();
        return S_OK;
    }

}; // CBlobCacheEx

class CMemoryCacheClient :
    public IMemoryCacheClient
{
public:

    // IMemoryCacheClient
    STDMETHOD(QueryInterface)(REFIID riid, void **ppv)
    {
        if (!ppv)
            return E_POINTER;

        if (InlineIsEqualGUID(riid, __uuidof(IUnknown)) ||
            InlineIsEqualGUID(riid, __uuidof(IMemoryCacheClient)))
        {
            *ppv = static_cast<IMemoryCacheClient*>(this);
            return S_OK;
        }
        return E_NOINTERFACE;
    }

    STDMETHOD_(ULONG, AddRef)()
    {
        return 1;
    }

    STDMETHOD_(ULONG, Release)()
    {
        return 1;
    }

    STDMETHOD(Free)(const void *pData)
    {
        if (!pData)
            return E_POINTER;

        free(*((void **) pData));

        return S_OK;
    }
};

CMemoryCacheClient g_MemoryCacheClient;

// CMemoryCacheExtension - the ISAPI extension class
template <class ThreadPoolClass=CThreadPool<CIsapiWorker>, 
    class CStatClass=CNoRequestStats, 
    class HttpUserErrorTextProvider=CDefaultErrorProvider, 
    class WorkerThreadTraits=DefaultThreadTraits >
class CMemoryCacheExtension : 
    public CIsapiExtension<ThreadPoolClass, 
        CStatClass, 
        HttpUserErrorTextProvider, 
        WorkerThreadTraits>
{

protected:

    typedef CIsapiExtension<ThreadPoolClass, CStatClass, 
        HttpUserErrorTextProvider, 
        WorkerThreadTraits> baseISAPI;
    typedef CWorkerThread<WorkerThreadTraits> WorkerThreadClass;

    // blob cache support
    CBlobCacheEx<WorkerThreadClass, CStdStatClass > m_BlobCache;

public:

    BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer)
    {
        if (!baseISAPI::GetExtensionVersion(pVer))
        {
            return FALSE;
        }
        
        if (GetCriticalIsapiError() != 0)
        {
            return TRUE;
        }
        

        if (S_OK != m_BlobCache.Initialize(
            static_cast<IServiceProvider*>(this), &m_WorkerThread))
        {
            ATLTRACE("Blob cache service failed to initialize\n");
            TerminateExtension(0);
            return SetCriticalIsapiError(IDS_ATLSRV_CRITICAL_BLOBCACHEFAILED);
        }

        return TRUE;
    }

    BOOL TerminateExtension(DWORD dwFlags)
    {
        m_BlobCache.Uninitialize();
        BOOL bRet = baseISAPI::TerminateExtension(dwFlags);
        return bRet;
    }
    
    HRESULT STDMETHODCALLTYPE QueryService(REFGUID guidService, 
            REFIID riid, void** ppvObject)
    {
        if (InlineIsEqualGUID(guidService, __uuidof(IMemoryCacheEx)))
            return m_BlobCache.QueryInterface(riid, ppvObject);
        return baseISAPI::QueryService(guidService, riid, ppvObject);
    }
}; // class CMemoryCacheExtension