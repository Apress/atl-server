// MemoryCache.h : Defines the ATL Server request handler class
//
#pragma once

#include "..\memorycacheisapi\memorycacheextension.h"

[ request_handler("Default") ]
class CMemoryCacheHandler
{
private:
    // Put private members here
    // uncomment the service declaration(s) if you want to use
    // a service that was generated with your ISAPI extension

    // Blob cache support
    CComPtr<IMemoryCacheEx> m_spBlobCache;
    CWeatherData *m_pData;
    DWORD m_dwSize;

protected:
    // Put protected members here

public:
    // Put public members here

    HTTP_CODE ValidateAndExchange()
    {
        // TODO: Put all initialization and validation code here
        
        // Set the content-type
        m_HttpResponse.SetContentType("text/html");

        // uncomment the service initialization(s) if you want to use
        // a service that was generated with your ISAPI extension
        

        // Get the IMemoryCacheEx service from the ISAPI extension
        if (FAILED(m_spServiceProvider->QueryService(__uuidof(IMemoryCacheEx), 
                        &m_spBlobCache)))
            return HTTP_FAIL;

        SYSTEMTIME st;
        GetSystemTime(&st);

        HCACHEITEM hEntry = NULL;
        // attempt to lookup the entry
        HRESULT hr = m_spBlobCache->LookupEntry(st.wDayOfWeek, &hEntry);
        if (FAILED(hr) || !hEntry)
        {
            // attempt to add the entry (just make it static data)

            // array of day-of-week to weather struct mappings
            static const CWeatherData s_arrWeather[] = 
            {
                { 78, wcNone, rcShowers },
                { 81, wcLight, rcNone },
                { 65, wcBreezy, rcLight },
                { 85, wcHurricane, rcTorrential },
                { 72, wcLight, rcLight},
                { 60, wcNone, rcNone},
                { 100, wcBreezy, rcShowers }
            };

            // allocate the data even though it's static, 
            // just to show how it would
            // be done if it were being retrieved dynamically
            CWeatherData *pData = (CWeatherData *)malloc(sizeof(CWeatherData));
            if (!pData)
                return HTTP_ERROR(500, ISE_SUBERR_OUTOFMEM);
            *pData = s_arrWeather[st.wDayOfWeek];

            // create the expires time (just make it 24 hours from now)
            CFileTime cftExpires = CFileTime::GetCurrentTime() + CFileTime::Day;
            hr = m_spBlobCache->Add(
                st.wDayOfWeek,
                pData,
                (DWORD)sizeof(CWeatherData),
                &cftExpires,
                m_hInstHandler,
                &hEntry,
                &g_MemoryCacheClient);

            if (FAILED(hr) || !hEntry)
                return HTTP_FAIL;
        }

        hr = m_spBlobCache->GetData(hEntry, &m_pData, &m_dwSize);
        if (FAILED(hr) || !m_pData|| m_dwSize == 0)
            return HTTP_FAIL;
        
        return HTTP_SUCCESS;
    }
 
protected:
    // Here is an example of how to use a replacement 
    // tag with the stencil processor
    [ tag_name(name="Hello") ]
    HTTP_CODE OnHello(void)
    {
        static const char * const s_szWind[] = 
            {"None", "Light", "Breezy", "Hurricane" };
        static const char * const s_szRain[] = 
            {"None", "Light", "Showers", "Torrential" };
        m_HttpResponse << "Hello World! <br>"
                          "Today's weather is :<br>"
                          "Wind: " << s_szWind[m_pData->eWind] << "<br>"
                          "Rain: " << s_szRain[m_pData->eRain] << "<br>"
                          "Temp: " << m_pData->nTemp;

        return HTTP_SUCCESS;
    }
}; // class CMemoryCacheHandler
