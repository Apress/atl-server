// Fault1.h : Defines the ATL Server request handler class
//
#pragma once

namespace Fault1Service
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IFault1Service - web service interface declaration
//
[
	uuid("31F30250-D5BB-4022-B6E2-CEA65EC7B06D"), 
	object
]
__interface IFault1Service
{
	[id(1)] HRESULT FaultTest([in] BSTR bstrInput);
};


// Fault1Service - web service implementation
//
[
	request_handler(name="Default", sdl="GenFault1WSDL"),
	soap_handler(
		name="Fault1Service", 
		namespace="urn:Fault1Service",
		protocol="soap"
	)
]
class CFault1Service :
	public IFault1Service
{
private:

	bool IsInvalidArg(BSTR bstrInput)
	{
		bstrInput;
		return true;
	}

public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT FaultTest(/*[in]*/ BSTR bstrInput)
	{
		if (IsInvalidArg(bstrInput))
		{
			SoapFault(SOAP_E_SERVER, L"Invalid Argument", sizeof("Invalid Argument")-1);
			return E_INVALIDARG;
		}

		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CFault1Service

} // namespace Fault1Service
