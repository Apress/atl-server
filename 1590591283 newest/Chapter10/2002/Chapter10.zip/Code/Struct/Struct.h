// Struct.h : Defines the ATL Server request handler class
//
#pragma once

namespace StructService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

[ export ]
struct MyStruct
{
	[size_is(nSize)] int *arr;
	int nSize;
};

// IStructService - web service interface declaration
//
[
	uuid("4EA08537-12F7-4DC7-ABE5-483CFE0F4FE0"), 
	object
]
__interface IStructService
{
	[id(1)] HRESULT StructTest([in] MyStruct tIn, [out, retval] MyStruct *tOut);
};


// StructService - web service implementation
//
[
	request_handler(name="Default", sdl="GenStructWSDL"),
	soap_handler(
		name="StructService", 
		namespace="urn:StructService",
		protocol="soap"
	)
]
class CStructService :
	public IStructService
{
public:
	[ soap_method ]
	HRESULT StructTest(/*[in]*/ MyStruct tIn, /*[out, retval]*/ MyStruct *tOut)
	{
		// set the size of the array
		// tIn.nSize will contain the number of array elements marshaled
		tOut->nSize = tIn.nSize;
		tOut->arr = reinterpret_cast<int *>(GetMemMgr()->Allocate(tIn.nSize*sizeof(int)));
		if (!tOut->arr)
		{
			return E_OUTOFMEMORY;
		}
		for (int i=0; i<tIn.nSize; i++)
		{
			tOut->arr[i] = tIn.arr[i];
		}
		return S_OK;
	}
}; // class CStructService

} // namespace StructService
