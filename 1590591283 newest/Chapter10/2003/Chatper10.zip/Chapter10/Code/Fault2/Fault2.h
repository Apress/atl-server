// Fault2.h : Defines the ATL Server request handler class
//
#pragma once

namespace Fault2Service
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IFault2Service - web service interface declaration
//
[
	uuid("2E55C132-0E5A-4EE9-9CAA-0B4824738D6B"), 
	object
]
__interface IFault2Service
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT FaultTest([in] BSTR bstrInput);
	// TODO: Add additional web service methods here
};


// Fault2Service - web service implementation
//
[
	request_handler(name="Default", sdl="GenFault2WSDL"),
	soap_handler(
		name="Fault2Service", 
		namespace="urn:Fault2Service",
		protocol="soap"
	)
]
class CFault2Service :
	public IFault2Service
{
private:

	bool IsInvalidArg(BSTR bstrInput)
	{
		bstrInput;

		return true;
	}

public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT FaultTest(/*[in]*/ BSTR bstrInput)
	{
		if (IsInvalidArg(bstrInput))
		{
			CSoapFault fault;
			fault.m_soapErrCode = SOAP_E_CLIENT;
			fault.m_strDetail = L"Invalid Argument";
			fault.GenerateFault(m_pHttpResponse);

			return E_INVALIDARG;
		}
		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CFault2Service

} // namespace Fault2Service
