// Header1.h : Defines the ATL Server request handler class
//
#pragma once

namespace Header1Service
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IHeader1Service - web service interface declaration
//
[
	uuid("E8F59246-F4CB-4B8D-8F09-1F8C79F5A825"), 
	object
]
__interface IHeader1Service
{
	[id(1)] HRESULT HeaderMethod([out, retval] BSTR *ReturnValue);
};


// Header1Service - web service implementation
//
[
	request_handler(name="Default", sdl="GenHeader1WSDL"),
	soap_handler(
		name="Header1Service", 
		namespace="urn:Header1Service",
		protocol="soap"
	)
]
class CHeader1Service :
	public IHeader1Service
{
public:

	BSTR HeaderValue;

	[ soap_method ]
	[ soap_header(value="HeaderValue", required=false, in=true, out=false) ]
	HRESULT HeaderMethod(/*[out, retval]*/ BSTR *ReturnValue)
	{
		if (HeaderValue != NULL)
		{
			*ReturnValue = SysAllocString(HeaderValue);
		}
		else
		{
			*ReturnValue = NULL;
		}

		return S_OK;
	}
	
}; // class CHeader1Service

} // namespace Header1Service
