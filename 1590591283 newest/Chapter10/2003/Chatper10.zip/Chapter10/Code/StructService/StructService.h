// StructService.h : Defines the ATL Server request handler class
//
#pragma once

namespace StructServiceService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IStructServiceService - web service interface declaration
//
[
	uuid("4FD04F06-DACE-4B04-9C23-AC4E3C1D0A94"), 
	object
]
__interface IStructServiceService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT HelloWorld([in] BSTR bstrInput, [out, retval] BSTR *bstrOutput);
	// TODO: Add additional web service methods here
};


// StructServiceService - web service implementation
//
[
	request_handler(name="Default", sdl="GenStructServiceWSDL"),
	soap_handler(
		name="StructServiceService", 
		namespace="urn:StructServiceService",
		protocol="soap"
	)
]
class CStructServiceService :
	public IStructServiceService
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT HelloWorld(/*[in]*/ BSTR bstrInput, /*[out, retval]*/ BSTR *bstrOutput)
	{
		CComBSTR bstrOut(L"Hello ");
		bstrOut += bstrInput;
		bstrOut += L"!";
		*bstrOutput = bstrOut.Detach();
		
		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CStructServiceService

} // namespace StructServiceService
