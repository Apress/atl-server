// Enum.h : Defines the ATL Server request handler class
//
#pragma once

namespace EnumService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

[ export ]
enum MyEnum { Value1, Value2, Value3, Value4 };

// IEnumService - web service interface declaration
//
[
	uuid("A745E7CB-AD49-41EB-B36C-D533B812EC64"), 
	object
]
__interface IEnumService
{
	[id(1)] HRESULT TestEnum([in] MyEnum eIn, [out, retval] MyEnum *eOut);
};


// EnumService - web service implementation
//
[
	request_handler(name="Default", sdl="GenEnumWSDL"),
	soap_handler(
		name="EnumService", 
		namespace="urn:EnumService",
		protocol="soap"
	)
]
class CEnumService :
	public IEnumService
{
public:
	
	[ soap_method ]
	HRESULT TestEnum(/*[in]*/ MyEnum eIn, /*[out, retval]*/ MyEnum *eOut)
	{	
		if (eIn == Value4)
		{
			*eOut = Value1;
		}
		else
		{
			*eOut = (MyEnum)(eIn+1);
		}
		return S_OK;
	}
}; // class CEnumService

} // namespace EnumService
