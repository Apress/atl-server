// RestrictedTypes.h : Defines the ATL Server request handler class
//
#pragma once

namespace RestrictedTypesService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IRestrictedTypesService - web service interface declaration
//
[
	uuid("23E070EF-C8B5-4A0F-A299-FB50ABD6CD03"), 
	object
]
__interface IRestrictedTypesService
{
	[id(1)] HRESULT Illegal([in] BSTR **arrInput);
};


// RestrictedTypesService - web service implementation
//
[
	request_handler(name="Default", sdl="GenRestrictedTypesWSDL"),
	soap_handler(
		name="RestrictedTypesService", 
		namespace="urn:RestrictedTypesService",
		protocol="soap"
	)
]
class CRestrictedTypesService :
	public IRestrictedTypesService
{
public:
	
	[ soap_method ]
	HRESULT Illegal(/*[in]*/ BSTR **arrInput)
	{
		arrInput;
		return S_OK;
	}
}; // class CRestrictedTypesService

} // namespace RestrictedTypesService
