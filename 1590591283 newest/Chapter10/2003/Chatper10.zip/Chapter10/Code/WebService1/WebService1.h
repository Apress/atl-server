// WebService1.h : Defines the ATL Server request handler class
//
#pragma once

namespace WebService1Service
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

[ export ]
struct MyStruct
{
	BSTR strValue;
	int nValue;
};

// IWebService1Service - web service interface declaration
//
[
	uuid("A11625E1-420D-4BD1-9AD4-C8E743DEEDA1"), 
	object
]
__interface IWebService1Service
{
	[id(1)] HRESULT HelloWorld([in] BSTR bstrInput, [out, retval] BSTR *bstrOutput);
	[id(2)] HRESULT Test([in] MyStruct tIn, [out, retval] MyStruct *tOut);
};


// WebService1Service - web service implementation
//
[
	request_handler(name="Default", sdl="GenWebService1WSDL"),
	soap_handler(
		name="WebService1Service", 
		namespace="urn:WebService1Service",
		protocol="soap"
	)
]
class CWebService1Service :
	public IWebService1Service
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT HelloWorld(/*[in]*/ BSTR bstrInput, /*[out, retval]*/ BSTR *bstrOutput)
	{
		CComBSTR bstrOut(L"Hello ");
		bstrOut += bstrInput;
		bstrOut += L"!";
		*bstrOutput = bstrOut.Detach();
		
		return S_OK;
	}
	
	[ soap_method ]
	HRESULT Test(MyStruct tIn, MyStruct *tOut)
	{
		tOut->strValue = SysAllocString(tIn.strValue);
		tOut->nValue = tIn.nValue;
		return S_OK;
	}
}; // class CWebService1Service

} // namespace WebService1Service
