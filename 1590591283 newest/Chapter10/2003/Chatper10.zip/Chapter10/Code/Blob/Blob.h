// Blob.h : Defines the ATL Server request handler class
//
#pragma once

namespace BlobService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IBlobService - web service interface declaration
//
[
	uuid("41AF710A-EC7B-4FD5-B1C4-CBB58406AEF8"), 
	object
]
__interface IBlobService
{
	[id(1)] HRESULT BlobTest([in] ATLSOAP_BLOB blobIn, [out, retval] ATLSOAP_BLOB *blobOut);
};


// BlobService - web service implementation
//
[
	request_handler(name="Default", sdl="GenBlobWSDL"),
	soap_handler(
		name="BlobService", 
		namespace="urn:BlobService",
		protocol="soap"
	)
]
class CBlobService :
	public IBlobService
{
public:
	[ soap_method ]
	HRESULT BlobTest(/*[in]*/ ATLSOAP_BLOB blobIn, /*[out, retval]*/ ATLSOAP_BLOB *blobOut)
	{
		blobOut->size = blobIn.size;
		blobOut->data = reinterpret_cast<unsigned char *>(GetMemMgr()->Allocate(blobIn.size));
		memcpy(blobOut->data, blobIn.data, blobIn.size);
		return S_OK;
	}
}; // class CBlobService

} // namespace BlobService
