#define _WIN32_WINNT 0x0500

#include "WebService.h"

int main()
{
	CoInitialize(NULL);
	{
		WebService1Service::CWebService1Service svc;
		CComBSTR bstrOut;
		svc.HelloWorld(CComBSTR(L"Joe"), &bstrOut);
		printf("%ws\n", bstrOut);
		return 0;
	}
	CoUninitialize();
}