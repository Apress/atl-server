// ClientParams.h : Defines the ATL Server request handler class
//
#pragma once

[ request_handler("Default") ]
class CClientParamsHandler
{
private:
	// Put private members here

protected:
	// Put protected members here

public:
	// Put public members here

	HTTP_CODE ValidateAndExchange()
	{
		// TODO: Put all initialization and validation code here
		
		// Set the content-type
		m_HttpResponse.SetContentType("text/html");
		
		m_HttpResponse << "<html><body>";
		POSITION pos;
		LPCSTR	szName, szValue;

		m_HttpResponse << "<H1>Form Variables</H1><br>";
		pos = m_HttpRequest.GetFirstFormVar( &szName, &szValue);
		while( pos != NULL )
		{
			m_HttpResponse << szName << "=" << szValue << "<br>";
			pos = m_HttpRequest.GetNextFormVar(pos, &szName, &szValue);
		}

		m_HttpResponse << "<H1>Query Params </H1><br>";
		pos = m_HttpRequest.GetFirstQueryParam( &szName, &szValue);
		while( pos != NULL )
		{
			m_HttpResponse << szName << "=" << szValue << "<br>";
			pos = m_HttpRequest.GetNextQueryParam(pos, &szName, &szValue);
		}

		m_HttpResponse << "</body></html>";
		return HTTP_SUCCESS;
	}
}; // class CClientParamsHandler
