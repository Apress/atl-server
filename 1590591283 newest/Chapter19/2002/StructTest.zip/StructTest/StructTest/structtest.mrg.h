// Created by Microsoft (R) C/C++ Compiler Version 13.00.9466
//
// c:\dev\book\ws_chapter2\new\code\structtest\structtest\structtest.mrg.h
// compiler-generated file created 01/25/03 at 16:37:02
//
// This C++ source file is intended to be a representation of the
// source code injected by the compiler.  It may not compile or
// run exactly as the original source file.
//


//+++ Start Injected Code
[no_injected_text(true)];      // Suppress injected text, it has already been injected
#pragma warning(disable: 4543) // Suppress warnings about skipping injected text
#pragma warning(disable: 4199) // Suppress warnings from attribute providers

#pragma message("\n\nNOTE: This merged source file should be visually inspected for correctness.\n\n")
//--- End Injected Code

// StructTest.h : Defines the ATL Server request handler class
//
#pragma once

namespace StructTestService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

[ export ]
struct TestStruct
{
	int IntegerValue;
	BSTR StringValue;
};

// IStructTestService - web service interface declaration
//
[
	uuid("FFCF67A4-D9C9-4F54-BE04-E30A6B62E9C2"), 
	object
]
__interface IStructTestService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT StructTest([in] TestStruct InputStruct, [out, retval] TestStruct *OutputStruct);
	// TODO: Add additional web service methods here
};


// StructTestService - web service implementation
//
[
	request_handler(name="Default", sdl="GenStructTestWSDL"),
	soap_handler(
		name="StructTestService", 
		namespace="urn:StructTestService",
		protocol="soap"
	)
]
class CStructTestService :
	public IStructTestService
,
    /*+++ Added Baseclass */ public CSoapHandler<CStructTestService>
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT StructTest(/*[in]*/ TestStruct InputStruct, /*[out, retval]*/ TestStruct *OutputStruct)
	{
		OutputStruct->IntegerValue = InputStruct.IntegerValue;
		if (InputStruct.StringValue)
		{
			OutputStruct->StringValue = SysAllocString(InputStruct.StringValue);
			if (!OutputStruct->StringValue)
				return E_OUTOFMEMORY;
		}
		else
		{
			OutputStruct->StringValue = NULL;
		}

		return S_OK;
	}
	// TODO: Add additional web service methods here

	//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 35 "c:\\dev\\book\\ws_chapter2\\new\\code\\structtest\\structtest\\structtest.h"
    const _soapmap ** GetFunctionMap() throw();
    const _soapmap ** GetHeaderMap() throw();
    void * GetHeaderValue() throw();
    const wchar_t * GetNamespaceUri() throw();
    const char * GetNamespaceUriA() throw();
    const char * GetServiceName() throw();
    HRESULT CallFunction(void *pvParam, const wchar_t *wszLocalName, int cchLocalName, size_t nItem);

	//--- End Injected Code For Attribute 'soap_handler'
};

//+++ Start Injected Code For Attribute 'request_handler'
#injected_line 34 "c:\\dev\\book\\ws_chapter2\\new\\code\\structtest\\structtest\\structtest.h"

				
HANDLER_ENTRY_SDL("Default", CStructTestService, ::StructTestService::CStructTestService, GenStructTestWSDL)

			
//--- End Injected Code For Attribute 'request_handler'


//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 35 "c:\\dev\\book\\ws_chapter2\\new\\code\\structtest\\structtest\\structtest.h"
__if_not_exists(___StructTestService_TestStruct_entries)
    {
    extern __declspec(selectany) const _soapmapentry ___StructTestService_TestStruct_entries[] =
        {
        	{ 
        		0x8A8BD84B, 
        		"IntegerValue", 
        		L"IntegerValue", 
        		sizeof("IntegerValue")-1, 
        		SOAPTYPE_INT, 
        		SOAPFLAG_FIELD, 
        		offsetof(::StructTestService::TestStruct, IntegerValue),
        		NULL, 
        		NULL, 
        		0	},
        	{ 
        		0xE257E474, 
        		"StringValue", 
        		L"StringValue", 
        		sizeof("StringValue")-1, 
        		SOAPTYPE_STRING, 
        		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
        		offsetof(::StructTestService::TestStruct, StringValue),
        		NULL, 
        		NULL, 
        		0	},
        	{ 0x00000000 }
        };

    extern __declspec(selectany) const _soapmap ___StructTestService_TestStruct_map =
        {
        	0x15962585,
        	"TestStruct",
        	L"TestStruct",
        	sizeof("TestStruct")-1,
        	sizeof("TestStruct")-1,
        	SOAPMAP_STRUCT,
        	___StructTestService_TestStruct_entries,
        	sizeof(::StructTestService::TestStruct),
        	2,
        	-1,
        	SOAPFLAG_NONE,
        	0x57848C05,
        	"urn:StructTestService",
        	L"urn:StructTestService",
        	sizeof("urn:StructTestService")-1
        };
}

struct ___StructTestService_CStructTestService_StructTest_struct
    {
    ::StructTestService::TestStruct InputStruct;
    ::StructTestService::TestStruct OutputStruct;
};

extern __declspec(selectany) const _soapmapentry ___StructTestService_CStructTestService_StructTest_entries[] =
    {
    
    	{
    		0x7F3D7616, 
    		"OutputStruct", 
    		L"OutputStruct", 
    		sizeof("OutputStruct")-1, 
    		SOAPTYPE_UNK, 
    		SOAPFLAG_RETVAL | SOAPFLAG_OUT,
    		offsetof(___StructTestService_CStructTestService_StructTest_struct, OutputStruct),
    		NULL,
    		&___StructTestService_TestStruct_map,
    		-1,
    	},
    
    	{
    		0x5FF51735, 
    		"InputStruct", 
    		L"InputStruct", 
    		sizeof("InputStruct")-1, 
    		SOAPTYPE_UNK, 
    		SOAPFLAG_NONE | SOAPFLAG_IN,
    		offsetof(___StructTestService_CStructTestService_StructTest_struct, InputStruct),
    		NULL,
    		&___StructTestService_TestStruct_map,
    		-1,
    	},
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___StructTestService_CStructTestService_StructTest_map =
    {
    	0x6AD07005,
    	"StructTest",
    	L"StructTest",
    	sizeof("StructTest")-1,
    	sizeof("StructTest")-1,
    	SOAPMAP_FUNC,
    	___StructTestService_CStructTestService_StructTest_entries,
    	sizeof(___StructTestService_CStructTestService_StructTest_struct),
    	1,
    	0,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0x57848C05,
    	"urn:StructTestService",
    	L"urn:StructTestService",
    	sizeof("urn:StructTestService")-1
    };

extern __declspec(selectany) const _soapmapentry ___StructTestService_CStructTestService_StructTest_atlsoapheader_entries[] =
    {
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___StructTestService_CStructTestService_StructTest_atlsoapheader_map =
    {
    	0x6AD07005,
    	"StructTest",
    	L"StructTest",
    	sizeof("StructTest")-1,
    	sizeof("StructTest")-1,
    	SOAPMAP_HEADER,
    	___StructTestService_CStructTestService_StructTest_atlsoapheader_entries,
    	0,
    	0,
    	-1,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0x57848C05,
    	"urn:StructTestService",
    	L"urn:StructTestService",
    	sizeof("urn:StructTestService")-1
    };
extern __declspec(selectany) const _soapmap * ___StructTestService_CStructTestService_funcs[] =
    {
    	&___StructTestService_CStructTestService_StructTest_map,
    	NULL
    };

extern __declspec(selectany) const _soapmap * ___StructTestService_CStructTestService_headers[] =
    {
    	&___StructTestService_CStructTestService_StructTest_atlsoapheader_map,
    	NULL
    };

ATL_NOINLINE inline const _soapmap ** CStructTestService::GetFunctionMap()
    {
    return ___StructTestService_CStructTestService_funcs;
};

ATL_NOINLINE inline const _soapmap ** CStructTestService::GetHeaderMap()
    {
    return ___StructTestService_CStructTestService_headers;
}

ATL_NOINLINE inline void * CStructTestService::GetHeaderValue()
    {
    return this;
}

ATL_NOINLINE inline HRESULT CStructTestService::CallFunction(
    	void *pvParam, 
    	const wchar_t *wszLocalName, 
    	int cchLocalName,
    	size_t nItem)
    {
    wszLocalName;
    cchLocalName;

    HRESULT hr = S_OK;

    switch(nItem)
	{
    case 0:
        {
            ___StructTestService_CStructTestService_StructTest_struct *p = (___StructTestService_CStructTestService_StructTest_struct *) pvParam;
            hr = StructTest(p->InputStruct, &p->OutputStruct);
            break;
        }
    default:
        hr = E_FAIL;
    }

    return hr;
}

ATL_NOINLINE inline const wchar_t * CStructTestService::GetNamespaceUri()
    {
    return L"urn:StructTestService";
}

ATL_NOINLINE inline const char * CStructTestService::GetNamespaceUriA()
    {
    return "urn:StructTestService";
}

ATL_NOINLINE inline const char * CStructTestService::GetServiceName()
    {
    return "StructTestService";
}

//--- End Injected Code For Attribute 'soap_handler'
 // class CStructTestService

} // namespace StructTestService
