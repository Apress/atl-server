// WhichInvoke.cpp : Implementation of CWhichInvoke

#include "stdafx.h"
#include "WhichInvoke.h"


// CWhichInvoke

