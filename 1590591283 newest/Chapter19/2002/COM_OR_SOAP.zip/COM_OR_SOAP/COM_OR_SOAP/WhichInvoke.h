// WhichInvoke.h : Declaration of the CWhichInvoke

#pragma once
#include "resource.h"       // main symbols
#include <atlsoap.h>
[ emitidl(true) ];


// IWhichInvoke
[
	object,
	uuid("D15E83BF-35BB-496F-9BE9-E0260443A292"),
	dual,	helpstring("IWhichInvoke Interface"),
	pointer_default(unique)
]
__interface IWhichInvoke : IDispatch
{
	[id(1)] HRESULT Test([out, retval] BSTR *InvokeType);
};



// CWhichInvoke

[
	coclass,
	threading("apartment"),
	vi_progid("COM_OR_SOAP.WhichInvoke"),
	progid("COM_OR_SOAP.WhichInvoke.1"),
	version(1.0),
	uuid("8777423D-7594-4116-94B9-70CCEE66DE27"),
	helpstring("WhichInvoke Class"),

	request_handler(name="Default", sdl="GenWSDL"),
	soap_handler(name="WhichInvoke")
]
class ATL_NO_VTABLE CWhichInvoke : 
	public IWhichInvoke
{
private:

	BOOL m_fCOMInvoke;

public:
	CWhichInvoke()
	{
		// default to COM
		m_fCOMInvoke = TRUE;
	}

	// override InitializeHandler
	HTTP_CODE InitializeHandler(AtlServerRequest *pRequestInfo, IServiceProvider *pProvider)
	{
		HTTP_CODE hcErr = __super::InitializeHandler(pRequestInfo, pProvider);
		if (hcErr == HTTP_SUCCESS)
		{
			m_fCOMInvoke = FALSE;
		}

		return hcErr;
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

	[ soap_method ]
	HRESULT Test(BSTR *InvokeType)
	{
		if (m_fCOMInvoke)
			*InvokeType = SysAllocString(L"COM!");
		else
			*InvokeType = SysAllocString(L"SOAP!");

		return S_OK;
	}

public:

};

