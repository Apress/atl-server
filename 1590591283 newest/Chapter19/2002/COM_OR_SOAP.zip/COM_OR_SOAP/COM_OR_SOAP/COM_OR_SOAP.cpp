// COM_OR_SOAP.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{C903F4A8-B0D2-46E5-AC40-91D18FDC5C7C}", 
		 name = "COM_OR_SOAP", 
		 helpstring = "COM_OR_SOAP 1.0 Type Library",
		 resource_name = "IDR_COM_OR_SOAP") ];
