// HelloWorld1.h : Defines the ATL Server request handler class
//
#pragma once
[ emitidl(true) ];

// disable warning about IRequestHandler not being emitted to IDL
#pragma warning(disable:4096)

[
	uuid("14FC0AE5-0900-4D88-AB69-D721B13F5479"), 
	object,

	// Add the following attributes
	dual
]
__interface IHelloWorldService
{
	[id(1)] HRESULT HelloWorld([in] BSTR bstrInput, [out, retval] BSTR *bstrOutput);
};

[
	request_handler(name="Default", sdl="GenHelloWorld1WSDL"),
	soap_handler(
		name="HelloWorld1Service", 
		namespace="urn:HelloWorld1Service",
		protocol="soap"
	),

	// Add the following attributes
	coclass,
	progid("HelloWordService.1"),
	uuid("8C9D14D0-A82E-424F-9A61-6293AAE11EF0")
]
class CHelloWorldService :
	public IHelloWorldService
{
public:
	
	[ soap_method ]
	HRESULT HelloWorld(/*[in]*/ BSTR bstrInput, /*[out, retval]*/ BSTR *bstrOutput)
	{
		CComBSTR bstrOut(L"Hello ");
		bstrOut += bstrInput;
		bstrOut += L"!";
		*bstrOutput = bstrOut.Detach();
		
		return S_OK;
	}
};
