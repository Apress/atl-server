// ErrorExample.cpp : Implementation of CErrorExample

#include "stdafx.h"
#include "ErrorExample.h"


// CErrorExample

