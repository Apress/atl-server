// ErrorExample.h : Declaration of the CErrorExample

#pragma once
#include "resource.h"       // main symbols
#include <atlsoap.h>
[ emitidl(true) ];


// IErrorExample
[
	object,
	uuid("CB3722F0-D016-409C-81F8-804520B9AB1D"),
	dual,	helpstring("IErrorExample Interface"),
	pointer_default(unique)
]
__interface IErrorExample : IDispatch
{
	[id(1)] HRESULT ReturnError();
};



// CErrorExample

[
	coclass,
	threading("apartment"),
	vi_progid("ErrorFault.ErrorExample"),
	progid("ErrorFault.ErrorExample.1"),
	version(1.0),
	uuid("C1457735-C0FD-4858-9A2D-42B60A4A93DE"),
	helpstring("ErrorExample Class"),

	support_error_info("IErrorExample"),
	request_handler(name="Default", sdl="GenWSDL"),
	soap_handler(name="ErrorExample")
]
class ATL_NO_VTABLE CErrorExample : 
	public IErrorExample
{
public:
	CErrorExample()
	{
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

	void GenerateError(HRESULT hr, LPCWSTR wszErr)
	{
		AtlReportError(GUID_NULL, wszErr);
	}

	// override GenerateAppError
	HRESULT
	GenerateAppError(
		IWriteStream *pStream, 
		HRESULT hr
		)
	{
		CComPtr<IErrorInfo> spErr;
		HRESULT hrInternal = GetErrorInfo(0, &spErr);
		if (SUCCEEDED(hrInternal))
		{
			CComBSTR bstrErr;
			hrInternal = spErr->GetDescription(&bstrErr);
			if (SUCCEEDED(hrInternal) && bstrErr.m_str)
			{
				return SoapFault(SOAP_E_SERVER, bstrErr, bstrErr.Length());
			}
		}
		
		return SoapFault(SOAP_E_SERVER, L"Unexpected Error", sizeof("Unexpected Error")-1);
	}

	[ soap_method ]
	HRESULT ReturnError()
	{
		GenerateError(0x80040200, L"Custom Failure Text");
		return 0x80040200;
	}

public:

};

