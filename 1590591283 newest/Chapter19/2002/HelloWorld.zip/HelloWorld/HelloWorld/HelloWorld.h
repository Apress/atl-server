// HelloWorld.h : Defines the ATL Server request handler class
//
#pragma once

namespace HelloWorldService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IHelloWorldService - web service interface declaration
//
[
	uuid("A035C807-3516-422C-A527-AB93D57F2798"), 
	object
]
__interface IHelloWorldService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT HelloWorld([in] BSTR InputParam, [out, retval] BSTR *bstrOutput);
	// TODO: Add additional web service methods here
};


// HelloWorldService - web service implementation
//
[
	request_handler(name="Default", sdl="GenHelloWorldWSDL"),
	soap_handler(
		name="HelloWorldService", 
		namespace="urn:HelloWorldService",
		protocol="soap"
	)
]
class CHelloWorldService :
	public IHelloWorldService
{
public:
	BSTR InputHeader;
	int OutputHeader;
	
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	[ soap_header(value="InputHeader", in=true, out=false) ]
	[ soap_header(value="OutputHeader", in=false, out=true) ]
	HRESULT HelloWorld(/*[in]*/ BSTR InputParam, /*[out, retval]*/ BSTR *bstrOutput)
	{
		CComBSTR bstrOut(L"Hello ");
		bstrOut += InputParam;
		bstrOut += L"!";
		*bstrOutput = bstrOut.Detach();
		if (InputHeader && InputHeader[0])
			OutputHeader = _wtoi(InputHeader);
		else
			OutputHeader = 0;
		
		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CHelloWorldService

} // namespace HelloWorldService
