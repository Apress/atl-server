// Created by Microsoft (R) C/C++ Compiler Version 13.00.9466
//
// c:\helloworld\helloworld\helloworld.mrg.h
// compiler-generated file created 01/25/03 at 15:30:39
//
// This C++ source file is intended to be a representation of the
// source code injected by the compiler.  It may not compile or
// run exactly as the original source file.
//


//+++ Start Injected Code
[no_injected_text(true)];      // Suppress injected text, it has already been injected
#pragma warning(disable: 4543) // Suppress warnings about skipping injected text
#pragma warning(disable: 4199) // Suppress warnings from attribute providers

#pragma message("\n\nNOTE: This merged source file should be visually inspected for correctness.\n\n")
//--- End Injected Code

// HelloWorld.h : Defines the ATL Server request handler class
//
#pragma once

namespace HelloWorldService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IHelloWorldService - web service interface declaration
//
[
	uuid("A035C807-3516-422C-A527-AB93D57F2798"), 
	object
]
__interface IHelloWorldService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT HelloWorld([in] BSTR InputParam, [out, retval] BSTR *bstrOutput);
	// TODO: Add additional web service methods here
};


// HelloWorldService - web service implementation
//
[
	request_handler(name="Default", sdl="GenHelloWorldWSDL"),
	soap_handler(
		name="HelloWorldService", 
		namespace="urn:HelloWorldService",
		protocol="soap"
	)
]
class CHelloWorldService :
	public IHelloWorldService
,
    /*+++ Added Baseclass */ public CSoapHandler<CHelloWorldService>
{
public:
	BSTR InputHeader;
	int OutputHeader;
	
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	[ soap_header(value="InputHeader", in=true, out=false) ]
	[ soap_header(value="OutputHeader", in=false, out=true) ]
	HRESULT HelloWorld(/*[in]*/ BSTR InputParam, /*[out, retval]*/ BSTR *bstrOutput)
	{
		CComBSTR bstrOut(L"Hello ");
		bstrOut += InputParam;
		bstrOut += L"!";
		*bstrOutput = bstrOut.Detach();
		if (InputHeader && InputHeader[0])
			OutputHeader = _wtoi(InputHeader);
		else
			OutputHeader = 0;
		
		return S_OK;
	}
	// TODO: Add additional web service methods here

	//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 28 "c:\\dev\\book\\ws_chapter2\\new\\code\\helloworld\\helloworld\\helloworld.h"
    const _soapmap ** GetFunctionMap() throw();
    const _soapmap ** GetHeaderMap() throw();
    void * GetHeaderValue() throw();
    const wchar_t * GetNamespaceUri() throw();
    const char * GetNamespaceUriA() throw();
    const char * GetServiceName() throw();
    HRESULT CallFunction(void *pvParam, const wchar_t *wszLocalName, int cchLocalName, size_t nItem);

	//--- End Injected Code For Attribute 'soap_handler'
};

//+++ Start Injected Code For Attribute 'request_handler'
#injected_line 27 "c:\\dev\\book\\ws_chapter2\\new\\code\\helloworld\\helloworld\\helloworld.h"

				
HANDLER_ENTRY_SDL("Default", CHelloWorldService, ::HelloWorldService::CHelloWorldService, GenHelloWorldWSDL)

			
//--- End Injected Code For Attribute 'request_handler'


//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 28 "c:\\dev\\book\\ws_chapter2\\new\\code\\helloworld\\helloworld\\helloworld.h"
struct ___HelloWorldService_CHelloWorldService_HelloWorld_struct
    {
    BSTR InputParam;
    BSTR bstrOutput;
};

extern __declspec(selectany) const _soapmapentry ___HelloWorldService_CHelloWorldService_HelloWorld_entries[] =
    {
    
    	{
    		0xF6041A8C, 
    		"bstrOutput", 
    		L"bstrOutput", 
    		sizeof("bstrOutput")-1, 
    		SOAPTYPE_STRING, 
    		SOAPFLAG_RETVAL | SOAPFLAG_OUT | SOAPFLAG_NULLABLE,
    		offsetof(___HelloWorldService_CHelloWorldService_HelloWorld_struct, bstrOutput),
    		NULL,
    		NULL,
    		-1,
    	},
    
    	{
    		0xD41C0B61, 
    		"InputParam", 
    		L"InputParam", 
    		sizeof("InputParam")-1, 
    		SOAPTYPE_STRING, 
    		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_NULLABLE,
    		offsetof(___HelloWorldService_CHelloWorldService_HelloWorld_struct, InputParam),
    		NULL,
    		NULL,
    		-1,
    	},
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___HelloWorldService_CHelloWorldService_HelloWorld_map =
    {
    	0x46BA99FC,
    	"HelloWorld",
    	L"HelloWorld",
    	sizeof("HelloWorld")-1,
    	sizeof("HelloWorld")-1,
    	SOAPMAP_FUNC,
    	___HelloWorldService_CHelloWorldService_HelloWorld_entries,
    	sizeof(___HelloWorldService_CHelloWorldService_HelloWorld_struct),
    	1,
    	0,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0xE6CAFA1C,
    	"urn:HelloWorldService",
    	L"urn:HelloWorldService",
    	sizeof("urn:HelloWorldService")-1
    };

extern __declspec(selectany) const _soapmapentry ___HelloWorldService_CHelloWorldService_HelloWorld_atlsoapheader_entries[] =
    {
    	{
    		0x45334E39, 
    		"InputHeader", 
    		L"InputHeader", 
    		sizeof("InputHeader")-1, 
    		SOAPTYPE_STRING, 
    		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_NULLABLE,
    		offsetof(CHelloWorldService, InputHeader),
    		NULL,
    		NULL,
    		-1,
    		0xE6CAFA1C,
    		"urn:HelloWorldService",
    		L"urn:HelloWorldService",
    		sizeof("urn:HelloWorldService")-1
    	},
    	{
    		0x647BAD1A, 
    		"OutputHeader", 
    		L"OutputHeader", 
    		sizeof("OutputHeader")-1, 
    		SOAPTYPE_INT, 
    		SOAPFLAG_NONE | SOAPFLAG_OUT,
    		offsetof(CHelloWorldService, OutputHeader),
    		NULL,
    		NULL,
    		-1,
    		0xE6CAFA1C,
    		"urn:HelloWorldService",
    		L"urn:HelloWorldService",
    		sizeof("urn:HelloWorldService")-1
    	},
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___HelloWorldService_CHelloWorldService_HelloWorld_atlsoapheader_map =
    {
    	0x46BA99FC,
    	"HelloWorld",
    	L"HelloWorld",
    	sizeof("HelloWorld")-1,
    	sizeof("HelloWorld")-1,
    	SOAPMAP_HEADER,
    	___HelloWorldService_CHelloWorldService_HelloWorld_atlsoapheader_entries,
    	0,
    	0,
    	-1,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0xE6CAFA1C,
    	"urn:HelloWorldService",
    	L"urn:HelloWorldService",
    	sizeof("urn:HelloWorldService")-1
    };
extern __declspec(selectany) const _soapmap * ___HelloWorldService_CHelloWorldService_funcs[] =
    {
    	&___HelloWorldService_CHelloWorldService_HelloWorld_map,
    	NULL
    };

extern __declspec(selectany) const _soapmap * ___HelloWorldService_CHelloWorldService_headers[] =
    {
    	&___HelloWorldService_CHelloWorldService_HelloWorld_atlsoapheader_map,
    	NULL
    };

ATL_NOINLINE inline const _soapmap ** CHelloWorldService::GetFunctionMap()
    {
    return ___HelloWorldService_CHelloWorldService_funcs;
};

ATL_NOINLINE inline const _soapmap ** CHelloWorldService::GetHeaderMap()
    {
    return ___HelloWorldService_CHelloWorldService_headers;
}

ATL_NOINLINE inline void * CHelloWorldService::GetHeaderValue()
    {
    return this;
}

ATL_NOINLINE inline HRESULT CHelloWorldService::CallFunction(
    	void *pvParam, 
    	const wchar_t *wszLocalName, 
    	int cchLocalName,
    	size_t nItem)
    {
    wszLocalName;
    cchLocalName;

    HRESULT hr = S_OK;

    switch(nItem)
	{
    case 0:
        {
            ___HelloWorldService_CHelloWorldService_HelloWorld_struct *p = (___HelloWorldService_CHelloWorldService_HelloWorld_struct *) pvParam;
            hr = HelloWorld(p->InputParam, &p->bstrOutput);
            break;
        }
    default:
        hr = E_FAIL;
    }

    return hr;
}

ATL_NOINLINE inline const wchar_t * CHelloWorldService::GetNamespaceUri()
    {
    return L"urn:HelloWorldService";
}

ATL_NOINLINE inline const char * CHelloWorldService::GetNamespaceUriA()
    {
    return "urn:HelloWorldService";
}

ATL_NOINLINE inline const char * CHelloWorldService::GetServiceName()
    {
    return "HelloWorldService";
}

//--- End Injected Code For Attribute 'soap_handler'
 // class CHelloWorldService

} // namespace HelloWorldService
