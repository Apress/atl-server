// EnumTest.h : Defines the ATL Server request handler class
//
#pragma once

namespace EnumTestService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

[ export ]
enum TestEnum { EnumVal1, EnumVal2, EnumVal3 };

// IEnumTestService - web service interface declaration
//
[
	uuid("3484E1E4-D46C-44DD-871D-52799101ADCE"), 
	object
]
__interface IEnumTestService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT EnumTest([in] TestEnum InputEnum, [out, retval] TestEnum *OutputEnum);
	// TODO: Add additional web service methods here
};


// EnumTestService - web service implementation
//
[
	request_handler(name="Default", sdl="GenEnumTestWSDL"),
	soap_handler(
		name="EnumTestService", 
		namespace="urn:EnumTestService",
		protocol="soap"
	)
]
class CEnumTestService :
	public IEnumTestService
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT EnumTest(/*[in]*/ TestEnum InputEnum, /*[out, retval]*/ TestEnum *OutputEnum)
	{
		*OutputEnum = InputEnum;
		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CEnumTestService

} // namespace EnumTestService
