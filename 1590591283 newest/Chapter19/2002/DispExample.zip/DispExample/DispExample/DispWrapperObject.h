// DispWrapperObject.h : Declaration of the CDispWrapperObject

#pragma once
#include "resource.h"       // main symbols
#include <atlsoap.h>
[ emitidl(true) ];

[ export ]
struct MyStruct
{
	int n;
	BSTR s;
};


// IDispWrapperObject
[
	object,
	uuid("879E3783-0AF9-43D2-85C3-66AF07CFC4BD"),
	dual,	helpstring("IDispWrapperObject Interface"),
	pointer_default(unique)
]
__interface IDispWrapperObject : IDispatch
{
	[id(1)] HRESULT StructTest([in] MyStruct tIn, [out, retval] MyStruct *tOut);
	[id(2)] HRESULT DispTest([in] IDispatch *tIn, [out, retval] IDispatch **tOut);
};



// CDispWrapperObject

inline HRESULT GetDispProperty(IDispatch *pDispatch, LPCWSTR wszName, VARIANT *pvOut)
{
	HRESULT hr;
	
	if (!pDispatch || !wszName)
		return E_INVALIDARG;
		
	if (!pvOut)
		return E_POINTER;
		
	DISPID dispid;
	hr = pDispatch->GetIDsOfNames(IID_NULL, (LPOLESTR *)&wszName, 1, NULL, &dispid);
	if (FAILED(hr))
		return hr;

	DISPPARAMS EmptyParams;
	EmptyParams.cArgs = 0;
	EmptyParams.cNamedArgs = 0;
	EmptyParams.rgdispidNamedArgs = NULL;
	EmptyParams.rgvarg = NULL;
	hr = pDispatch->Invoke(dispid, IID_NULL, NULL, DISPATCH_PROPERTYGET,
		&EmptyParams, pvOut, NULL, NULL);
	if (FAILED(hr))
		return hr;

	return S_OK;
}

class CDispatchBag : public IDispatch, public CComObjectRoot
{
private:

	struct CProp
	{
		int m_nCnt;
		CComVariant m_var;
		CStringW m_str;
		
		CProp(LPCWSTR wsz, int nCnt)
			: m_str(wsz), m_nCnt(nCnt)
		{
		}
	};
	
	CAtlArray<CProp> m_props;
	
public:

	BEGIN_COM_MAP(CDispatchBag)
		COM_INTERFACE_ENTRY(IDispatch)
	END_COM_MAP()
	
	VARIANT * AddProperty(LPCWSTR wszName)
	{
		VARIANT *pRet = NULL;
		_ATLTRY
		{
			size_t nCount = m_props.GetCount();
			CProp prop(wszName, (int) nCount);
			size_t nIndex = m_props.Add(prop);
			if (nCount < m_props.GetCount())
			{
				pRet = &(m_props[nIndex].m_var);
			}
		}
		_ATLCATCH( e )
		{
			e;
		}
		
		return pRet;
	}
	
	virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
		UINT *pctinfo)
	{
		if (!pctinfo)
			return E_INVALIDARG;

		*pctinfo = 0;
		return S_OK;
	}
        
	virtual HRESULT STDMETHODCALLTYPE GetTypeInfo( 
		UINT iTInfo,
        LCID lcid,
        ITypeInfo **ppTInfo)
	{
		if (!ppTInfo)
			return E_INVALIDARG;

		*ppTInfo = NULL;

		return DISP_E_BADINDEX;
	}
        
    virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
        REFIID riid,
        LPOLESTR *rgszNames,
        UINT cNames,
        LCID lcid,
        DISPID *rgDispId)
	{
		HRESULT hr = S_OK;
		
		for (UINT i=0; i<cNames; i++)
		{
			bool bFound = false;
			for (size_t nIndex=0; nIndex<m_props.GetCount(); nIndex++)
			{	
				if (m_props[nIndex].m_str == rgszNames[i])
				{
					rgDispId[i] = (DISPID)nIndex;
					bFound = true;
					break;
				}
			}
			if (!bFound)
			{
				rgDispId[i] = DISPID_UNKNOWN;
				hr = DISP_E_UNKNOWNNAME;
			}
		}
		
		return hr;
	}
        
    virtual HRESULT STDMETHODCALLTYPE Invoke( 
        DISPID dispIdMember,
        REFIID riid,
        LCID lcid,
        WORD wFlags,
        DISPPARAMS *pDispParams,
        VARIANT *pVarResult,
        EXCEPINFO *pExcepInfo,
        UINT *puArgErr)
	{
		if (dispIdMember < 0 || dispIdMember > (long)m_props.GetCount())
			return DISP_E_MEMBERNOTFOUND;

		if (wFlags != DISPATCH_PROPERTYGET)
			return DISP_E_MEMBERNOTFOUND;

		if (!pVarResult || !pDispParams)
			return E_INVALIDARG;
		
		return VariantCopy(pVarResult, &m_props[dispIdMember].m_var);
	}
}; // class CDispatchBag

[
	coclass,
	threading("apartment"),
	vi_progid("DispExample.DispWrapperObject"),
	progid("DispExample.DispWrapperObject.1"),
	version(1.0),
	uuid("99843466-E53E-49C3-9191-0E41A3D427DF"),
	helpstring("DispWrapperObject Class")
]
class ATL_NO_VTABLE CDispWrapperObject : 
	public IDispWrapperObject
{
public:
	CDispWrapperObject()
	{
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}


	[ soap_method ]
	HRESULT StructTest(MyStruct tIn, MyStruct *tOut)
	{
		tOut->n = tIn.n;
		tOut->s = tIn.s ? SysAllocString(tIn.s) : NULL;

		return S_OK;
	}

	// NOTE: the soap_method attribute is omitted here 
	//       so this method is not exposed via SOAP 
	HRESULT DispTest(IDispatch *tIn, IDispatch **tOut)
	{
		CComVariant vInt;
		CComVariant vStr;
		MyStruct structIn;
		MyStruct structOut;
		*tOut = NULL;

		HRESULT hr = GetDispProperty(tIn, L"n", &vInt);
		if (FAILED(hr))
			return hr;
		if (vInt.vt != VT_INT && vInt.vt != VT_UI1 && vInt.vt != VT_I2 && vInt.vt != VT_I4 &&
			vInt.vt != VT_UI2 && vInt.vt != VT_UI4 && vInt.vt != VT_UINT)
			return E_INVALIDARG;

		structIn.n = vInt.intVal;

		hr = GetDispProperty(tIn, L"s", &vStr);
		if (FAILED(hr))
			return hr;
		if (vStr.vt != VT_BSTR)
			return E_INVALIDARG;

		structIn.s = vStr.bstrVal;

		hr = StructTest(structIn, &structOut);
		if (FAILED(hr))
			return hr;

		CComObject<CDispatchBag> *pDispBag = new CComObject<CDispatchBag>;
		if (pDispBag)
		{
			pDispBag->AddRef();
			VARIANT *pVar = pDispBag->AddProperty(L"n");
			if (pVar)
			{
				pVar->vt = VT_INT;
				pVar->intVal = structOut.n;
				pVar = pDispBag->AddProperty(L"s");
				if (pVar)
				{
					pVar->vt = VT_BSTR;
					pVar->bstrVal = structOut.s;
					*tOut = static_cast<IDispatch*>(pDispBag);
					return S_OK;
				}
			}

			pDispBag->Release();
		}

		if (structOut.s)
			SysFreeString(structOut.s);

		return E_OUTOFMEMORY;
	}

public:

};

