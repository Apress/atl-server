// DispWrapperObject.cpp : Implementation of CDispWrapperObject

#include "stdafx.h"
#include "DispWrapperObject.h"


// CDispWrapperObject

