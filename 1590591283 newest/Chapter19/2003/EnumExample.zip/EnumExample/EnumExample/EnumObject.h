// EnumObject.h : Declaration of the CEnumObject

#pragma once
#include "resource.h"       // main symbols
#include <atlsoap.h>
[ emitidl(true) ];

[ export ]
enum MyEnumeration
{
	Value1,
	Value2,
	Value3
};


// IEnumObject
[
	object,
	uuid("F3AF9E86-98ED-4B2F-8A5B-7439745ED7E9"),
	dual,	helpstring("IEnumObject Interface"),
	pointer_default(unique)
]
__interface IEnumObject : IDispatch
{
	[id(1)] HRESULT EnumTest([in] MyEnumeration eIn, [out, retval] MyEnumeration *eOut);
};



// CEnumObject

[
	coclass,
	threading("apartment"),
	vi_progid("EnumExample.EnumObject"),
	progid("EnumExample.EnumObject.1"),
	version(1.0),
	uuid("CADF04A4-6023-490A-827D-7E35F069FEFA"),
	helpstring("EnumObject Class"),

	request_handler(name="Default", sdl="GenWSDL"),
	soap_handler(name="EnumObject")
]
class ATL_NO_VTABLE CEnumObject : 
	public IEnumObject
{
public:
	CEnumObject()
	{
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

	[ soap_method ]
	HRESULT EnumTest(MyEnumeration eIn, MyEnumeration *eOut)
	{
		*eOut = eIn;
		return S_OK;
	}

public:

};

