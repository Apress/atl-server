// EnumExample.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{8893C837-CFB6-4743-A4E9-9D32D27406F6}", 
		 name = "EnumExample", 
		 helpstring = "EnumExample 1.0 Type Library",
		 resource_name = "IDR_ENUMEXAMPLE") ];
