========================================================================
       ATL SERVER : HelloWorld1 Project Overview
========================================================================

AppWizard has created this HelloWorld1 application for you.  This application
not only demonstrates the basics of using the ATL Server Classes but is also a starting 
point for writing your application.

This file contains a summary of what you will find in each of the files that
make up your HelloWorld1 application.

HelloWorld1.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.
 
HelloWorld1.h
    This file contains your ATL Server request handler class customized based on the 
    options you chose in the the ATL Server Wizard.
 
HelloWorld1.disco
    This file contains information that allows your web service to be exposed via
    web servers supporting the DISCO protocol.
	
HelloWorld1.htm
    This is a webpage containing a description of your web service.  It is referenced
    in HelloWorld1.disco.  You should update this file when adding or
    removing methods from your web service.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    and a precompiled types file.

/////////////////////////////////////////////////////////////////////////////

Other notes:
 
AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
