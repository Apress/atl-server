// Created by Microsoft (R) C/C++ Compiler Version 13.10.3077
//
// e:\dev\book\chapter19\helloworld1\helloworld1\helloworld1.mrg.h
// compiler-generated file created 05/30/03 at 10:43:45
//
// This C++ source file is intended to be a representation of the
// source code injected by the compiler.  It may not compile or
// run exactly as the original source file.
//


//+++ Start Injected Code
[no_injected_text(true)];      // Suppress injected text, it has already been injected
#pragma warning(disable: 4543) // Suppress warnings about skipping injected text
#pragma warning(disable: 4199) // Suppress warnings from attribute providers

// M00PRAGMA("\n\nNOTE: This merged source file should be visually inspected for correctness.\n\n")
//--- End Injected Code

// HelloWorld1.h : Defines the ATL Server request handler class
//
#pragma once
[ emitidl(true) ];

// disable warning about IRequestHandler not being emitted to IDL
#pragma warning(disable:4096)

[
	uuid("14FC0AE5-0900-4D88-AB69-D721B13F5479"), 
	object,

	// Add the following attributes
	dual
]
__interface IHelloWorldService
{
	[id(1)] HRESULT HelloWorld([in] BSTR bstrInput, [out, retval] BSTR *bstrOutput);
};

[
	request_handler(name="Default", sdl="GenHelloWorld1WSDL"),
	soap_handler(
		name="HelloWorld1Service", 
		namespace="urn:HelloWorld1Service",
		protocol="soap"
	),

	// Add the following attributes
	coclass,
	progid("HelloWordService.1"),
	uuid("8C9D14D0-A82E-424F-9A61-6293AAE11EF0")
]
class CHelloWorldService :
	public IHelloWorldService
,
    /*+++ Added Baseclass */ public CComCoClass<CHelloWorldService, &__uuidof(CHelloWorldService)>,
    /*+++ Added Baseclass */ public IProvideClassInfoImpl<&__uuidof(CHelloWorldService)>,
    /*+++ Added Baseclass */ public CSoapHandler<CHelloWorldService>
{
public:
	
	[ soap_method ]
	HRESULT HelloWorld(/*[in]*/ BSTR bstrInput, /*[out, retval]*/ BSTR *bstrOutput)
	{
		CComBSTR bstrOut(L"Hello ");
		bstrOut += bstrInput;
		bstrOut += L"!";
		*bstrOutput = bstrOut.Detach();
		
		return S_OK;
	}

	//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 32 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    virtual HRESULT STDMETHODCALLTYPE IHelloWorldService::Invoke(
                /* [in] */ DISPID dispIdMember,
                /* [in] */ REFIID riid,
                /* [in] */ LCID lcid,
                /* [in] */ WORD wFlags,
                /* [out][in] */ DISPPARAMS *pDispParams,
                /* [out] */ VARIANT *pVarResult,
                /* [out] */ EXCEPINFO *pExcepInfo,
                /* [out] */ UINT *puArgErr) 
    {
        (void) riid;
        (void) dispIdMember;
        (void) lcid;
        (void) wFlags;
        (void) pExcepInfo;
        (void) puArgErr;
        HRESULT hr = S_OK;
        if (pDispParams == 0) {
            return DISP_E_BADVARTYPE;
        }
        if (pDispParams->cArgs > 2) {
            return DISP_E_BADPARAMCOUNT;
        }
        if (pVarResult != 0) {
            ::VariantInit(pVarResult);
        }
        VARIANT* rgpVars[2];
        UINT index = 0;
        if (pDispParams->cNamedArgs > 0) {
            if (pDispParams->rgdispidNamedArgs[0] == DISPID_PROPERTYPUT) {
                rgpVars[0] = &pDispParams->rgvarg[0];
                index = 1;
            }
            for (; index < pDispParams->cNamedArgs; ++index) {
                if (pDispParams->rgdispidNamedArgs[index] >= (int) pDispParams->cArgs || pDispParams->rgdispidNamedArgs[index] < 0) {
                    if (puArgErr != 0) {
                        *puArgErr = index;
                    }
                    return DISP_E_PARAMNOTFOUND;
                }
                rgpVars[pDispParams->cArgs - pDispParams->rgdispidNamedArgs[index] - 1] = &pDispParams->rgvarg[index];
            }
        }
        for (; index < pDispParams->cArgs; ++index) {
            rgpVars[index] = &pDispParams->rgvarg[index];
        }
        VARIANT v0;
        VARIANT* v;
        switch (dispIdMember) {
        case 1:
            {
                if (pDispParams->cArgs != 1) {
                    return DISP_E_BADPARAMCOUNT;
                }
                v = rgpVars[0];
                if (v->vt != VT_BSTR && FAILED(__VariantChangeType(v, &v0, VT_BSTR))) {
                    if (puArgErr != 0) {
                        *puArgErr = 0;
                    }
                    return DISP_E_TYPEMISMATCH;
                }
                BSTR i1 = (BSTR) V_BSTR(v);
                BSTR i2;
                hr = ((::IHelloWorldService*) this)->HelloWorld(i1, &i2);
                if (pVarResult != 0) {
                    V_VT(pVarResult) = VT_BSTR;
                    V_BSTR(pVarResult) = (BSTR) i2;
                }
                break;
            }
        default:
            return DISP_E_MEMBERNOTFOUND;
        }
        return hr;
    }
    virtual HRESULT STDMETHODCALLTYPE IHelloWorldService::GetIDsOfNames(
                /* [in] */ REFIID riid,
                /* [size_is][in] */ LPOLESTR *rgszNames,
                /* [in] */ UINT cNames,
                /* [in] */ LCID lcid,
                /* [size_is][out] */ DISPID *rgDispId) 
    {
        (void) riid;
        (void) rgszNames;
        (void) cNames;
        (void) lcid;
        (void) rgDispId;
        static LPOLESTR names[] = { L"bstrInput", L"bstrOutput", L"HelloWorld" };
        static DISPID dids[] = { 0, 1, 1 };
        for (unsigned int i = 0; i < cNames; ++i) {
            int fFoundIt = 0;
            for (unsigned int j = 0; j < sizeof(names)/sizeof(LPOLESTR); ++j) {
                if (_wcsicmp(rgszNames[i], names[j]) == 0) {
                    fFoundIt = 1;
                    rgDispId[i] = dids[j];
                    break;
                }
            }
            if (fFoundIt == 0) {
                return DISP_E_UNKNOWNNAME;
            }
        }
        return S_OK;
    }
    HRESULT TypeInfoHelper(REFIID iidDisp, LCID /*lcid*/, ITypeInfo** ppTypeInfo) 
    {
        if (ppTypeInfo == NULL) {
            return E_POINTER;
        }
        *ppTypeInfo = NULL;
        TCHAR szModule1[_MAX_PATH];
        int nLen = ::GetModuleFileName(_AtlBaseModule.GetModuleInstance(), szModule1, _MAX_PATH);
        if (nLen == 0 || nLen == _MAX_PATH) {
            return E_FAIL;
        }
        USES_CONVERSION_EX;
        LPOLESTR pszModule = T2OLE_EX(szModule1, _ATL_SAFE_ALLOCA_DEF_THRESHOLD);
#ifndef _UNICODE
        if (pszModule == NULL) {
            return E_OUTOFMEMORY;
        }
#endif
        CComPtr<ITypeLib> spTypeLib;
        HRESULT hr = LoadTypeLib(pszModule, &spTypeLib);
        if (SUCCEEDED(hr)) {
            CComPtr<ITypeInfo> spTypeInfo;
            hr = spTypeLib->GetTypeInfoOfGuid(iidDisp, &spTypeInfo);
            if (SUCCEEDED(hr)) {
                *ppTypeInfo = spTypeInfo.Detach();
            }
        }
        return hr;
    }
    virtual HRESULT STDMETHODCALLTYPE IHelloWorldService::GetTypeInfoCount(unsigned int*  pctinfo) 
    {
        if (pctinfo == NULL) {
            return E_POINTER;
        }
        CComPtr<ITypeInfo> spTypeInfo;
        *pctinfo = 
                       (SUCCEEDED(TypeInfoHelper(__uuidof(IHelloWorldService), 0, &spTypeInfo))) ? 1 : 0;
        return S_OK;
    }
    virtual HRESULT STDMETHODCALLTYPE IHelloWorldService::GetTypeInfo(unsigned int iTInfo, LCID lcid, ITypeInfo** ppTInfo) 
    {
        if (iTInfo != 0) {
            return DISP_E_BADINDEX;
        }
        return TypeInfoHelper(__uuidof(IHelloWorldService), lcid, ppTInfo);
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static DWORD* GetOpCodes() 
    {
        static DWORD rgOps[] = 
            					{
            						0x70000000,
            0x30004000,
            0x80000002,
            0x50000000,
            0x3000c000,
            0x80000004,
            0x60000000,
            0x30014000,
            0x80000002,
            0x50000000,
            0x3000c000,
            0x80000004,
            0x30018000,
            0x80000001,
            0x60000000,
            0x1000c000,
            0x3000c000,
            0x50000000,
            0x20010000,
            0x30010000,
            0x80000002,
            0x50000000,
            0x3001c000,
            0x80000001,
            0x30020000,
            0x80000005,
            0x20024000,
            0x30024000,
            0x30028000,
            0x8000000b,
            0x50000000,
            0x8003000d,
            0x60000000,
            0x8003800f,
            0x30040000,
            0x80000011,
            0x60000000,
            0x60000000,
            0x60000000,
            0
            					};
        return rgOps;
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static RGSDWORD* GetOpcodeDWORDVals() 
    {
        static RGSDWORD rgDWORDS[] = 
            					{
            						{0, 0}
            					};
        return rgDWORDS;
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static RGSBinary* GetOpcodeBinaryVals() 
    {

        static RGSBinary rgBinary[] = 
            					{
            						{0, 0}
            					};
        return rgBinary;
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static RGSStrings* GetOpcodeStringVals() 
    {
        static RGSStrings rgStrings[] = 
            					{
            						{_T(""),0 }, 
            {_T("HelloWordService.1"),0 }, 
            {_T("%FriendlyName%"),1 }, 
            {_T("CLSID"),0 }, 
            {_T("{8C9D14D0-A82E-424F-9A61-6293AAE11EF0}"),0 }, 
            {_T("HelloWordService"),0 }, 
            {_T("CurVer"),0 }, 
            {_T("ProgID"),0 }, 
            {_T("VersionIndependentProgID"),0 }, 
            {_T("Programmable"),0 }, 
            {_T("%MODULETYPE%"),1 }, 
            {_T("%MODULE%"),1 }, 
            {_T("ThreadingModel"),0 }, 
            {_T("apartment"),0 }, 
            {_T("AppID"),0 }, 
            {_T("%APPID%"),1 }, 
            {_T("TypeLib"),0 }, 
            {_T("%MODULEGUID%"),1 }, 
            {NULL, 0}
            					};
        return rgStrings;
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static HRESULT WINAPI UpdateRegistry(BOOL bRegister) 
    {
        CRegistryVirtualMachine rvm;
        HRESULT hr;
        if (FAILED(hr = rvm.AddStandardReplacements()))
            return hr;
        rvm.AddReplacement(_T("FriendlyName"), GetObjectFriendlyName());
        return rvm.VMUpdateRegistry(GetOpCodes(), GetOpcodeStringVals(), GetOpcodeDWORDVals(), GetOpcodeBinaryVals(), bRegister);
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static const TCHAR* GetObjectFriendlyName() 
    {
        return _T("CHelloWorldService Object");
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static const TCHAR* GetProgID() 
    {
        return _T("HelloWordService.1");
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    static const TCHAR* GetVersionIndependentProgID() 
    {
        return _T("HelloWordService");
    }
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    BEGIN_COM_MAP(CHelloWorldService)
        COM_INTERFACE_ENTRY(IHelloWorldService)
        COM_INTERFACE_ENTRY(IDispatch)
        COM_INTERFACE_ENTRY(IProvideClassInfo)
        COM_INTERFACE_ENTRY(ISAXContentHandler)
        COM_INTERFACE_ENTRY(ATL::IRequestHandler)
    END_COM_MAP()
#injected_line 23 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
    const _soapmap ** GetFunctionMap() throw();
    const _soapmap ** GetHeaderMap() throw();
    void * GetHeaderValue() throw();
    const wchar_t * GetNamespaceUri() throw();
    const char * GetNamespaceUriA() throw();
    const char * GetServiceName() throw();
    HRESULT CallFunction(void *pvParam, const wchar_t *wszLocalName, int cchLocalName, size_t nItem);

	//--- End Injected Code For Attribute 'soap_handler'
};

//+++ Start Injected Code For Attribute 'request_handler'
#injected_line 23 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"

				OBJECT_ENTRY_AUTO(__uuidof(CHelloWorldService), CHelloWorldService)
			
#injected_line 22 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"

				
HANDLER_ENTRY_SDL("Default", CHelloWorldService, ::CHelloWorldService, GenHelloWorld1WSDL)

			
//--- End Injected Code For Attribute 'request_handler'


//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 23 "e:\\dev\\book\\chapter19\\helloworld1\\helloworld1\\helloworld1.h"
struct ___CHelloWorldService_HelloWorld_struct
    {
    BSTR bstrInput;
    BSTR bstrOutput;
};

extern __declspec(selectany) const _soapmapentry ___CHelloWorldService_HelloWorld_entries[] =
    {
    
    	{
    		0xF6041A8C, 
    		"bstrOutput", 
    		L"bstrOutput", 
    		sizeof("bstrOutput")-1, 
    		SOAPTYPE_STRING, 
    		SOAPFLAG_RETVAL | SOAPFLAG_OUT | SOAPFLAG_NULLABLE,
    		offsetof(___CHelloWorldService_HelloWorld_struct, bstrOutput),
    		NULL,
    		NULL,
    		-1,
    	},
    
    	{
    		0xA9ECBD0B, 
    		"bstrInput", 
    		L"bstrInput", 
    		sizeof("bstrInput")-1, 
    		SOAPTYPE_STRING, 
    		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_NULLABLE,
    		offsetof(___CHelloWorldService_HelloWorld_struct, bstrInput),
    		NULL,
    		NULL,
    		-1,
    	},
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___CHelloWorldService_HelloWorld_map =
    {
    	0x46BA99FC,
    	"HelloWorld",
    	L"HelloWorld",
    	sizeof("HelloWorld")-1,
    	sizeof("HelloWorld")-1,
    	SOAPMAP_FUNC,
    	___CHelloWorldService_HelloWorld_entries,
    	sizeof(___CHelloWorldService_HelloWorld_struct),
    	1,
    	0,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0xD73F7A8D,
    	"urn:HelloWorld1Service",
    	L"urn:HelloWorld1Service",
    	sizeof("urn:HelloWorld1Service")-1
    };

extern __declspec(selectany) const _soapmapentry ___CHelloWorldService_HelloWorld_atlsoapheader_entries[] =
    {
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___CHelloWorldService_HelloWorld_atlsoapheader_map =
    {
    	0x46BA99FC,
    	"HelloWorld",
    	L"HelloWorld",
    	sizeof("HelloWorld")-1,
    	sizeof("HelloWorld")-1,
    	SOAPMAP_HEADER,
    	___CHelloWorldService_HelloWorld_atlsoapheader_entries,
    	0,
    	0,
    	-1,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0xD73F7A8D,
    	"urn:HelloWorld1Service",
    	L"urn:HelloWorld1Service",
    	sizeof("urn:HelloWorld1Service")-1
    };
extern __declspec(selectany) const _soapmap * ___CHelloWorldService_funcs[] =
    {
    	&___CHelloWorldService_HelloWorld_map,
    	NULL
    };

extern __declspec(selectany) const _soapmap * ___CHelloWorldService_headers[] =
    {
    	&___CHelloWorldService_HelloWorld_atlsoapheader_map,
    	NULL
    };

ATL_NOINLINE inline const _soapmap ** CHelloWorldService::GetFunctionMap()
    {
    return ___CHelloWorldService_funcs;
};

ATL_NOINLINE inline const _soapmap ** CHelloWorldService::GetHeaderMap()
    {
    return ___CHelloWorldService_headers;
}

ATL_NOINLINE inline void * CHelloWorldService::GetHeaderValue()
    {
    return this;
}

ATL_NOINLINE inline HRESULT CHelloWorldService::CallFunction(
    	void *pvParam, 
    	const wchar_t *wszLocalName, 
    	int cchLocalName,
    	size_t nItem)
    {
    wszLocalName;
    cchLocalName;

    HRESULT hr = S_OK;

    switch(nItem)
	{
    case 0:
        {
            ___CHelloWorldService_HelloWorld_struct *p = (___CHelloWorldService_HelloWorld_struct *) pvParam;
            hr = HelloWorld(p->bstrInput, &p->bstrOutput);
            break;
        }
    default:
        hr = E_FAIL;
    }

    return hr;
}

ATL_NOINLINE inline const wchar_t * CHelloWorldService::GetNamespaceUri()
    {
    return L"urn:HelloWorld1Service";
}

ATL_NOINLINE inline const char * CHelloWorldService::GetNamespaceUriA()
    {
    return "urn:HelloWorld1Service";
}

ATL_NOINLINE inline const char * CHelloWorldService::GetServiceName()
    {
    return "HelloWorld1Service";
}

//--- End Injected Code For Attribute 'soap_handler'

