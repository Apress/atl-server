// StructObject.cpp : Implementation of CStructObject

#include "stdafx.h"
#include "StructObject.h"


// CStructObject

