// StructObject.h : Declaration of the CStructObject

#pragma once
#include "resource.h"       // main symbols
#include <atlsoap.h>
[ emitidl(true) ];

[ export ]
struct MyStruct
{
	int n;
	BSTR s;
};

// IStructObject
[
	object,
	uuid("4933C2D4-EA9A-4988-A163-E19BA560AE16"),
	dual,	helpstring("IStructObject Interface"),
	pointer_default(unique)
]
__interface IStructObject : IDispatch
{
	[id(1)] HRESULT StructTest([in] MyStruct tIn, [out, retval] MyStruct *tOut);
};



// CStructObject

[
	coclass,
	threading("apartment"),
	vi_progid("StructExample.StructObject"),
	progid("StructExample.StructObject.1"),
	version(1.0),
	uuid("CD55DAD9-597B-4652-BAC7-2E8CD5AA7BB0"),
	helpstring("StructObject Class"),

	request_handler(name="Default", sdl="GetWSDL"),
	soap_handler(name="StructObject")
]
class ATL_NO_VTABLE CStructObject : 
	public IStructObject
{
public:
	CStructObject()
	{
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

	[ soap_method ]
	HRESULT StructTest(MyStruct tIn, MyStruct *tOut)
	{
		tOut->n = tIn.n;
		tOut->s = tIn.s ? SysAllocString(tIn.s) : NULL;

		return S_OK;
	}

public:

};

