// StructExample.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{E471EB2E-7EC1-48A0-B5B4-6B522269F5A5}", 
		 name = "StructExample", 
		 helpstring = "StructExample 1.0 Type Library",
		 resource_name = "IDR_STRUCTEXAMPLE") ];
