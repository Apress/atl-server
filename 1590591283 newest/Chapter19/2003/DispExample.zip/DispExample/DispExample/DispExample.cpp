// DispExample.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{526DA482-314F-4C23-92AA-9244CD7A0601}", 
		 name = "DispExample", 
		 helpstring = "DispExample 1.0 Type Library",
		 resource_name = "IDR_DISPEXAMPLE") ];
