// Created by Microsoft (R) C/C++ Compiler Version 13.10.3077
//
// e:\dev\book\chapter19\enumtest\enumtest\enumtest.mrg.h
// compiler-generated file created 05/30/03 at 10:37:04
//
// This C++ source file is intended to be a representation of the
// source code injected by the compiler.  It may not compile or
// run exactly as the original source file.
//


//+++ Start Injected Code
[no_injected_text(true)];      // Suppress injected text, it has already been injected
#pragma warning(disable: 4543) // Suppress warnings about skipping injected text
#pragma warning(disable: 4199) // Suppress warnings from attribute providers

// M00PRAGMA("\n\nNOTE: This merged source file should be visually inspected for correctness.\n\n")
//--- End Injected Code

// EnumTest.h : Defines the ATL Server request handler class
//
#pragma once

namespace EnumTestService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

[ export ]
enum TestEnum { EnumVal1, EnumVal2, EnumVal3 };

// IEnumTestService - web service interface declaration
//
[
	uuid("3484E1E4-D46C-44DD-871D-52799101ADCE"), 
	object
]
__interface IEnumTestService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT EnumTest([in] TestEnum InputEnum, [out, retval] TestEnum *OutputEnum);
	// TODO: Add additional web service methods here
};


// EnumTestService - web service implementation
//
[
	request_handler(name="Default", sdl="GenEnumTestWSDL"),
	soap_handler(
		name="EnumTestService", 
		namespace="urn:EnumTestService",
		protocol="soap"
	)
]
class CEnumTestService :
	public IEnumTestService
,
    /*+++ Added Baseclass */ public CSoapHandler<CEnumTestService>
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT EnumTest(/*[in]*/ TestEnum InputEnum, /*[out, retval]*/ TestEnum *OutputEnum)
	{
		*OutputEnum = InputEnum;
		return S_OK;
	}
	// TODO: Add additional web service methods here

	//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 31 "e:\\dev\\book\\chapter19\\enumtest\\enumtest\\enumtest.h"
    const _soapmap ** GetFunctionMap() throw();
    const _soapmap ** GetHeaderMap() throw();
    void * GetHeaderValue() throw();
    const wchar_t * GetNamespaceUri() throw();
    const char * GetNamespaceUriA() throw();
    const char * GetServiceName() throw();
    HRESULT CallFunction(void *pvParam, const wchar_t *wszLocalName, int cchLocalName, size_t nItem);

	//--- End Injected Code For Attribute 'soap_handler'
};

//+++ Start Injected Code For Attribute 'request_handler'
#injected_line 30 "e:\\dev\\book\\chapter19\\enumtest\\enumtest\\enumtest.h"

				
HANDLER_ENTRY_SDL("Default", CEnumTestService, ::EnumTestService::CEnumTestService, GenEnumTestWSDL)

			
//--- End Injected Code For Attribute 'request_handler'


//+++ Start Injected Code For Attribute 'soap_handler'
#injected_line 31 "e:\\dev\\book\\chapter19\\enumtest\\enumtest\\enumtest.h"
__if_not_exists(___EnumTestService_TestEnum_entries)
    {
    extern __declspec(selectany) const _soapmapentry ___EnumTestService_TestEnum_entries[] =
        {
        	{ 0xDA154F6B, "EnumVal3", L"EnumVal3", sizeof("EnumVal3")-1, 2, SOAPFLAG_FIELD, 0, NULL, NULL, -1 },
        	{ 0xDA154F6A, "EnumVal2", L"EnumVal2", sizeof("EnumVal2")-1, 1, SOAPFLAG_FIELD, 0, NULL, NULL, -1 },
        	{ 0xDA154F69, "EnumVal1", L"EnumVal1", sizeof("EnumVal1")-1, 0, SOAPFLAG_FIELD, 0, NULL, NULL, -1 },
        	{ 0x00000000 }
        };

    extern __declspec(selectany) const _soapmap ___EnumTestService_TestEnum_map =
        {
        	0xF8EFE655,
        	"TestEnum",
        	L"TestEnum",
        	sizeof("TestEnum")-1,
        	sizeof("TestEnum")-1,
        	SOAPMAP_ENUM,
        	___EnumTestService_TestEnum_entries,
        	sizeof(::EnumTestService::TestEnum),
        	1,
        	-1,
        	SOAPFLAG_NONE,
        	0xF29B2B15,
        	"urn:EnumTestService",
        	L"urn:EnumTestService",
        	sizeof("urn:EnumTestService")-1
        };
}

struct ___EnumTestService_CEnumTestService_EnumTest_struct
    {
    ::EnumTestService::TestEnum InputEnum;
    ::EnumTestService::TestEnum OutputEnum;
};

extern __declspec(selectany) const _soapmapentry ___EnumTestService_CEnumTestService_EnumTest_entries[] =
    {
    
    	{
    		0x50B7DEA6, 
    		"OutputEnum", 
    		L"OutputEnum", 
    		sizeof("OutputEnum")-1, 
    		SOAPTYPE_UNK, 
    		SOAPFLAG_RETVAL | SOAPFLAG_OUT,
    		offsetof(___EnumTestService_CEnumTestService_EnumTest_struct, OutputEnum),
    		NULL,
    		&___EnumTestService_TestEnum_map,
    		-1,
    	},
    
    	{
    		0x8286AC05, 
    		"InputEnum", 
    		L"InputEnum", 
    		sizeof("InputEnum")-1, 
    		SOAPTYPE_UNK, 
    		SOAPFLAG_NONE | SOAPFLAG_IN,
    		offsetof(___EnumTestService_CEnumTestService_EnumTest_struct, InputEnum),
    		NULL,
    		&___EnumTestService_TestEnum_map,
    		-1,
    	},
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___EnumTestService_CEnumTestService_EnumTest_map =
    {
    	0xDA1448D5,
    	"EnumTest",
    	L"EnumTest",
    	sizeof("EnumTest")-1,
    	sizeof("EnumTest")-1,
    	SOAPMAP_FUNC,
    	___EnumTestService_CEnumTestService_EnumTest_entries,
    	sizeof(___EnumTestService_CEnumTestService_EnumTest_struct),
    	1,
    	0,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0xF29B2B15,
    	"urn:EnumTestService",
    	L"urn:EnumTestService",
    	sizeof("urn:EnumTestService")-1
    };

extern __declspec(selectany) const _soapmapentry ___EnumTestService_CEnumTestService_EnumTest_atlsoapheader_entries[] =
    {
    	{ 0x00000000 }
    };

extern __declspec(selectany) const _soapmap ___EnumTestService_CEnumTestService_EnumTest_atlsoapheader_map =
    {
    	0xDA1448D5,
    	"EnumTest",
    	L"EnumTest",
    	sizeof("EnumTest")-1,
    	sizeof("EnumTest")-1,
    	SOAPMAP_HEADER,
    	___EnumTestService_CEnumTestService_EnumTest_atlsoapheader_entries,
    	0,
    	0,
    	-1,
    	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
    	0xF29B2B15,
    	"urn:EnumTestService",
    	L"urn:EnumTestService",
    	sizeof("urn:EnumTestService")-1
    };
extern __declspec(selectany) const _soapmap * ___EnumTestService_CEnumTestService_funcs[] =
    {
    	&___EnumTestService_CEnumTestService_EnumTest_map,
    	NULL
    };

extern __declspec(selectany) const _soapmap * ___EnumTestService_CEnumTestService_headers[] =
    {
    	&___EnumTestService_CEnumTestService_EnumTest_atlsoapheader_map,
    	NULL
    };

ATL_NOINLINE inline const _soapmap ** CEnumTestService::GetFunctionMap()
    {
    return ___EnumTestService_CEnumTestService_funcs;
};

ATL_NOINLINE inline const _soapmap ** CEnumTestService::GetHeaderMap()
    {
    return ___EnumTestService_CEnumTestService_headers;
}

ATL_NOINLINE inline void * CEnumTestService::GetHeaderValue()
    {
    return this;
}

ATL_NOINLINE inline HRESULT CEnumTestService::CallFunction(
    	void *pvParam, 
    	const wchar_t *wszLocalName, 
    	int cchLocalName,
    	size_t nItem)
    {
    wszLocalName;
    cchLocalName;

    HRESULT hr = S_OK;

    switch(nItem)
	{
    case 0:
        {
            ___EnumTestService_CEnumTestService_EnumTest_struct *p = (___EnumTestService_CEnumTestService_EnumTest_struct *) pvParam;
            hr = EnumTest(p->InputEnum, &p->OutputEnum);
            break;
        }
    default:
        hr = E_FAIL;
    }

    return hr;
}

ATL_NOINLINE inline const wchar_t * CEnumTestService::GetNamespaceUri()
    {
    return L"urn:EnumTestService";
}

ATL_NOINLINE inline const char * CEnumTestService::GetNamespaceUriA()
    {
    return "urn:EnumTestService";
}

ATL_NOINLINE inline const char * CEnumTestService::GetServiceName()
    {
    return "EnumTestService";
}

//--- End Injected Code For Attribute 'soap_handler'
 // class CEnumTestService

} // namespace EnumTestService
