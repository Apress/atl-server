// MyObject.h : Declaration of the CMyObject

#pragma once
#include "resource.h"       // main symbols
#include <atlsoap.h>
[ emitidl(true) ];


// IMyObject
[
	object,
	uuid("0CA838BD-9423-4B78-8B3A-1E4B9698525B"),
	dual,	helpstring("IMyObject Interface"),
	pointer_default(unique)
]
__interface IMyObject : IDispatch
{
	[id(1)] HRESULT HelloWorld([in] BSTR bstrIn, [out, retval] BSTR *bstrOut);
};



// CMyObject

[
	coclass,
	threading("apartment"),
	vi_progid("BasicCOM.MyObject"),
	progid("BasicCOM.MyObject.1"),
	version(1.0),
	uuid("D958904B-F324-496A-9DB9-016F01D5BAF3"),
	helpstring("MyObject Class"),

	// Add these additional attributes
	request_handler(name="Default", sdl="GenWSDL"),
	soap_handler(name="MyObject")
]
class ATL_NO_VTABLE CMyObject : 
	public IMyObject
{
public:
	CMyObject()
	{
	}


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

	// add the soap_method attribute to the interface method implementation
	[ soap_method ]
	HRESULT HelloWorld(BSTR bstrIn, BSTR *bstrOut)
	{
		CComBSTR bstrRet = L"Hello ";
		bstrRet+= bstrIn;
		bstrRet+= "!";

		*bstrOut = bstrRet.Detach();

		return S_OK;
	}

public:

};

