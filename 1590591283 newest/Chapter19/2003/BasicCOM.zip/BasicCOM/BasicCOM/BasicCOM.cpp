// BasicCOM.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{5158CA43-81FD-41F3-9A4A-22C6B14D0F66}", 
		 name = "BasicCOM", 
		 helpstring = "BasicCOM 1.0 Type Library",
		 resource_name = "IDR_BASICCOM") ];
