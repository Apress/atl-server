// MyObject.cpp : Implementation of CMyObject

#include "stdafx.h"
#include "MyObject.h"


// CMyObject
