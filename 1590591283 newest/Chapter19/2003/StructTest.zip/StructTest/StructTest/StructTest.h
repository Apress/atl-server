// StructTest.h : Defines the ATL Server request handler class
//
#pragma once

namespace StructTestService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

[ export ]
struct TestStruct
{
	int IntegerValue;
	BSTR StringValue;
};

// IStructTestService - web service interface declaration
//
[
	uuid("FFCF67A4-D9C9-4F54-BE04-E30A6B62E9C2"), 
	object
]
__interface IStructTestService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT StructTest([in] TestStruct InputStruct, [out, retval] TestStruct *OutputStruct);
	// TODO: Add additional web service methods here
};


// StructTestService - web service implementation
//
[
	request_handler(name="Default", sdl="GenStructTestWSDL"),
	soap_handler(
		name="StructTestService", 
		namespace="urn:StructTestService",
		protocol="soap"
	)
]
class CStructTestService :
	public IStructTestService
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT StructTest(/*[in]*/ TestStruct InputStruct, /*[out, retval]*/ TestStruct *OutputStruct)
	{
		OutputStruct->IntegerValue = InputStruct.IntegerValue;
		if (InputStruct.StringValue)
		{
			OutputStruct->StringValue = SysAllocString(InputStruct.StringValue);
			if (!OutputStruct->StringValue)
				return E_OUTOFMEMORY;
		}
		else
		{
			OutputStruct->StringValue = NULL;
		}

		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CStructTestService

} // namespace StructTestService
