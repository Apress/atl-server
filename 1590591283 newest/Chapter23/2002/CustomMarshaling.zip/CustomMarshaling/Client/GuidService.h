//
// sproxy.exe generated file
// do not modify this file
//
// Created: 02/15/2002@01:10:27
//

#pragma once

/*#include <atlsoap.h>*/
#include "atlsoap.h"

#define SOAPTYPE_GUID SOAPTYPE_USERBASE + 1

inline HRESULT AtlGenXMLValue<GUID>(IWriteStream *pStream, GUID *pVal)
{
	if ((pStream == NULL) || (pVal == NULL))
	{
		return E_INVALIDARG;
	}
	
	CStringA strFormattedGUID;
	_ATLTRY
	{
		strFormattedGUID.Format("%08lX-%04X-%04x-%02X%02X-%02X%02X%02X%02X%02X%02X", 
								pVal->Data1, pVal->Data2, pVal->Data3, 
								pVal->Data4[0], pVal->Data4[1], pVal->Data4[2], pVal->Data4[3], 
								pVal->Data4[4], pVal->Data4[5], pVal->Data4[6], pVal->Data4[7]);
	}
	_ATLCATCHALL()
	{
		return E_OUTOFMEMORY;
	}

	return pStream->WriteStream(strFormattedGUID, -1, NULL);
}

inline HRESULT AtlGetSAXValue<GUID>(GUID *pVal, const wchar_t *wsz, int cch)
{
	ATLASSERT( wsz != NULL );

	if (!pVal)
	{
		return E_POINTER;
	}

	/*
	typedef struct _GUID {
		unsigned long  Data1;
		unsigned short Data2;
		unsigned short Data3;
		unsigned char  Data4[ 8 ];
	} GUID;
	We also know that a guid should look like:
	7063652D-D5FC-41cd-9D19-20E378B5DBA7
	(Data1 on 8 hex digits) -
	(Data2 on 4 hex digits)-
	(Data3 on 4 hex digits)-
	(Data4[0] on 2 hex digits, Data4[1] on 2 hex digits) -
	(Data4[i] on 2 hex digits for each i between 2 and 7, everything in hex);
	
	Therefore, the whole length should be 8 + 1 +4 +1 + 4 + 1 + 2*2 + 1 + 2*6 = 36
	*/


	HRESULT hr = S_OK;

	if( cch != 36 )
	{
		return E_FAIL;
	}


	// start converting
	const wchar_t *pReadBuff = wsz;

	_ATLTRY
	{
		CStringW	strWork;
		wchar_t		*wszEnd;

		strWork.SetString(pReadBuff, 8);
		pVal->Data1 = (unsigned long)wcstoul( strWork, &wszEnd, 16);
		if( *wszEnd != '\0' || errno == ERANGE)
		{
			return E_FAIL;
		}
		pReadBuff += 9; // (Data1 on 8 hex digits) + dash

		strWork.SetString(pReadBuff, 4);
		pVal->Data2 = (unsigned short)wcstoul( strWork, &wszEnd, 16);
		if( *wszEnd != '\0' || errno == ERANGE)
		{
			return E_FAIL;
		}
		pReadBuff += 5; // (Data2 on 4 hex digits) + dash

		strWork.SetString(pReadBuff, 4);
		pVal->Data3 = (unsigned short)wcstoul( strWork, &wszEnd, 16);
		if( *wszEnd != '\0' || errno == ERANGE)
		{
			return E_FAIL;
		}
		pReadBuff += 5; // (Data3 on 4 hex digits) + dash

		strWork.SetString(pReadBuff, 2);
		pVal->Data4[0] = (unsigned char)wcstoul( strWork, &wszEnd, 16);
		if( *wszEnd != '\0' || errno == ERANGE)
		{
			return E_FAIL;
		}
		pReadBuff += 2; // (Data4[0] on 2 hex digits)

		strWork.SetString(pReadBuff, 2);
		pVal->Data4[1] = (unsigned char)wcstoul( strWork, &wszEnd, 16);
		if( *wszEnd != '\0' || errno == ERANGE)
		{
			return E_FAIL;
		}
		pReadBuff += 3; // (Data4[1] on 2 hex digits) + dash



		for( int iIndex = 2; iIndex < 8; iIndex ++)
		{
			strWork.SetString(pReadBuff, 2);
			pVal->Data4[iIndex] = (unsigned char)wcstoul( strWork, &wszEnd, 16);
			if( *wszEnd != '\0' || errno == ERANGE)
			{
				return E_FAIL;
			}
			pReadBuff += 2; // (Data4[iIndex] on 2 hex digits)
		}

		hr = S_OK;
	}
	_ATLCATCHALL()
	{
		hr = E_OUTOFMEMORY;
	}

	return hr;
}


namespace GuidService
{

struct someStruct
{
	BSTR strVal;
	/*BSTR*/GUID guidVal;
};

template <typename TClient = CSoapSocketClientT<> >
class CGuidServiceT : 
	public TClient, 
	public CSoapRootHandler
{
protected:

	const _soapmap ** GetFunctionMap();
	const _soapmap ** GetHeaderMap();
	void * GetHeaderValue();
	const wchar_t * GetNamespaceUri();
	const char * GetServiceName();
	const char * GetNamespaceUriA();
	HRESULT CallFunction(
		void *pvParam, 
		const wchar_t *wszLocalName, int cchLocalName,
		size_t nItem);
	HRESULT GetClientReader(ISAXXMLReader **ppReader);

public:

	HRESULT __stdcall QueryInterface(REFIID riid, void **ppv)
	{
		if (ppv == NULL)
		{
			return E_POINTER;
		}

		*ppv = NULL;

		if (InlineIsEqualGUID(riid, IID_IUnknown) ||
			InlineIsEqualGUID(riid, IID_ISAXContentHandler))
		{
			*ppv = static_cast<ISAXContentHandler *>(this);
			return S_OK;
		}

		return E_NOINTERFACE;
	}

	ULONG __stdcall AddRef()
	{
		return 1;
	}

	ULONG __stdcall Release()
	{
		return 1;
	}

	CGuidServiceT(ISAXXMLReader *pReader = NULL)
		:TClient(_T("http://localhost/TestServer/TestServer.dll\?Handler=Default"))
	{
		SetClient(true);
		SetReader(pReader);
	}
	
	~CGuidServiceT()
	{
		Uninitialize();
	}
	
	void Uninitialize()
	{
		UninitializeSOAP();
	}	

	HRESULT RetGuidSoap(
		someStruct x, 
		someStruct* __retval
	);
};

typedef CGuidServiceT<> CGuidService;

__if_not_exists(__someStruct_entries)
{
extern __declspec(selectany) const _soapmapentry __someStruct_entries[] =
{
	{ 
		0x14B458BC, 
		"strVal", 
		L"strVal", 
		sizeof("strVal")-1, 
		SOAPTYPE_STRING, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(someStruct, strVal),
		NULL, 
		NULL, 
		-1 
	},
	{ 
		0x113E60CC, 
		"guidVal", 
		L"guidVal", 
		sizeof("guidVal")-1, 
		/*SOAPTYPE_STRING*/SOAPTYPE_GUID, 
		SOAPFLAG_FIELD | SOAPFLAG_NULLABLE, 
		offsetof(someStruct, guidVal),
		NULL, 
		NULL, 
		-1 
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __someStruct_map =
{
	0x138595F9,
	"someStruct",
	L"someStruct",
	sizeof("someStruct")-1,
	sizeof("someStruct")-1,
	SOAPMAP_STRUCT,
	__someStruct_entries,
	sizeof(someStruct),
	2,
	-1,
	SOAPFLAG_NONE,
	0x03904EC9,
	"urn:GuidService",
	L"urn:GuidService",
	sizeof("urn:GuidService")-1
};
}

struct __CGuidService_RetGuidSoap_struct
{
	someStruct x;
	someStruct __retval;
};

extern __declspec(selectany) const _soapmapentry __CGuidService_RetGuidSoap_entries[] =
{

	{
		0x00000078, 
		"x", 
		L"x", 
		sizeof("x")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_IN | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
		offsetof(__CGuidService_RetGuidSoap_struct, x),
		NULL,
		&__someStruct_map,
		-1,
	},
	{
		0x11515F60, 
		"return", 
		L"return", 
		sizeof("return")-1, 
		SOAPTYPE_UNK, 
		SOAPFLAG_NONE | SOAPFLAG_OUT | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
		offsetof(__CGuidService_RetGuidSoap_struct, __retval),
		NULL,
		&__someStruct_map,
		-1,
	},
	{ 0x00000000 }
};

extern __declspec(selectany) const _soapmap __CGuidService_RetGuidSoap_map =
{
	0xC90EF8E7,
	"RetGuidSoap",
	L"RetGuidSoap",
	sizeof("RetGuidSoap")-1,
	sizeof("RetGuidSoap")-1,
	SOAPMAP_FUNC,
	__CGuidService_RetGuidSoap_entries,
	sizeof(__CGuidService_RetGuidSoap_struct),
	1,
	-1,
	SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
	0x03904EC9,
	"urn:GuidService",
	L"urn:GuidService",
	sizeof("urn:GuidService")-1
};

extern __declspec(selectany) const _soapmap * __CGuidService_funcs[] =
{
	&__CGuidService_RetGuidSoap_map,
	NULL
};

template <typename TClient>
inline HRESULT CGuidServiceT<TClient>::RetGuidSoap(
		someStruct x, 
		someStruct* __retval
	)
{
	HRESULT __atlsoap_hr = InitializeSOAP(NULL);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_INITIALIZE_ERROR);
		return __atlsoap_hr;
	}
	
	CleanupClient();

	CComPtr<IStream> __atlsoap_spReadStream;
	__CGuidService_RetGuidSoap_struct __params;
	memset(&__params, 0x00, sizeof(__params));
	__params.x = x;

	__atlsoap_hr = SetClientStruct(&__params, 0);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_OUTOFMEMORY);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = GenerateResponse(GetWriteStream());
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_GENERATE_ERROR);
		goto __skip_cleanup;
	}
	
	__atlsoap_hr = SendRequest(_T("SOAPAction: \"#RetGuidSoap\"\r\n"));
	if (FAILED(__atlsoap_hr))
	{
		goto __skip_cleanup;
	}
	__atlsoap_hr = GetReadStream(&__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_READ_ERROR);
		goto __skip_cleanup;
	}
	
	// cleanup any in/out-params and out-headers from previous calls
	Cleanup();
	__atlsoap_hr = BeginParse(__atlsoap_spReadStream);
	if (FAILED(__atlsoap_hr))
	{
		SetClientError(SOAPCLIENT_PARSE_ERROR);
		goto __cleanup;
	}

	*__retval = __params.__retval;
	goto __skip_cleanup;
	
__cleanup:
	Cleanup();
__skip_cleanup:
	ResetClientState(true);
	memset(&__params, 0x00, sizeof(__params));
	return __atlsoap_hr;
}

template <typename TClient>
ATL_NOINLINE inline const _soapmap ** CGuidServiceT<TClient>::GetFunctionMap()
{
	return __CGuidService_funcs;
}

template <typename TClient>
ATL_NOINLINE inline const _soapmap ** CGuidServiceT<TClient>::GetHeaderMap()
{
	static const _soapmapentry __CGuidService_RetGuidSoap_atlsoapheader_entries[] =
	{
		{ 0x00000000 }
	};

	static const _soapmap __CGuidService_RetGuidSoap_atlsoapheader_map = 
	{
		0xC90EF8E7,
		"RetGuidSoap",
		L"RetGuidSoap",
		sizeof("RetGuidSoap")-1,
		sizeof("RetGuidSoap")-1,
		SOAPMAP_HEADER,
		__CGuidService_RetGuidSoap_atlsoapheader_entries,
		0,
		0,
		-1,
		SOAPFLAG_NONE | SOAPFLAG_RPC | SOAPFLAG_ENCODED,
		0x03904EC9,
		"urn:GuidService",
		L"urn:GuidService",
		sizeof("urn:GuidService")-1
	};


	static const _soapmap * __CGuidService_headers[] =
	{
		&__CGuidService_RetGuidSoap_atlsoapheader_map,
		NULL
	};
	
	return __CGuidService_headers;
}

template <typename TClient>
ATL_NOINLINE inline void * CGuidServiceT<TClient>::GetHeaderValue()
{
	return this;
}

template <typename TClient>
ATL_NOINLINE inline const wchar_t * CGuidServiceT<TClient>::GetNamespaceUri()
{
	return L"urn:GuidService";
}

template <typename TClient>
ATL_NOINLINE inline const char * CGuidServiceT<TClient>::GetServiceName()
{
	return NULL;
}

template <typename TClient>
ATL_NOINLINE inline const char * CGuidServiceT<TClient>::GetNamespaceUriA()
{
	return "urn:GuidService";
}

template <typename TClient>
ATL_NOINLINE inline HRESULT CGuidServiceT<TClient>::CallFunction(
	void *, 
	const wchar_t *, int,
	size_t)
{
	return E_NOTIMPL;
}

template <typename TClient>
ATL_NOINLINE inline HRESULT CGuidServiceT<TClient>::GetClientReader(ISAXXMLReader **ppReader)
{
	if (ppReader == NULL)
	{
		return E_INVALIDARG;
	}
	
	CComPtr<ISAXXMLReader> spReader = GetReader();
	if (spReader.p != NULL)
	{
		*ppReader = spReader.Detach();
		return S_OK;
	}
	return TClient::GetClientReader(ppReader);
}

} // namespace GuidService

inline HRESULT AtlCleanupValue<GuidService::someStruct>(GuidService::someStruct *pVal)
{
	pVal;
	AtlCleanupValue(&pVal->strVal);
	AtlCleanupValue(&pVal->guidVal);
	return S_OK;
}

inline HRESULT AtlCleanupValueEx<GuidService::someStruct>(GuidService::someStruct *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	AtlCleanupValueEx(&pVal->strVal, pMemMgr);
	AtlCleanupValueEx(&pVal->guidVal, pMemMgr);
	return S_OK;
}

inline HRESULT AtlCleanupValue<GUID>(GUID *pVal)
{
	pVal;
	return S_OK;
}

inline HRESULT AtlCleanupValueEx<GUID>(GUID *pVal, IAtlMemMgr *pMemMgr)
{
	pVal;
	pMemMgr;
	
	return S_OK;
}
