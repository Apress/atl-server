// Client.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#define _WIN32_WINDOWS 0x0500
#include "GuidService.h"
using namespace GuidService;


int _tmain(int argc, _TCHAR* argv[])
{
	CoInitialize(NULL);
	{
		CGuidService	service;
		someStruct		stIn, stOut;

		CoCreateGuid(&stIn.guidVal);
		stIn.strVal = SysAllocString(L"TestVal");
		HRESULT hRet = service.RetGuidSoap(stIn, &stOut);
		if( SUCCEEDED(hRet) )
		{
				
			printf("Success -- \n [in]GUID -- (%s) is identical to  \n[out]GUID -- (%s)\n", stIn.guidVal, stOut.guidVal);
		}
		else
		{
			printf("Error in executing the request\n");
		}
		AtlCleanupValue(&stIn);
	}
	CoUninitialize();
	return 0;
}

