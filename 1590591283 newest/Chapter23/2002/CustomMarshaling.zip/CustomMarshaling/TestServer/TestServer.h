// TestServer.h : Defines the ATL Server request handler class
//
#pragma once

namespace TestServerService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// ITestServerService - web service interface declaration
//
[
	uuid("05CB4E48-4280-4266-9CE7-53E37546AF07"), 
	object
]
__interface ITestServerService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT RetGuidSoap([in] BSTR x, [out, retval] BSTR *result);
	// TODO: Add additional web service methods here
};


// TestServerService - web service implementation
//
[
	request_handler(name="Default", sdl="GenTestServerWSDL"),
	soap_handler(
		name="TestServerService", 
		namespace="urn:TestServerService",
		protocol="soap"
	)
]
class CTestServerService :
	public ITestServerService
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT RetGuidSoap(/*[in]*/ BSTR x, /*[out, retval]*/ BSTR *result)
	{
		CComBSTR bstrOut;
		bstrOut.Append(x);
		*result = bstrOut.Detach();
		
		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CTestServerService

} // namespace TestServerService
