// HW.h : Defines the ATL Server request handler class
//
#pragma once

namespace HWService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace

// IHWService - web service interface declaration
//
[
	uuid("68DFCBE0-CD62-4CEB-BB26-B5D38994F4BF"), 
	object
]
__interface IHWService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT HelloWorld([in] BSTR bstrInput, [out, retval] BSTR *bstrOutput);
	// TODO: Add additional web service methods here
};


// HWService - web service implementation
//
[
	request_handler(name="Default", sdl="GenHWWSDL"),
	soap_handler(
		name="HWService", 
		namespace="urn:HWService",
		protocol="soap"
	)
]
class CHWService :
	public IHWService
{
public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT HelloWorld(/*[in]*/ BSTR bstrInput, /*[out, retval]*/ BSTR *bstrOutput)
	{
		CComBSTR bstrOut(L"Hello ");
		bstrOut += bstrInput;
		bstrOut += L"!";
		*bstrOutput = bstrOut.Detach();
		
		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CHWService

} // namespace HWService
