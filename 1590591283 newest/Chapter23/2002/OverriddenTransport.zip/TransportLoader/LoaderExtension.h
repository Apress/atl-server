#ifndef _LOADEREXTENSION_H_INCLUDED
#define _LOADEREXTENSION_H_INCLUDED


#pragma once
/*
	CLoaderExtension -- limited IIsapiExtension implementation designed to work with a standalone loader
*/
class CLoaderExtension: public IServiceProvider, public IIsapiExtension
{
protected:

	CWorkerThread<> m_WorkerThread;
	CDllCache<CWorkerThread<>, CDllCachePeer> m_DllCache;
	CIsapiWorker m_Worker;
	CDefaultErrorProvider m_UserErrorProvider;
public:

	CString m_strErr;
	
	CLoaderExtension() throw()
	{
	}

	AtlServerRequest *CreateRequest()
	{
		AtlServerRequest *pRequest = (AtlServerRequest *) malloc(max(sizeof(AtlServerRequest), sizeof(CComObjectNoLock<CServerContext>)));
		if (!pRequest)
			return NULL;
		pRequest->cbSize = sizeof(AtlServerRequest);
		return pRequest;
	}

	void FreeRequest(AtlServerRequest *pRequest)
	{
		if (pRequest)
		{
			if (pRequest->pHandler)
				pRequest->pHandler->Release();
			if (pRequest->pServerContext)
				pRequest->pServerContext->Release();
			if (pRequest->pDllCache && pRequest->hInstDll)
				pRequest->pDllCache->ReleaseModule(pRequest->hInstDll);
		}

	}

	BOOL Initialize() throw()
	{
		if (!m_Worker.Initialize(static_cast<IIsapiExtension*>(this)))
			return FALSE;

		if (S_OK != m_WorkerThread.Initialize())
			return FALSE;

		if (FAILED(m_DllCache.Initialize(&m_WorkerThread, ATL_DLL_CACHE_TIMEOUT)))
		{
			m_WorkerThread.Shutdown();
			return FALSE;
		}

		return TRUE;
	}

	BOOL Uninitialize() throw()
	{
		m_WorkerThread.Shutdown();
		m_DllCache.Uninitialize();
		m_Worker.Terminate(static_cast<IIsapiExtension*>(this));
		return TRUE;
	}

	void RequestComplete(AtlServerRequest * /*pRequestInfo*/, DWORD /*dwStatus*/, DWORD /*dwSubStatus*/) throw()
	{
	}

	HTTP_CODE GetHandlerName(LPCSTR szFileName, LPSTR szHandlerName) throw()
	{
		return _AtlGetHandlerName(szFileName, szHandlerName);
	}

	
	HTTP_CODE LoadDispatchFile(LPCSTR szFileName, AtlServerRequest *pRequestInfo)
	{
		ATLASSERT(szFileName);
		ATLASSERT(pRequestInfo);

		CStencil *pStencil = NULL;
		HCACHEITEM hStencil = NULL;

		// Must have space for the path to the handler + the maximum size
		// of the handler, plus the '/' plus the '\0'
		CHAR szDllPath[MAX_PATH];
		CHAR szHandlerName[ATL_MAX_HANDLER_NAME_LEN+1];

		pRequestInfo->pHandler = NULL;
		pRequestInfo->hInstDll = NULL;


		if (!hStencil)
		{
			CHAR szHandlerDllName[MAX_PATH+ATL_MAX_HANDLER_NAME_LEN+1];
			*szHandlerDllName = '\0';

			// not in the cache, so open the file
			HTTP_CODE hcErr = GetHandlerName(szFileName, szHandlerDllName);
			if (hcErr)
				return hcErr;
			DWORD dwDllPathLen = MAX_PATH;
			DWORD dwHandlerNameLen = ATL_MAX_HANDLER_NAME_LEN+1;
			if (!_AtlCrackHandler(szHandlerDllName, szDllPath, &dwDllPathLen, szHandlerName, &dwHandlerNameLen))
			{
				return AtlsHttpError(500, ISE_SUBERR_HANDLER_NOT_FOUND);
			}
			ATLASSERT(*szHandlerName);
			ATLASSERT(*szDllPath);
			if (!*szHandlerName)
			{
				return AtlsHttpError(500, ISE_SUBERR_HANDLER_NOT_FOUND);
			}
		}


		return LoadRequestHandler(szDllPath, szHandlerName, pRequestInfo->pServerContext, 
			&pRequestInfo->hInstDll, &pRequestInfo->pHandler);
	}


	HTTP_CODE LoadDllHandler(LPCSTR szFileName, AtlServerRequest *pRequestInfo)
	{
		ATLASSERT(szFileName);
		ATLASSERT(pRequestInfo);

		_ATLTRY
		{
			HTTP_CODE hcErr = HTTP_SUCCESS;
			CHAR szHandler[ATL_MAX_HANDLER_NAME_LEN+1] = { 'D', 'e', 'f', 'a', 'u', 'l', 't', '\0' };
			LPCSTR szQueryString = pRequestInfo->pServerContext->GetQueryString();
			if (szQueryString != NULL)
			{
				LPCSTR szHdlr = strstr(szQueryString, "Handler=");
				if (szHdlr != NULL)
				{
					if ((szHdlr == szQueryString) ||
						((szHdlr > szQueryString) && (*(szHdlr-1) == '&')))
					{
						int nCnt = 0;
						LPSTR pszHandler = szHandler;
						szHdlr += sizeof("Handler=")-1;
						while (*szHdlr && *szHdlr != '&')
						{
							if (nCnt < ATL_MAX_HANDLER_NAME_LEN)
							{
								*pszHandler++ = *szHdlr++;
								nCnt++;
							}
							else
							{
								hcErr = AtlsHttpError(500, ISE_SUBERR_HANDLER_NOT_FOUND);
								break;
							}
						}
						if (hcErr == HTTP_SUCCESS)
						{
							*pszHandler = '\0';
						}
					}
				}
			}

			if (hcErr == HTTP_SUCCESS)
			{
				CHAR szFile[MAX_PATH+ATL_MAX_HANDLER_NAME_LEN+1];
				if (SafeStringCopy(szFile, szFileName))
				{
					hcErr = LoadRequestHandler(szFile, szHandler, pRequestInfo->pServerContext, &pRequestInfo->hInstDll, &pRequestInfo->pHandler);
				}
				else
				{
					hcErr = AtlsHttpError(500, ISE_SUBERR_UNEXPECTED);
				}
			}

			return hcErr;
		}
		_ATLCATCHALL()
		{
			return AtlsHttpError(500, ISE_SUBERR_UNEXPECTED);
		}
	}



	BOOL DispatchStencilCall(AtlServerRequest * /*pRequestInfo*/) throw()
	{
		return FALSE;
	}

	virtual void ThreadTerminate(DWORD /*dwThreadId*/) { }
    virtual BOOL QueueRequest(AtlServerRequest * /*pRequestInfo*/) { return FALSE; }
	virtual CIsapiWorker *GetThreadWorker() { return &m_Worker; }
	virtual BOOL SetThreadWorker(CIsapiWorker * /*pWorker*/) { return TRUE; }
	BOOL OnThreadAttach() { return TRUE; }
	void OnThreadTerminate() {}


	BOOL ExecuteRequestDirect(IHttpServerContext		*pServerContext)
	{
		if( !pServerContext )
		{
			return NULL;
		}


		AtlServerRequest RequestInfo;
		AtlServerRequest *pRequestInfo = &RequestInfo;
		pRequestInfo->pServerContext = pServerContext;
		pRequestInfo->dwRequestType = ATLSRV_REQUEST_STENCIL;
		pRequestInfo->dwRequestState = ATLSRV_STATE_BEGIN;
		pRequestInfo->pExtension = static_cast<IIsapiExtension*>(this);
		pRequestInfo->pDllCache = static_cast<IDllCache *>(&m_DllCache);
		pRequestInfo->dwStartTicks = 0;

		HTTP_CODE hcErr = HTTP_SUCCESS;
		if (pRequestInfo->dwRequestState == ATLSRV_STATE_BEGIN)
        {
			LPCSTR szFileName = pServerContext->GetScriptPathTranslated();

            if (!szFileName)
			{
				m_strErr.Format(_T("ERROR: Invalid file: %s"), szFileName);
				RequestComplete(pRequestInfo, 500, 8);
				return FALSE;
			}

			LPCSTR szDot = szFileName + strlen(szFileName)-4;
			if (stricmp(szDot, c_AtlSRFExtension) == 0)
			{
				pRequestInfo->dwRequestType = ATLSRV_REQUEST_STENCIL;
			    hcErr = LoadDispatchFile(szFileName, pRequestInfo);
			}
			else if (_stricmp(szDot, ".dll") == 0)
		    {
                pRequestInfo->dwRequestType = ATLSRV_REQUEST_DLL;
		        hcErr = LoadDllHandler(szFileName, pRequestInfo);
            }
			else
			{
				hcErr = HTTP_FAIL;
			}

			if (hcErr)
			{
				if (hcErr == HTTP_ERROR(500, ISE_SUBERR_BADSRF))
					m_strErr.Format(_T("ERROR: Invalid SRF file: %s"), szFileName);
				else if (hcErr == HTTP_ERROR(500, ISE_SUBERR_READFILEFAIL))
					m_strErr.Format(_T("ERROR: Failed to read SRF file: %s"), szFileName);
				else if (hcErr == HTTP_ERROR(500, ISE_SUBERR_UNEXPECTED))
					m_strErr = _T("ERROR: Unexpected Error Loading DLL");
				RequestComplete(pRequestInfo, HTTP_ERROR_CODE(hcErr), HTTP_SUBERROR_CODE(hcErr));
				return FALSE;
			}

			// initialize the handler
			DWORD dwStatus = 0;

			hcErr = pRequestInfo->pHandler->GetFlags(&dwStatus);
			// Ignoring caching options
			// Log errors on async
			if (dwStatus & ATLSRV_INIT_USEASYNC)
			{
				// TODO: Log error, or come up with a way to make it work
				RequestComplete(pRequestInfo, 500, SUBERR_NONE);
				return FALSE;
			}

			hcErr = pRequestInfo->pHandler->InitializeHandler(pRequestInfo, static_cast<IServiceProvider*>(this));
			if (hcErr == HTTP_SUCCESS)
				hcErr = pRequestInfo->pHandler->HandleRequest(pRequestInfo, static_cast<IServiceProvider*>(this));
		}

        if (hcErr == HTTP_SUCCESS_ASYNC || hcErr == HTTP_SUCCESS_ASYNC_DONE)
		{
			// TODO: Log error or fix
		}
        else
		{
			pRequestInfo->pHandler->UninitializeHandler();
		    RequestComplete(pRequestInfo, HTTP_ERROR_CODE(hcErr), HTTP_SUBERROR_CODE(hcErr));
		}

		FreeRequest(pRequestInfo);
		return TRUE;
	}

	HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void **ppv) throw()
	{
		if (!ppv)
			return E_POINTER;
		if (InlineIsEqualGUID(riid, __uuidof(IUnknown)) ||
			InlineIsEqualGUID(riid, __uuidof(IServiceProvider)))
		{
			*ppv = static_cast<IUnknown*>(static_cast<IServiceProvider*>(this));
			AddRef();
			return S_OK;
		}
		if (InlineIsEqualGUID(riid, __uuidof(IIsapiExtension)))
		{
			*ppv = static_cast<IUnknown*>(static_cast<IIsapiExtension*>(this));
			AddRef();
			return S_OK;
		}
		return E_NOINTERFACE;
	}

	virtual HRESULT STDMETHODCALLTYPE QueryService(
		REFGUID guidService,
		REFIID riid,
		void **ppvObject) throw()
	{
		if (!ppvObject)
			return E_POINTER;

		if (InlineIsEqualGUID(guidService, __uuidof(IDllCache)))
			return m_DllCache.QueryInterface(riid, ppvObject);

		return E_NOINTERFACE;
	}


	virtual HRESULT AddService(REFGUID guidService, REFIID riid, IUnknown *punk, HINSTANCE hInstance) throw()
	{
		return E_NOTIMPL;
	}

	virtual HRESULT RemoveService(REFGUID guidService, REFIID riid) throw()
	{	
		return E_NOTIMPL;
	}

	HRESULT GetService(REFGUID guidService, REFIID riid, void **ppvObject) throw()
	{
		return E_NOTIMPL;
	}

	ULONG STDMETHODCALLTYPE AddRef()
	{
		return 1;
	}
	
	ULONG STDMETHODCALLTYPE Release()
	{
		return 1;
	}

	HTTP_CODE LoadRequestHandler(LPCSTR szDllPath, LPCSTR szHandlerName, IHttpServerContext *pServerContext,
		HINSTANCE *phInstance, IRequestHandler **ppHandler) throw()
	{
		return _AtlLoadRequestHandler(szDllPath, szHandlerName, pServerContext, phInstance, 
			ppHandler, this, static_cast<IDllCache*>(&m_DllCache));
	} // LoadRequestHandler


	HTTP_CODE TransferRequest(
		AtlServerRequest *pRequest, 
		IServiceProvider *pServiceProvider,
		IWriteStream *pWriteStream,
		IHttpRequestLookup *pLookup,
		LPCSTR szNewUrl,
		WORD nCodePage,
		bool bContinueAfterProcess = false,
		CStencilState *pState = NULL)
	{
		return _AtlTransferRequest(pRequest, pServiceProvider, pWriteStream,
			pLookup, szNewUrl, nCodePage, bContinueAfterProcess, pState);
	}
};


#endif //_LOADEREXTENSION_H_INCLUDED