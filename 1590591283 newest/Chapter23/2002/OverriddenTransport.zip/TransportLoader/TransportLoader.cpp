// TransportLoader.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "StreamOnString.h"
#include "LoaderExtension.h"
#include "LoaderServerCtxt.h"


#include <iostream>
#include <fstream>
using namespace std;

bool	LoadInputFile(CStringA& strURL, CStringA& strSOAPAction, CReadWriteStreamOnCString& buffReq);
bool	WriteOutputFile(CReadWriteStreamOnCString& buffRes);
bool	ResolveDLLMapping(LPCTSTR szDLLName, CString& strFulPath);

struct	stDLLMapping
{
	LPCTSTR	szDLLName;
	LPCTSTR	szDLLPath;
};

stDLLMapping	g_arMappings[] = 
{
	{
		_T("HW.dll"),
		_T("..\\HW\\Debug\\HW.dll")
	}
};


bool ProcessRequest()
{
	CStringA strUrl,strSoapAction;
	CLoaderServerContext	srvCtxt;

	/*
		Load the input file. Identify the URL and the SOAP Action as the 
		first two lines of the input file
	*/
	if(!LoadInputFile(strUrl, strSoapAction, srvCtxt.m_requestStream))
	{
		_tprintf(_T("Failure in loading the request file\n"));
		return false;
	}
	/*
		Parse the URL. Extract the DLL file name, without path, 
		to be used in mapping, and the HTTP Query parameters
		(?Handler=...)
	*/
	srvCtxt.SetUrl(strUrl, strSoapAction);

	// Convert the DLL Name as isolated by SetUrl to a fully qualified DLL path
	CString	strDLLFullPath;
	if( !ResolveDLLMapping(srvCtxt.m_strDLLFileName, strDLLFullPath) )
	{
		_tprintf(_T("Failure in resolving the DLL Name\n"));
		return false;
	}
	
	
	//	Map the DLL file name to a physical DLL name
	srvCtxt.SetSoapAppDllPath(strDLLFullPath);
	
	
	// The stand-alone ISAPI Extension
	CLoaderExtension		ext;

	if(!ext.Initialize())
	{
		_tprintf(_T("Failed in initializing the ISAPI Extension\n"));
		return false;
	}

	BOOL bExecRet = ext.ExecuteRequestDirect( &srvCtxt);
	ext.Uninitialize();
	if(!bExecRet )
	{
		_tprintf(_T("Failed in executing the SOAP request\n"));
		
		return false;
	}


	if( ! WriteOutputFile( srvCtxt.m_responseStream ))
	{
		_tprintf(_T("Failure in generating the response\n"));
		return false;
	}
	return true;
}

int _tmain(int argc, _TCHAR* argv[])
{
	BOOL	bProcessingResult = FALSE;
	CoInitialize(NULL);
	_ATLTRY
	{
		bProcessingResult = ProcessRequest();
	}
	_ATLCATCHALL()
	{
		bProcessingResult = FALSE;
	}

	CoUninitialize();

	if( !bProcessingResult )
	{
		_tprintf(_T("Failure in processing the request\n"));
	}
	else
	{
		_tprintf(_T("Request processed successfully\n"));
	}



	return 0;
}




bool	LoadInputFile(CStringA& strURL, CStringA& strSOAPAction, CReadWriteStreamOnCString& buffReq)
{
	char		inputFileName[MAX_PATH];
	bool		bRet = true;
	ifstream	inputStream;
	const	int	maxURLSize = 2048;
	char		szWorkBuffer[maxURLSize];
	
	cout	<<	"Please specify the input file:";
	cin		>>	inputFileName;
	
	inputStream.open( inputFileName);

	if( !inputStream.is_open() )
	{
		cerr	<<	"ERROR - Cannot open request file :"	<<	inputFileName	<<	endl;	
		return false;
	}

	inputStream >> szWorkBuffer;
	strURL	=	szWorkBuffer;


	inputStream >> szWorkBuffer;
	strSOAPAction	=	szWorkBuffer;

	while( !inputStream.eof() )
	{
		memset(szWorkBuffer, 0, maxURLSize);
		inputStream.read(szWorkBuffer, maxURLSize);
		buffReq.WriteStream( szWorkBuffer, -1, NULL );
	}

	inputStream.close();

	if( strURL.IsEmpty() )
	{
		cerr	<<	"ERROR - Empty URL(the first line in the input file)"	<<	endl;	
		bRet	=	false;
	}

	if( bRet && !strSOAPAction.IsEmpty())
	{
		// the stream formats the soap action
		strSOAPAction	+=	"\r\n";
	}
	return bRet;
}





bool	WriteOutputFile(CReadWriteStreamOnCString&	strmOut)
{
	char		outputFileName[MAX_PATH];
	bool		bRet = true;
	ofstream	outputStream;
	const	int	maxURLSize = 2048;
	
	cout	<<	"Please specify the output file:";
	cin		>>	outputFileName;
	
	outputStream.open( outputFileName);

	if( !outputStream.is_open() )
	{
		cerr	<<	"ERROR - Cannot open response file :"	<<	outputFileName	<<	endl;	
		return false;
	}

	
	
	outputStream	<<	(LPCSTR)strmOut.m_str;

	outputStream.close();

	return true;
}


bool ResolveDLLMapping(LPCTSTR szDLLName, CString& strFullDLLPath)
{
	int		iIndex, iSize;
	LPCTSTR	szDLLPath = NULL;
	iSize = sizeof(g_arMappings)/sizeof(stDLLMapping);

	// Lok for a mapping of the DLL name
	for( iIndex = 0; (szDLLPath == NULL) && (iIndex <= iSize); iIndex ++)
	{
		if( 0 == _tcsicmp( szDLLName, g_arMappings[iIndex].szDLLName) )
		{
			szDLLPath = g_arMappings[iIndex].szDLLPath;
		}
	}

	if( !szDLLPath )
	{
		return false;
	}
	//calculate it
	if( ::IsFullPath(szDLLPath) )
		strFullDLLPath = szDLLPath;
	else
	{
		TCHAR	curDir[MAX_PATH+1];
		::GetCurrentDirectory( MAX_PATH, curDir );
		
		if( szDLLPath[0] == '\\')
		{
			// PathCanonicalize does not handle root related paths
			strFullDLLPath.AppendChar( curDir[0]);
			strFullDLLPath.AppendChar( curDir[1]);
			strFullDLLPath.Append( szDLLPath);
		}
		else
		{
			TCHAR	tempBuff[2*MAX_PATH + 1];
			TCHAR	szFullDllPath[MAX_PATH + 1];
			_stprintf(tempBuff, curDir);
			_stprintf(tempBuff + strlen(curDir), "\\");
			_stprintf(tempBuff + strlen(tempBuff), szDLLPath);
			BOOL	bCanonicalized =	::PathCanonicalize( szFullDllPath, tempBuff);
			if(!bCanonicalized)
			{
				return false;
			}
			strFullDLLPath = szFullDllPath;
		}
	}
	return true;
}