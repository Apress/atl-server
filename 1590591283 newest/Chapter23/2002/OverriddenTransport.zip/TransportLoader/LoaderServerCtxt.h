#ifndef __LOADERSERVERCTXT_H_INCLUDED
#define __LOADERSERVERCTXT_H_INCLUDED

#define DEFAULT_SOAP_CONTENT_TYPE	"text/xml"
#define DEFAULT_SOAP_HTTP_VERB		"POST"
#define DEFAULT_SOAP_HTTP_VERSION	"HTTP/1.1"
#define DEFAULT_WSDL_HTTP_VERB		"GET"

class CLoaderServerContext : public IHttpServerContext
{
public:

	CReadWriteStreamOnCString	m_requestStream;
	CReadWriteStreamOnCString	m_responseStream;

	// The name of the DLL -- app.dll
	CString					m_strDLLFileName;
	
protected:
	// All the explanations below are for a URL like:
	// http://server/VDir/app.dll?Handler=Something
	
	
	// The physical path of the DLL -- C:\Work\Debug\app.dll
	CString					m_strDLLFilePath;
	
	// The URL -- http://server/VDir/app.dll?Handler=Something
	CString					m_strURL;


	//  The translated path -- C:\Work\Debug\app.dll
	char					m_szScriptPathTranslated[MAX_PATH + 1];

	// The Path Info -- /VDir/app.dll
	char					m_szPathInfo[ATL_URL_MAX_URL_LENGTH + 1];
	
	// The query string -- ?Handler=Something
	char					m_szQueryString[ATL_URL_MAX_URL_LENGTH + 1];
	
	// The HTTP verb of the requet, defaulted to POST
	// It becomes GET for a request with no body
	char					m_szVerb[MAX_PATH];
	
	// The HTTP version -- defaulted to HTTP/1.1
	char					m_szProtocol[MAX_PATH];
	

	// Map containing the HTTP headers. Has to be filled by the caller
	// Used in GetServerVariable
	typedef CAtlMap< 
				CStringA,
				CStringA,
				CStringElementTraitsI<CStringA>,
				CStringElementTraitsI<CStringA>
			   > HeaderMapType;

	HeaderMapType			m_requestHeaderMap;


public:


	// sets the soap app dll path - default "app.dll" from URL
	HRESULT		SetSoapAppDllPath(LPCTSTR		szFile)
	{
		if( _tcslen(szFile) >= MAX_PATH )
			return E_FAIL;

		
		m_strDLLFilePath = szFile;
		CT2A	szTemp(szFile);
		strcpy( m_szScriptPathTranslated, szTemp);
		SetPathTranslated();
		return S_OK;
	}

	
	HRESULT		SetProtocol(LPCSTR		szProtocol)
	{
		if( strlen(szProtocol) >= MAX_PATH )
			return E_FAIL;
		strcpy( m_szProtocol, szProtocol);
		return S_OK;
	}


	void SetUrl(LPCTSTR	tszURL, CString& strSOAPAction)
	{
		if( !tszURL )
		{
			return;
		}

		m_strURL = tszURL;

		// sets the QueryString
		// Assume that the URL looks like .....app.dll?Handler=....., i.e. a SOAP handler DLL
		
		// Looking for the end of the HTTP Request object
		LPCSTR	pQMark			=	tszURL?_tcschr( tszURL, (TCHAR)'?'):NULL;
		LPCSTR	pAppPathLimit	=	NULL;
		
		pAppPathLimit	=	tszURL + _tcslen(tszURL);

		if( pQMark != NULL )
		{
			if( _tcslen(pQMark+1) < ATL_URL_MAX_URL_LENGTH )
				_tcsncpy(m_szQueryString, pQMark+1, ATL_URL_MAX_URL_LENGTH);
			pAppPathLimit	=	pQMark;
		}

		LPCTSTR	pAppStart =	tszURL;
		LPCTSTR	pCurr	=	pAppStart;

		while( pCurr != pAppPathLimit )
			if( *pCurr++ == (TCHAR)('/'))
				pAppStart	=	pCurr;
				
		m_strDLLFileName.SetString( pAppStart, (int)(pAppPathLimit - pAppStart));

		// repeat the same until to get m_szPathInfo
		pAppStart = tszURL;
		pAppStart = _tcsstr( tszURL, _T("://"));
		if( pAppStart )
		{
			pAppStart += _tcslen(_T("://"));

			pAppStart = _tcschr(pAppStart, (TCHAR)'/');
			if( pAppStart )
			{
				int nCopy = min(ATL_URL_MAX_URL_LENGTH, (int)(pAppPathLimit - pAppStart));
				_tcsncpy( m_szPathInfo, pAppStart, nCopy);
				m_szPathInfo[nCopy] = (TCHAR)('\0');
			}
		}


		// If m_requestSTream is empty, the verb should be GET
		if( m_requestStream.m_nBodyLen == 0 )
		{
			_tcscpy( m_szVerb, DEFAULT_WSDL_HTTP_VERB);
		}
		else
		{
			_tcscpy( m_szVerb, DEFAULT_SOAP_HTTP_VERB);
		}

		// Set headers
		CStringA	strContentLength;
		strContentLength.Format("%d", m_requestStream.m_nBodyLen);
		m_requestHeaderMap.SetAt( "content-length", strContentLength);
		
		CT2A	szSOAPAction( strSOAPAction);
		m_requestHeaderMap.SetAt( "soapaction", szSOAPAction);
		m_requestHeaderMap.SetAt( "host", "localhost");
		m_requestHeaderMap.SetAt( "content-type", DEFAULT_SOAP_CONTENT_TYPE);
	}


public:
	CLoaderServerContext()
	{
		*m_szQueryString	= 0;
		strcpy(m_szVerb, DEFAULT_SOAP_HTTP_VERB);
		sprintf( m_szProtocol, DEFAULT_SOAP_HTTP_VERSION);
		sprintf( m_szProtocol, "HTTP/1.1");
	}

	~CLoaderServerContext() throw()
	{
		Cleanup();
	}
	
	void Cleanup() throw()
	{
		m_requestHeaderMap.RemoveAll();
		m_requestStream.Cleanup();
		m_responseStream.Cleanup();
		m_szPathInfo[0] = 0;
		m_szScriptPathTranslated[0] = 0;
		m_strDLLFileName.Empty();
		m_strDLLFilePath.Empty();
	}
	
	

protected:
	void	upcaseHttpHeaderName(CStringA&	strName)
	{
		int		iIndex;
		bool	bUpCase	=	true;
		for( iIndex = 0; iIndex  < strName.GetLength(); iIndex ++ )
		{
			if( bUpCase )
				strName.SetAt(iIndex, toupper( strName[iIndex] ));
			bUpCase	=	strName[iIndex ]  == '-';
		}
	}
	
// IHttpServerContext
protected:

public:

	// Implementation
	HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void **ppv) throw()
	{
		if (!ppv)
			return E_POINTER;
		if (InlineIsEqualGUID(riid, __uuidof(IUnknown)) ||
			InlineIsEqualGUID(riid, __uuidof(IHttpServerContext)))
		{
			*ppv = static_cast<IUnknown*>(this);
			AddRef();
			return S_OK;
		}
		return E_NOINTERFACE;
	}
	
	// Implementation
	ULONG STDMETHODCALLTYPE AddRef() throw()
	{
		return 1;
	}
	
	// Implementation
	ULONG STDMETHODCALLTYPE Release() throw()
	{
		return 1;
	}

	// Returns the HTTP status code.
	// Equivalent to EXTENSION_CONTROL_BLOCK::dwHttpStatusCode.
	DWORD GetHttpStatusCode() throw()
	{
		return 0;
	}

	// Returns a nul-terminated string that contains the HTTP method of the current request.
	// Examples of common HTTP methods include "GET" and "POST".
	// Equivalent to the REQUEST_METHOD server variable or EXTENSION_CONTROL_BLOCK::lpszMethod.
	LPCSTR GetRequestMethod() throw()
	{
		return m_szVerb;
	}

	// Returns a nul-terminated string that contains the query information.
	// This is the part of the URL that appears after the question mark (?). 
	// Equivalent to the QUERY_STRING server variable or EXTENSION_CONTROL_BLOCK::lpszQueryString.
	LPCSTR GetQueryString() throw()
	{
		return m_szQueryString;
	}

	// Returns a nul-terminated string that contains the path of the current request.
	// This is the part of the URL that appears after the server name, but before the query string.
	// Equivalent to the PATH_INFO server variable or EXTENSION_CONTROL_BLOCK::lpszPathInfo.
	LPCSTR GetPathInfo() throw()
	{
		return m_szPathInfo;
	}

	// Call this function to retrieve a nul-terminated string containing the physical path of the script.
	//
	// Returns TRUE on success, and FALSE on failure. Call GetLastError to get extended error information.
	//
	// On entry, pdwSize should point to a DWORD that indicates the size of the buffer in bytes.
	// On exit, the DWORD contains the number of bytes transferred or available to be transferred into the buffer (including the nul-terminating byte).
	// The script path is the same as GetPathTranslated up to the first .srf or .dll.
	// For example, if GetPathTranslated returns "c:\inetpub\vcisapi\hello.srf\goodmorning",
	// then this function returns "c:\inetpub\vcisapi\hello.srf".
	LPCSTR GetScriptPathTranslated() throw()
	{		
		return m_szScriptPathTranslated;
    }

	// Returns a nul-terminated string that contains the translated path of the requested resource.
	// This is the path of the resource on the local server.
	// Equivalent to the PATH_TRANSLATED server variable or EXTENSION_CONTROL_BLOCK::lpszPathTranslated.
	LPCSTR GetPathTranslated() throw()
	{
		return m_szScriptPathTranslated;
	}

	void SetPathTranslated()
	{
        // Initialize the translated script path
		LPCSTR szEnd = m_szScriptPathTranslated;
		
		while (TRUE)
		{
			while (*szEnd != '.' && *szEnd != '\0')
				szEnd++;
			if (*szEnd == '\0')
                break;

			szEnd++;
			if (!_strnicmp(szEnd, c_AtlDLLExtension+1, 3) || 
				!_strnicmp(szEnd, c_AtlSRFExtension+1, 3))
			{
				szEnd += 3;
                if (!*szEnd || *szEnd == '/' || *szEnd == '\\' || *szEnd == '?' || *szEnd == '#')
				    break;
			}
		}
	}

	// Returns the total number of bytes to be received from the client.
	// If this value is 0xffffffff, then there are four gigabytes or more of available data.
	// In this case, ReadClient or AsyncReadClient should be called until no more data is returned.
	// Equivalent to the CONTENT_LENGTH server variable or EXTENSION_CONTROL_BLOCK::cbTotalBytes. 
	DWORD GetTotalBytes() throw()
	{
		ULONGLONG nLen = 0;
		nLen	=	m_requestStream.m_str.GetLength();
		return (DWORD)nLen;
	}

	// Returns the number of bytes available in the request buffer accessible via GetAvailableData.
	// If GetAvailableBytes returns the same value as GetTotalBytes, the request buffer contains the whole request.
	// Otherwise, the remaining data should be read from the client using ReadClient or AsyncReadClient.
	// Equivalent to EXTENSION_CONTROL_BLOCK::cbAvailable.
	DWORD GetAvailableBytes() throw()
	{
		return 0;
	}

	// Returns a pointer to the request buffer containing the data sent by the client.
	// The size of the buffer can be determined by calling GetAvailableBytes.
	// Equivalent to EXTENSION_CONTROL_BLOCK::lpbData
	BYTE *GetAvailableData() throw()
	{
		return NULL;
	}

	// Returns a nul-terminated string that contains the content type of the data sent by the client.
	// Equivalent to the CONTENT_TYPE server variable or EXTENSION_CONTROL_BLOCK::lpszContentType.
	LPCSTR GetContentType() throw()
	{
		return DEFAULT_SOAP_CONTENT_TYPE;
	}

	// Call this function to retrieve a nul-terminated string containing the value of the requested server variable.
	// Returns TRUE on success, and FALSE on failure. Call GetLastError to get extended error information.
	// On entry, pdwSize should point to a DWORD that indicates the size of the buffer in bytes.
	// On exit, the DWORD contains the number of bytes transferred or available to be transferred into the buffer (including the nul-terminating byte).
	// Equivalent to  EXTENSION_CONTROL_BLOCK::GetServerVariable.
	BOOL GetServerVariable(
		LPCSTR pszVariableName,
		LPSTR pvBuffer,
		DWORD * pdwSize) throw()
	{
		BOOL		bRet	=	TRUE;
		CStringA	strValue;

		
		if( stricmp( pszVariableName, "ALL_RAW") == 0 )
		{
			// render all map
			POSITION	pos;
			CStringA	strName, strValue;
			
			pos	=	m_requestHeaderMap.GetStartPosition();
			while( pos != NULL )
			{
				m_requestHeaderMap.GetNextAssoc(pos, strName, strValue);
				upcaseHttpHeaderName(strName);

				strValue	+=	strName;
				strValue	+=	":";
				strValue	+=	strValue;
			}
			
		}
		else if( stricmp( pszVariableName, "URL") == 0 )
		{
			CT2A		tempConvert(m_strURL);
			strValue	=	(LPCSTR)tempConvert;	
		}
		else if( stricmp( pszVariableName, "SERVER_NAME") == 0 )
		{
			strValue	=	"NoServer";
		}
		else if( stricmp( pszVariableName, "SERVER_PROTOCOL") == 0 )
		{
			strValue	=	m_szProtocol;
		}
		else if( stricmp( pszVariableName, "HTTPS") == 0 )
		{
			strValue	=	"off";
		}
		else if( strstr(pszVariableName, "HTTP_") == pszVariableName)
		{
			LPCSTR	szVarName	=	pszVariableName + strlen( "HTTP_");
			CStringA	strVarName	=	szVarName;
			strVarName.MakeLower();
			if( !m_requestHeaderMap.Lookup( strVarName, strValue ) )
				strValue.Empty();
			else
				strValue	+=	"\r\n";
		}
		else
		{
			if (pvBuffer)
				*pvBuffer = 0;
			if (pdwSize)
				*pdwSize = 0;

			return	FALSE;
		}

		if( *pdwSize > (DWORD)strValue.GetLength() )
		{
			if(  pvBuffer )
				strncpy(pvBuffer, strValue, strValue.GetLength() + 1);
		}
		else
		{
			if(  pvBuffer )
				*pvBuffer	=	'\0';
			
			bRet	=	FALSE;
		}
		
		*pdwSize	=	strValue.GetLength() + 1;
		
		return bRet;
	}

	// Synchronously sends the data present in the given buffer to the client that made the request.
	// Returns TRUE on success, and FALSE on failure. Call GetLastError to get extended error information.
	// Equivalent to EXTENSION_CONTROL_BLOCK::WriteClient(..., HSE_IO_SYNC).
	BOOL WriteClient(void *pvBuffer, DWORD *pdwBytes) throw()
	{
		HRESULT	hRet	=	m_responseStream.WriteStream( (LPCSTR)pvBuffer, *pdwBytes, NULL);
		
		return (hRet==S_OK)?TRUE:FALSE;
	}

	// Asynchronously sends the data present in the given buffer to the client that made the request.
	// Returns TRUE on success, and FALSE on failure. Call GetLastError to get extended error information.
	// Equivalent to EXTENSION_CONTROL_BLOCK::WriteClient(..., HSE_IO_ASYNC).
	BOOL AsyncWriteClient(void *pvBuffer, DWORD *pdwBytes) throw()
	{
		
		return WriteClient(pvBuffer, pdwBytes);
	}

	// Call this function to synchronously read information from the body of the web client's HTTP request into the buffer supplied by the caller.
	// Returns TRUE on success, and FALSE on failure. Call GetLastError to get extended error information.
	// Equivalent to EXTENSION_CONTROL_BLOCK::ReadClient.
	BOOL ReadClient(void * pvBuffer, DWORD * pdwSize) throw()
	{
		ATLASSERT(pdwSize != NULL);
		DWORD dwRead = 0;
		ULONG	ulRead;
		HRESULT	hr	=	m_requestStream.Read( pvBuffer, *pdwSize, &ulRead);
		*pdwSize = ulRead;
		return (hr == S_OK ? TRUE : FALSE);
	}

	// Call this function to asynchronously read information from the body of the web client's HTTP request into the buffer supplied by the caller.
	// Returns TRUE on success, and FALSE on failure. Call GetLastError to get extended error information.
	// Equivalent to the HSE_REQ_ASYNC_READ_CLIENT server support function.
	BOOL AsyncReadClient(void * pvBuffer, DWORD * pdwSize) throw()
	{
		return ReadClient(pvBuffer, pdwSize);
	}
	
	// Call this function to redirect the client to the specified URL.
	// The client receives a 302 (Found) HTTP status code.
	// Returns TRUE on success, and FALSE on failure.
	// Equivalent to the HSE_REQ_SEND_URL_REDIRECT_RESP server support function.
	BOOL SendRedirectResponse(LPCSTR /*pszRedirectURL*/) throw()
	{
		ATLTRACE(_T("IHttpServerContext::SendRedirectResponse not supported in the stand-alone Loader.\r\n"));
		return FALSE;
	}

	// Call this function to retrieve a handle to the impersonation token for this request.
	// An impersonation token represents a user context. You can use the handle in calls to ImpersonateLoggedOnUser or SetThreadToken.
	// Do not call CloseHandle on the handle.
	// Returns TRUE on success, and FALSE on failure.
	// Equivalent to the HSE_REQ_GET_IMPERSONATION_TOKEN server support function.

	// TODO (jasjitg): Need to find a way to make this work now.
	BOOL GetImpersonationToken(HANDLE * /*pToken*/) throw()
	{
		ATLTRACE(_T("IHttpServerContext::GetImpersonationToken not supported in the stand-alone Loader.\r\n"));
		return FALSE;
	}

	// Call this function to send an HTTP response header to the client including the HTTP status, server version, message time, and MIME version.
	// Returns TRUE on success, and FALSE on failure.
	// Equivalent to the HSE_REQ_SEND_RESPONSE_HEADER_EX server support function.
	BOOL SendResponseHeader(
		LPCSTR pszHeader = "Content-Type: text/html\r\n\r\n",
		LPCSTR pszStatusCode = "200 OK",
		BOOL fKeepConn=FALSE) throw()
	{
		ATLTRACE(_T("IHttpServerContext::SendResponseHeader not supported in the stand-alone Loader.\r\n"));
		return TRUE;
	}

	// Call this function to terminate the session for the current request.
	// Returns TRUE on success, and FALSE on failure.
	// Equivalent to the HSE_REQ_DONE_WITH_SESSION server support function.
	BOOL DoneWithSession(DWORD /*dwStatusCode*/) throw()
	{
		ATLTRACE(_T("IHttpServerContext::DoneWithSession not supported in the stand-alone Loader.\r\n"));
		return FALSE;
	}

	// Call this function to set a special callback function that will be used for handling the completion of asynchronous I/O operations.
	// Returns TRUE on success, and FALSE on failure.
	// Equivalent to the HSE_REQ_IO_COMPLETION server support function.
	BOOL RequestIOCompletion(PFN_HSE_IO_COMPLETION /*pfn*/, DWORD * /*pdwContext*/) throw()
	{
		ATLTRACE(_T("IHttpServerContext::RequestIOCompletion not supported in the stand-alone Loader.\r\n"));
		return FALSE;
	}

	// Call this function to transmit a file asynchronously to the client.
	// Returns TRUE on success, and FALSE on failure.
	// Equivalent to the HSE_REQ_TRANSMIT_FILE server support function.
	BOOL TransmitFile(
		HANDLE hFile,
		PFN_HSE_IO_COMPLETION /*pfn*/,
		void * /*pContext*/,
		LPCSTR /*szStatusCode*/,
		DWORD /*dwBytesToWrite*/,
		DWORD /*dwOffset*/,
		void * /*pvHead*/,
		DWORD /*dwHeadLen*/,
		void * /*pvTail*/,
		DWORD /*dwTailLen*/,
		DWORD /*dwFlags*/) throw()
	{
		char szBuffer[1024];
		DWORD dwLen;
		OVERLAPPED overlapped;
		memset(&overlapped, 0, sizeof(OVERLAPPED));
		HANDLE hEvent = CreateEvent(NULL, TRUE, TRUE, NULL);
		if (!hEvent)
			return FALSE;
		overlapped.hEvent = hEvent;
		CHandle hdlEvent;
		hdlEvent.Attach(hEvent);
		DWORD dwErr;
		do
		{
			BOOL bRet = ::ReadFile(hFile, szBuffer, 1024, &dwLen, &overlapped);
			if (!bRet && (dwErr = GetLastError()) != ERROR_IO_PENDING && dwErr != ERROR_IO_INCOMPLETE)
				return FALSE;

			if (!GetOverlappedResult(hFile, &overlapped, &dwLen, TRUE))
				return FALSE;

			if (dwLen)
			{
				DWORD dwWritten = dwLen;
				if (!WriteClient(szBuffer, &dwWritten))
					return FALSE;
			}

		} while (dwLen != 0);

		return TRUE;
	}

    // Appends the string szMessage to the web server log for the current
    // request.
    // Returns TRUE on success, FALSE on failure.
    // Equivalent to the HSE_APPEND_LOG_PARAMETER server support function.
    BOOL AppendToLog(LPCSTR /*szMessage*/, DWORD * /*pdwLen*/) throw()
    {
		ATLTRACE(_T("IHttpServerContext::AppendToLog not supported in the stand-alone Loader.\r\n"));
		return FALSE;
    }

	BOOL MapUrlToPathEx(LPCSTR /*szLogicalPath*/, DWORD /*dwLen*/, HSE_URL_MAPEX_INFO * /*pumInfo*/)
	{
		ATLTRACE(_T("IHttpServerContext::MapUrlToPathEx not supported in the stand-alone Loader.\r\n"));
		return FALSE;
	}

};


#endif __LOADERSERVERCTXT_H_INCLUDED