// CustomParsingServer.h : Defines the ATL Server request handler class
//
#pragma once

#include "CustomSAXParser.h"

namespace CustomParsingServerService
{
// all struct, enum, and typedefs for your webservice should go inside the namespace
// ICustomParsingServerService - web service interface declaration
//
[
	uuid("F29A0805-241B-4FB7-BCC5-F6B994DB37EB"), 
	object
]
__interface ICustomParsingServerService
{
	// HelloWorld is a sample ATL Server web service method.  It shows how to
	// declare a web service method and its in-parameters and out-parameters
	[id(1)] HRESULT TreatXMLNode([out, retval] BSTR *bstrOutput, [out]unsigned int* pnNodesCount, [out]unsigned int* pnAttrCount);
	// TODO: Add additional web service methods here
};


// CustomParsingServerService - web service implementation
//
[
	request_handler(name="Default", sdl="GenCustomParsingServerWSDL"),
	soap_handler(
		name="CustomParsingServerService", 
		namespace="urn:CustomParsingServerService",
		protocol="soap"
	)
]
class CCustomParsingServerService :
	public ICustomParsingServerService
{
public:
// Custom SAX parsing data
	
	HRESULT DispatchSoapCall(const wchar_t *wszNamespaceUri,
		int cchNamespaceUri, const wchar_t *wszLocalName,
		int cchLocalName)
	{
		// Call the base class's DispatchSoapCall
		// This allows the appropriate method to be invoked after the request parsing is done
		HRESULT hRet	= __super::DispatchSoapCall(wszNamespaceUri, cchNamespaceUri, 
													wszLocalName, cchLocalName);
	
		if( SUCCEEDED(hRet)  )
		{
			// If the method was recognized, launch the custom parser for the content
			m_privateParser.Clear();

			ATLASSERT( GetReader() != NULL );
			m_privateParser.SetReader(GetReader());
			m_privateParser.SetParent(this);
			
			GetReader()->putContentHandler( &m_privateParser );
		}
		
		return hRet;
	}

	virtual void Cleanup()
	{
		__super::Cleanup();
		m_privateParser.Clear();
	}

	CSAXCustomParser	m_privateParser;


public:
	// This is a sample web service method that shows how to use the 
	// soap_method attribute to expose a method as a web method
	[ soap_method ]
	HRESULT TreatXMLNode(/*[out, retval]*/ BSTR *bstrOutput, /*[out]*/unsigned int* pnNodesCount, /*[out]*/unsigned int* pnAttrCount)
	{
		CComBSTR	bstrTemp;
		bstrTemp.Append( (LPCTSTR)m_privateParser.m_strDescription);
		*bstrOutput = bstrTemp.Detach();
		*pnNodesCount = m_privateParser.m_nNodesCount;
		*pnAttrCount = m_privateParser.m_nAttrCount;

		return S_OK;
	}
	// TODO: Add additional web service methods here
}; // class CCustomParsingServerService

} // namespace CustomParsingServerService
