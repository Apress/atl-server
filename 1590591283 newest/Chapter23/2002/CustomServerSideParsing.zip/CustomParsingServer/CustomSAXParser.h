#ifndef CUSTOMSAXPARSER_SAX_INCLUDED
#define CUSTOMSAXPARSER_SAX_INCLUDED
#pragma once

#include <atlsoap.h>


/*
	This class is a SAX Content Handler implementation that will be used in parsing a
	custom XML Node. 
	In a real application, the SAX handler methods (startElement, endElement, characters)
	should be overriden to actually use the XML.
	This simplified version only 'describes' the structure of the XML in plain English, but shows 
	how to access all the XML elements of the XML Node. As the description is built, it is appended
	to the m_strDescription variable that will be sent back to the client
*/

class CSAXCustomParser : public ISAXContentHandlerImpl
{
public:
	CString				m_strDescription;
	unsigned int		m_nNodesCount;
	unsigned int		m_nAttrCount;

public:
	HRESULT __stdcall QueryInterface(REFIID riid, void **ppv)
	{
		if (ppv == NULL)
		{
			return E_POINTER;
		}

		*ppv = NULL;

		if (InlineIsEqualGUID(riid, IID_IUnknown) ||
			InlineIsEqualGUID(riid, IID_ISAXContentHandler))
		{
			*ppv = static_cast<ISAXContentHandler *>(this);
			return S_OK;
		}

		return E_NOINTERFACE;
	}

	ULONG __stdcall AddRef()
	{
		return 1;
	}

	ULONG __stdcall Release()
	{
		return 1;
	}

private:

	ISAXContentHandler * m_pParent;
	ISAXXMLReader * m_pReader;
	DWORD m_dwReset;

	DWORD DisableReset(DWORD dwReset = 1)
	{
		m_dwReset+= dwReset;

		return m_dwReset;
	}

	DWORD EnableReset()
	{
		if (m_dwReset > 0)
		{
			--m_dwReset;
		}

		return m_dwReset;
	}

public:

	CSAXCustomParser(ISAXXMLReader *pReader = NULL, ISAXContentHandler *pParent = NULL)
		:m_pReader(pReader), m_pParent(pParent), m_dwReset(0), m_nNodesCount(0), m_nAttrCount(0)
	{
	}

	void SetReader(ISAXXMLReader *pReader)
	{
		m_pReader = pReader;
	}

	void SetParent(ISAXContentHandler *pParent)
	{
		m_pParent = pParent;
	}

	void Clear()
	{
		m_strDescription.Empty();
	}

	HRESULT __stdcall startElement( 
	     const wchar_t  * wszNamespaceUri,
	     int cchNamespaceUri,
	     const wchar_t  * wszLocalName,
	     int cchLocalName,
	     const wchar_t  *wszQName,
	     int cchQName,
	     ISAXAttributes  *pAttributes)
	{
		if (m_dwReset == 0)
		{
			// if there is unescaped, nested XML, must disable 
			// an additional time for the first element
			DisableReset();
		}
		DisableReset();


		CString		strAdd;
		CStringW	strNamespace, strLocalName;

		strNamespace.SetString( wszNamespaceUri, cchNamespaceUri);
		strLocalName.SetString( wszLocalName, cchLocalName);

		// Incrementing the Nodes counter
		m_nNodesCount ++;

		strAdd.Format( _T("Starting new element : (Namespace - %ls ) %ls\r\n"), strNamespace, strLocalName);
		m_strDescription += strAdd;


		m_strDescription += _T("Starting attribute list\r\n");
		
		
		// Browse attributes
		int nAttrs = 0;
		HRESULT hr = pAttributes->getLength(&nAttrs);

		_ATLTRY
		{
			if (SUCCEEDED(hr))
			{
				const wchar_t *wszAttrNamespaceUri = NULL;
				const wchar_t *wszAttrLocalName = NULL;
				const wchar_t *wszAttrQName = NULL;
				const wchar_t *wszAttrValue = NULL;
				int cchAttrUri = 0;
				int cchAttrLocalName = 0;
				int cchAttrQName = 0;
				int cchAttrValue = 0;
				CStringW	strValue;

				for (int i=0; i<nAttrs; i++)
				{
					// Incrementing the Attributes counter
					m_nAttrCount ++;
					
					hr = pAttributes->getName(i, &wszAttrNamespaceUri, &cchAttrUri, 
						&wszAttrLocalName, &cchAttrLocalName, &wszAttrQName, &cchAttrQName);

					if (FAILED(hr))
					{
						ATLTRACE( _T("ATLSOAP: CSAXCustomParser::startElement -- MSXML error.\r\n") );

						break;
					}

					hr = pAttributes->getValue(i, &wszAttrValue, &cchAttrValue);
					
					if (FAILED(hr))
					{
						ATLTRACE( _T("ATLSOAP: CSAXCustomParser::startElement -- MSXML error.\r\n") );

						break;
					}

					strNamespace.SetString( wszAttrNamespaceUri, cchAttrUri);
					strLocalName.SetString( wszAttrLocalName, cchAttrLocalName);
					strValue.SetString( wszAttrValue, cchAttrValue);

					strAdd.Format( _T("Attribute : (Namespace - %ls, Name - %ls) %ls\r\n"), 
									strNamespace, strLocalName, strValue);
					m_strDescription += strAdd;

				}
			}
		}
		_ATLCATCHALL()
		{
			ATLTRACE( _T("ATLSOAP: CSAXCustomParser::startElement -- out of memory.\r\n") );

			hr = E_OUTOFMEMORY;
		}

		m_strDescription += _T("End attribute list\r\n");
	
		return hr;
	}

	HRESULT __stdcall endElement( 
	     const wchar_t  * wszNamespaceUri,
	     int cchNamespaceUri,
	     const wchar_t  * wszLocalName,
	     int cchLocalName,
	     const wchar_t  *wszQName,
	     int cchQName)
	{
		HRESULT hr = S_OK;

		_ATLTRY
		{
			if (EnableReset() == 0)
			{
				// end of the XML Node, the element counter is back to zero
				hr = m_pParent->endElement(wszNamespaceUri, cchNamespaceUri,
						wszLocalName, cchLocalName, wszQName, cchQName);
				m_pReader->putContentHandler(m_pParent);
			}
			else
			{

				CString		strAdd;
				CStringW	strNamespace, strLocalName;

				strNamespace.SetString( wszNamespaceUri, cchNamespaceUri);
				strLocalName.SetString( wszLocalName, cchLocalName);

				strAdd.Format( _T("Ending element : (Namespace - %ls ) %ls\r\n"), strNamespace, strLocalName);
				m_strDescription += strAdd;
			}
		}
		_ATLCATCHALL()
		{
			ATLTRACE( _T("ATLSOAP: CSAXCustomParser::endElement -- out of memory.\r\n") );

			hr = E_OUTOFMEMORY;
		}

		return hr;
	}

	HRESULT __stdcall characters(
	     const wchar_t  *wszChars,
	     int cchChars)
	{
		CString		strAdd;
		CStringW	strCharacters;
		strCharacters.SetString( wszChars, cchChars);
		strAdd.Format("Content : %ls\r\n", strCharacters);
		m_strDescription += strAdd;
		return S_OK;
	}


}; // class CSAXCustomParser

#endif // CUSTOMSAXPARSER_SAX_INCLUDED