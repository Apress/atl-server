// SOAPXMLNodeClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#define _WIN32_WINDOWS 0x0500
#include <atlsoap.h>


/*
	The HTTP request MUST BE a valid SOAP request for our server
	Therefore, it must use the appropriate SOAP Action, and the body must conform 
	to the SOAP spec. It will consist of :
	<soap:Envelope ...> <!-- the SOAP Envelope, required by the SOAP spec -->
		<soap:Body ... > <!-- the SOAP Body, required by the SOAP spec -->
			<snp:TreatXMLNode ... > <!-- the SOAP Method, required by our server's WSDL -->
			... <!-- custom XML node HERE!!! -->
			</snp:TreatXMLNode> <!-- end of the SOAP Method, required by our server's WSDL -->
		<soap:Body ... > <!-- the SOAP Body, required by the SOAP spec -->
	<soap:Envelope... > <!-- the SOAP Body, required by the SOAP spec -->

	The first part and last parts are always the same for a given server/SOAP Method, so they 
	are hardcoded below as g_szRequestHeader and g_szRequestFooter
	Same for the SOAP Action
*/

const TCHAR	*g_szSOAPAction =  _T("\"#TreatXMLNode\"");

const TCHAR	*g_szRequestHeader = 
_T("<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n")
_T("	<soap:Body soap:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n")
_T("		<snp:TreatXMLNode xmlns:snp=\"urn:CustomParsingServerService\">");

const TCHAR	*g_szRequestFooter = 
_T("		</snp:TreatXMLNode>\r\n")
_T("	</soap:Body>\r\n")
_T("</soap:Envelope>\r\n");


int _tmain(int argc, _TCHAR* argv[])
{
	CUrl				url;
	
	// Using ATL Server classes for direct HTTP communication. As this sample only covers 
	// custom XML Node parsing on the server side, the client only needs to submit a request
	CAtlHttpClient		httpClient;
	CAtlNavigateData 	navData;
	CStringA 			strExtraHeaders;
	CStringA			strRequestBody, strResponseBody;
	
	
	// The URL of the server
	LPCTSTR				szURL	=	_T("http://localhost/CustomParsingServer/CustomParsingServer.dll?Handler=Default");

	
	// This is the custom XML node to be sent
	const TCHAR	*szCustomXML = 
		_T("<m:customXMLNode xmlns:m=\"http://MyServer/NamespaceM\">")
		_T("	<m:binaryinfo bintype=\"exe\">")
		_T("		<m:filename>C:\\WINNT\\system32\\notepad.exe</m:filename>")
		_T("		<m:filesize>0xc600</m:filesize>")
		_T("		<m:versioninfo checkSum=\"0x0\" creationdate=\"2000-10-23T09:33:11.090\" description=\"Notepad\" manufacturer=\"Microsoft Corporation\" version=\"4.0\"/>")
		_T("	</m:binaryinfo>")
		_T("</m:customXMLNode>");

	url.CrackUrl(szURL);

	navData.SetMethod(ATL_HTTP_METHOD_POST);
	navData.SetPort(url.GetPortNumber());
	
	
	strExtraHeaders.Format("SOAPAction: \"%s\"\r\n", g_szSOAPAction);
	navData.SetExtraHeaders(strExtraHeaders);
	
	

	// Building the request body
	strRequestBody  = g_szRequestHeader;
	strRequestBody += szCustomXML;
	strRequestBody += g_szRequestFooter;

	navData.SetPostData((LPBYTE)(LPCSTR) strRequestBody, strRequestBody.GetLength(), _T("text/xml"));
	

	// Debug trace
	printf(" Request:\n================\n");
	printf( "%s\n\n", strRequestBody);

	// Parsing might take a while
	navData.SetSocketTimeout(10000);

	

	httpClient.SetProxy("localhost", 4999);
	// Send the request
	BOOL	bRet	=	httpClient.Navigate(&url, &navData);
	
	printf(" Navigate result : %s\n", bRet?"TRUE":"FALSE");

	
	// Tracing the response from the server
	printf( "result following :\n==============\n");
	char	*pResponse	=	new char[httpClient.GetBodyLength() + 1];
	memcpy( pResponse, httpClient.GetBody(), httpClient.GetBodyLength());
	pResponse[httpClient.GetBodyLength()]	=	0;
	strResponseBody = pResponse;
	delete []pResponse;
	
	

	// Unescape the \r\n\t sequences in the SOAP response for proper formatting
	strResponseBody.Replace(_T("&#x000D;"), _T("\r"));
	strResponseBody.Replace(_T("&#x000A;"), _T("\n"));
	strResponseBody.Replace(_T("&#x0009;"), _T("\t"));
	printf("%s\n\n", (LPCTSTR)strResponseBody);
	
	
	return 0;
}

